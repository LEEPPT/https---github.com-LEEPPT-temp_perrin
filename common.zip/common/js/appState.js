define([ 'js/constants' ], function(Constants) {
	var AppState = {
		// Cached App State
		currentLangCode : Constants.LANG_EN,
		isNetworkConnected : '',
		serverConnectionState : Constants.SERVER_DISCONNECTED,
		appMode : Constants.APP_MODE_ONLINE,
		storedPortfolio : [],
		storedTargetPortfolio : [],
		storedRAQResult : [],
		storedCallReport : [],
		userID:'default',
		userInfo : null,
		raqConfig : null,
		raqPDFTemplate:[],
		rmRINumber:null,
		tmpRAQResult:{},		
		isFirstTimeLaunch : 'Y',
		isRAQReminderShown : false
	};
	return AppState;
});
