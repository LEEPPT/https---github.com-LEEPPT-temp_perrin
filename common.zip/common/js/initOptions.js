// Uncomment the initialization options as required. For advanced initialization options please refer to IBM MobileFirst Platform Foundation Knowledge Center 
 
 var wlInitOptions = {
	
	// # To disable automatic hiding of the splash screen uncomment this property and use WL.App.hideSplashScreen() API
	autoHideSplash: false,
		 
	// # The callback function to invoke in case application fails to connect to MobileFirst Server
	//onConnectionFailure: function (){},
	
	// # MobileFirst Server connection timeout
	//timeout: 30000,
	
	// # How often heartbeat request will be sent to MobileFirst Server
	//heartBeatIntervalInSecs: 7 * 60,
	
	// # Enable FIPS 140-2 for data-in-motion (network) and data-at-rest (JSONStore) on iOS or Android.
	//   Requires the FIPS 140-2 optional feature to be enabled also.
	//enableFIPS : false,
	
	// # The options of busy indicator used during application start up
	busyOptions: {text: "Loading"},
	
	// Disable because of duplicate handling with Ionic
	showIOS7StatusBar : false,
	
	showCloseOnRemoteDisableDenial : false
};

if (window.addEventListener) {
	window.addEventListener('load', function() { WL.Client.init(wlInitOptions); }, false);
} else if (window.attachEvent) {
	window.attachEvent('onload',  function() { WL.Client.init(wlInitOptions); });
}

wl_directUpdateChallengeHandler.handleDirectUpdate = function(directUpdateData,directUpdateContext) {

	
	  var totalSize = ((directUpdateData.downloadSize)/1024).toFixed(1).toString();
	  require([
	       	'js/appState',
	    	'js/message'],function(AppState,Message){
		  	var langCode = AppState.currentLangCode; 
		  	
	        var message = Message[langCode].MSG_DIRECT_UPDATE;
			var confirm = Message[langCode].BTN_CONFIRM;
			var reminder = Message[langCode].MSG_REMINDER;
		  message = message.replace("@totalSize@", totalSize);
		  WL.SimpleDialog.show(reminder,message, [{
		    text : confirm,
		    handler : function() {
		      directUpdateContext.start();
		    }
		  }]);
	  });
	};
WL.App.BackgroundHandler.setOnAppEnteringForeground(function(){
	WL.Client.checkForDirectUpdate();
});
	
function wlCommonInit(){
	/*
	 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required. 
	 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
	 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
	 *    
	 *    WL.Client.connect({
	 *    		onSuccess: onConnectSuccess,
	 *    		onFailure: onConnectFailure
	 *    });
	 *     
	 */
	
	// Common initialization code goes here
	var env = WL.Client.getEnvironment();
    if(env === WL.Environment.IPHONE || env === WL.Environment.IPAD){
        document.body.classList.add('platform-ios'); 
    } else if(env === WL.Environment.ANDROID){
        document.body.classList.add('platform-android'); 
    }
}