define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var CallReportAdapter = {
		submitCallReport: function(userID, reportData, successCallback, failureCallback) {
			LogUtil.logInfo('CallReportAdapter : submitCallReport : Attempt to submitCallReport');
			function submitCallReportSuccess(data) {
				LogUtil.logInfo('CallReportAdapter : submitCallReportSuccess : ' + data);
				successCallback(data);
			}
			function submitCallReportFailure(data) {
				LogUtil.logError('CallReportAdapter : submitCallReportFailure : ERROR - ' + data);
				failureCallback(data);
			}
			var paramList=[
			               userID, 
			               reportData.attendeeList,
			               reportData.staffList,
			               reportData.meetingDate, 
			               reportData.meetingTime, 
			               reportData.venue, 
			               reportData.mainObjectiveList, 
			               reportData.meetingTypeList, 
			               reportData.meetingDetailsList
			];
			
			LogUtil.logInfo("paramList");
			LogUtil.logInfo(paramList);
			var invocationData = {
					adapter: "CallReportAdapter", 
					procedure: "submitCallReport",
					parameters: paramList
			};
			WL.Client.invokeProcedure(invocationData, {
				onSuccess: submitCallReportSuccess,
				onFailure: submitCallReportFailure,
				timeout: 10000 
			});
		}
	};
	return CallReportAdapter;
});
