define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var AuditLoggingAdapter = {
		insertAuditLog: function(params,successCallback,failureCallback) {
			LogUtil.logInfo('AuditLoggingAdapter : insertAuditLog : Attempt to insertAuditLog');
			function insertAuditLogSuccess(data) {
				LogUtil.logInfo('AuditLoggingAdapter : insertAuditLogSuccess : ' + data);
				successCallback(data);
			}
			function insertAuditLogFailure(data) {
				LogUtil.logError('AuditLoggingAdapter : insertAuditLogFailure : ERROR - ' + data);
				failureCallback(data);
			}
			var paramList=[
			            params.userID,
			            params.activity,
			            params.customerName,
			            params.accountName,
			            params.accountNumber
			    ];
			LogUtil.logInfo('paramList');
			LogUtil.logInfo(paramList);
			var invocationData = {
					adapter: 'AuditLoggingAdapter', 
					procedure: 'insertAuditLog',
					parameters: paramList
			};
			WL.Client.invokeProcedure(invocationData, {
				onSuccess: insertAuditLogSuccess,
				onFailure: insertAuditLogFailure,
				timeout: 10000 
			});
			
		}
		
};
		return AuditLoggingAdapter;
});
