define([
    'js/appConfig',
    'js/constants',
    'js/Util/LogUtil'
], function(AppConfig, Constants, LogUtil) {

    var Validation = {

        isEmpty: function(input) {
            var isEmpty = false;
            if (input === null || input === '' || input === undefined || input === 'undefined' || typeof(input) === 'undefined') {
                isEmpty = true;
            }
            return isEmpty;
        },
        isExistInSelectedAccount: function(accountList, accountNumber) {
            var isExist = false;
            angular.forEach(accountList, function(value, key) {

                if (value.accountNumber === accountNumber) {
                	LogUtil.logTrace('Validation -> Account already selected.');
                    isExist = true;
                }
            });
            return isExist;
        },
        isInvalidLength: function(input, minLength, maxLength) {
        	var isInvalidLength = false;
        	if (input && (input.length < minLength || input.length > maxLength)) {
        		isInvalidLength = true;
        	}
            return isInvalidLength;
        },
        isNumeric: function(input) {
        	return !isNaN(parseFloat(input)) && isFinite(input);
        }
    };
    return Validation;
});