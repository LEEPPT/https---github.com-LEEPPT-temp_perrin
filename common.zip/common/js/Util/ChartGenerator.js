define([
	'js/appConfig',	
	'js/constants',
    'js/message',
    'js/appState',
	'js/Util/CommonUtil',
	'js/Util/LogUtil'
	], function(AppConfig,Constants,Message,AppState,CommonUtil,LogUtil){

		var ChartGenerator = {

				createBasicDonutChartOption : function() {  
					return {
		      			  chart: {
		      				  type: 'pieChart',
		      				  height: 395,
		      				  width :395,
		                      donut: true,
		                      x: function(d){return d.key;},
		                      y: function(d){return d.y;},
		                      duration: 500,
		                      pie: {
		  	                    dispatch: {
		  	                        
		  	                    }
		  	                  },
			                  legend: {
			                    margin: {
			                       top: 0,
			                       right: 0,
			                       bottom: 0,
			                       left: 0
			                     }
			                  },
			                  showLegend: false,
			                  donutRatio: 0.4,
			                  showLabels: false
		        			    
		      			  }
		        	};
				},
		        createBasicPieChartOption :function() {  
		        	return {
		      			  chart: {
		        			    type: 'pieChart',
		        			    height: 395,
		        			    width :395,
		        			    x: function(d){return d.key;},
		        			    y: function(d){return d.y;},
		        			    duration: 500,
		        			    labelThreshold: 0.01,
		        			    labelSunbeamLayout: true,
		        			    pie: {
		  	                    dispatch: {
		  	                        
		  	                    	}
		        			    },
		        			    legend: {
		        			      margin: {
		        			        top: 0,
		        			        right: 0,
		        			        bottom: 0,
		        			        left: 0
		        			      }
		        			    },
			  	              	showLegend: false,
			  	                showLabels: false
	        			  }
		        		};
	        		},
			        createBasicModelChartOption :function() {  
			        	return {
			      			  chart: {
			        			    type: 'pieChart',
			        			    height: 400,
			        			    width :400,
				                    donut: true,
				                    donutRatio: 0.43,
			        			    x: function(d){return d.key;},
			        			    y: function(d){return d.y;},
			        			    duration: 500,
			        			    labelThreshold: 0.01,
			        			    labelSunbeamLayout: true,
			        			    tooltip: {
	                                    enabled: false
			        			    },
			        			    pie: {
			  	                    dispatch: {
			  	                        
			  	                    	}
			        			    },
			        			    growOnHover : false,
			        			    legend: {
			        			      margin: {
			        			        top: 0,
			        			        right: 0,
			        			        bottom: 0,
			        			        left: 0
			        			      }
			        			    },
			        			    margin: {
			        			        top: 0,
			        			        right: 0,
			        			        bottom: 0,
			        			        left: 0
			        			    },
				  	              	showLegend: false,
				  	                showLabels: false
		        			  }
			        		};
		        		},
		        createBasicBulletChartOption :function() {  
				        	return {
				      			chart: {
				        			    type: 'bulletChart',
				        			    height: 50,
				        			    width : 550,
				        			    orient: "left",
				        			    bullet: { orient: "left" },
				        			    margin: {
				        			        top: 0,
				        			        right: 0,
				        			        bottom: 0,
				        			        left: 0
				        			    }
					        	}
			        		};
		        		},
	        	createStackedBarChartOption : function() {
	        		return {
		    			chart: {
		                    type: 'multiBarChart',
		                    height: '100%',
		                    margin : {
		                        top: 20,
		                        right: 20,
		                        bottom: 45,
		                        left: 80
		                    },
		                    clipEdge: true,
		                    //staggerLabels: true,
		                    duration: 500,
		                    stacked: true,
	    	                multibar: {
	    	                    dispatch: {
	    	                        
	    	                    }
	    	                },
		                    xAxis: {
		                        axisLabel: '',
		                        showMaxMin: false,
		                        tickFormat: function(d){
		                            return d;
		                        }
		                    },
		                    yAxis: {
		                        axisLabel: '',
		                        axisLabelDistance: -20,
		                        showMaxMin: false,
		                        tickFormat: function(d){
		                        	if ((d / 1000) >= 1) {
		                        		d = d / 1000 + "K";
		                           }
		                        	return d;
		                        }
		                    },
		                    showLegend: false,
		                    showControls: false
		                }
	        		};
	    		},
	    		createBasicLineChartOption: function() {
	    			return {
	    				chart: {
	    	                type: 'lineChart',
	    	                height: '100%',
	    	                margin : {
	    	                    top: 20,
	    	                    right: 20,
	    	                    bottom: 60,
	    	                    left: 55
	    	                },
	    	                x: function(d){ return d.x; },
	    	                y: function(d){ return d.y; },
	    	                useInteractiveGuideline: false,
	    	                clipEdge: false,
	    	                duration: -50,
    	                    stacked: true,
	    	                lines: {
	    	                    dispatch: {
	    	                        
	    	                    }
	    	                },
	    	                tooltip: {
        	                	enabled: false
        	                },
	    	                xAxis: {
	    	                    axisLabel: '',
	    	                    showMaxMin: true
	    	                },
	    	                yAxis: {
	    	                    axisLabel: '',
	    	                    showMaxMin: true
	    	                },
	    	                showLegend: false,
	    	                showControls: false,
	    	                reduceXTicks : false
	    	            },
	    	            title: {
	    	                enable: true,
	    	                text: ''
	    	            }
	    			};
    			},
    			createBasicBarChartOption : function() {
    				return {
    	    			chart: {
    	                    type: 'multiBarChart',
    	                    height: '100%',
    	                    margin : {
    	                        left:60
    	                    },
    	                    clipEdge: true,
    	                    duration: 500,
    	                    stacked: true,
        	                multibar: {
        	                    dispatch: {
        	                        
        	                    }
        	                },
        	                tooltip: {
        	                	enabled: false
        	                },
    	                    xAxis: {
    	                        axisLabel: '',
    	                        showMaxMin: false,
    	                        tickFormat: function(d){
    	                            return d;
    	                        }
    	                    },
    	                    yAxis: {
    	                        axisLabel: '',
    	                        axisLabelDistance: -20,
    	                        showMaxMin: true,
    	                        ticks : 3,
    	                        tickFormat: function(d){
    	                        	if ((d / 1000) >= 1) {
    	                        		d = d / 1000 + "K";
    	                           }
    	                        	return d;
    	                        }
    	                    },
    	                    showLegend: false,
    	                    showControls: false,
    	                    reduceXTicks : false
    	                }
    	    		};
    			},
    			createBasicDiscreteBarChartOption : function() {
    				var currencyChartColorSets = ['#AA834F', '#CEAA84'];
    				return {
    					chart: {
    	                    type: 'discreteBarChart',
    	                    height: 500,
    	                    margin: {
    	                        top: 100,
    	                        left: 100,
    	                        right: 100
    	                    },
    	                    showXAxis: true,
    	                    showYAxis: true,
    	                    forceY: [0],
    	                    x: function(d) {
    	                        return d.label;
    	                    },
    	                    y: function(d) {
    	                        return d.value + (1e-10);
    	                    },
    	                    showValues: false,
    	                    color: function(d, i) {
    	                        if (d.value >= 0) return currencyChartColorSets[0];
    	                        else return currencyChartColorSets[1];
    	                    },
    	                    valueFormat: function(d) {
    	                        return d3.format(',.4f')(d);
    	                    },
    	                    duration: 500,
    	                    xAxis: {
    	                        tickFormat: function(d) {
    	                            return d;
    	                        }
    	                    },
    	                    yAxis: {
    	                        rotateYLabel: false,
    	                        showMaxMin: true,
    	                        ticks: 7,
    	                        tickFormat: function(d) {
    	                            if (Math.abs(d) > 0) {
    	                                var scaleDenominator = 0,
    	                                    valueScale = [{
    	                                        range: 1000000000000,
    	                                        label: "tn"
    	                                    }, {
    	                                        range: 1000000000,
    	                                        label: "bn"
    	                                    }, {
    	                                        range: 1000000,
    	                                        label: "mn"
    	                                    }, {
    	                                        range: 1000,
    	                                        label: "k"
    	                                    }];
    	                                for (var i in valueScale) {
    	                                    var scale = valueScale[i];
    	                                    if (Math.abs(d) >= scale.range) {
    	                                        scaleDenominator = scale.range;
    	                                        return (d / scaleDenominator).toFixed(1) + scale.label;
    	                                    }
    	                                }
    	                            }
    	                            return d.toFixed(1);
    	                        }
    	                    }
    	                }
    				};
    			},
    			createHorizontalBarChartOption : function() {
    				return {
		    			chart: {
		                    type: 'multiBarHorizontalChart',
		                    height: 50,
		                    width: 420,
		                    margin : {
		                        top: 0,
		                        right: 10,
		                        bottom: 0,
		                        left: 5
		                    },
		                    showValues : false,	
		                    duration: 0,
		                    stacked: false,
	    	                multibar: {
	    	                    dispatch: {
	    	                        
	    	                    }
	    	                },
		                    xAxis: {
		                        axisLabel: '',
		                        showMaxMin: false,
		                        tickFormat: function(d){
		                            return d;
		                        }
		                    },
		                    yAxis: {
		                        axisLabel: '',
		                        axisLabelDistance: 0,
		                        showMaxMin: false,
		                        tickFormat: function(d){
		                        	return d;
		                        }
		                    },
		                    showLegend: false,
		                    showControls: false,
		                    showXAxis : false,
		                    tooltips: false,
		                    tooltip: {
		                    	enabled: false
		                    }
		                }
	        		};
    			},
    			axisNumberFormater : function (d){
    	    		if (d > 0){ 
    	    			return CommonUtil.numericShortenFormat(d);	
    	    		}else if(d < 0) {
    	    			return '-'+CommonUtil.numericShortenFormat(Math.abs(d));	
    	    		}else {
    	    			return d;
    	    		}
                },
                axisMonthFormatter : function (d) {
	                var months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	                var langCode = AppState.currentLangCode;
                	return Message[langCode][months[d-1]];
                },
                axisPercentFormater : function (d){
                	var formattedAxisPercent = d3.format('.02f')(d);
                	if (formattedAxisPercent == '-0.00') {
                		formattedAxisPercent = '0.00';
                	}
                	return formattedAxisPercent + ' %';
                },
                /*
            	 * "d" should be YYYY-MM
            	 * return "mmm YYYY"
            	 */ 
                axisMonthYearFormatter : function (d) {
	                var months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	                var date = d.split('-');
	                if (date.length != 2 || isNaN(date[1]) || Number(date[1]) < 1 || Number(date[1]) > 12) {
	                	return d;
	                }
	                var langCode = AppState.currentLangCode;
	                if (langCode == Constants.LANG_TC || langCode == Constants.LANG_SC) {
	                	return date[0] + Message[langCode].YEAR + Message[langCode][months[Number(date[1])-1]];
	                } else {
	                	return Message[langCode][months[Number(date[1])-1]]+" "+date[0];
	                }
                },
                /*
            	 * "d" should be number of YYYYMM
            	 * return "mmm YYYY"
            	 */ 
                axisMonthYearFormatter2 : function (d) {
	                d = d.toString();
                	var months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	                var year = d.substring(0,4);
	                var month = Number(d.substring(4,6));
	                if (year === null || month === null || year === undefined || month === undefined) {
	                	return d;
	                }
	                var langCode = AppState.currentLangCode;
	                if (langCode === Constants.LANG_TC || langCode === Constants.LANG_SC) {
	                	return year + Message[langCode].YEAR + Message[langCode][months[month-1]];
	                } else {
	                	return Message[langCode][months[month-1]]+" "+year;
	                }
                },
                axisMonthYearFormatter2MonthOnly : function (d) {
	                d = d.toString();
                	var months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	                var year = d.substring(0,4);
	                var month = Number(d.substring(4,6));
	                if (year === null || month === null || year === undefined || month === undefined) {
	                	return d;
	                }
	                var langCode = AppState.currentLangCode;
	                
	                return Message[langCode][months[month-1]];
                },
                axisMonthYearFormatter3 : function (d) {
                	var months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
	                var month = Number(d);
	                if (month < 1) {
	                	month = month + 12;
	                }
	                var langCode = AppState.currentLangCode;
	                return Message[langCode][months[month-1]];
                },
                getDefaultColorSet : function(){
                	return ['#C53C31', '#881E41', '#464478', '#64A533', '#EC8626', '#923575', '#CABDA7'];
                },
                getCategoryColorMap: function (){
                	var catergoryList = [
                	                ['savings_n_current','#F76744'],
            		                ['time_deposit','#74AF41'],
            		                ['bond','#F0AA30'],
            		                ['linked_deposit','#8B6CB8'],
            		                ['stock','#B6264A'],
            		                ['structured_products','#141B76'],
            		                ['unit_trust','#D4C7B6'],
            		                ['investment','#9B2F51'],
            		                ['cash_n_deposit','#73AE40'],
            		                ['loans','#D4C7B5'],
            		                ['net_asset_values','#1C76AB']
            		             ];
                	var colorMap = new Map(catergoryList);
                	return colorMap;
                },
                getGoldenColorSet : function(){
                	return ['#CEAA84','#AA834F'];
                },
                createLegendByData : function (data,legendConfig) {
           			for (i = 0 ; i < data.length ; i++) {
           				LogUtil.logInfo('assetClassID: '+legendConfig.size);
           				data[i].color = legendConfig.get(data[i].assetClassID || data[i].category).color;
           				data[i].legendLabel = legendConfig.get(data[i].assetClassID || data[i].category).label;
        			}
           			return data;
                },
                createMutilChartOption : function () {
                	return {
                		chart : {
            				type : 'multiChart',
            				height : 450,
            				margin : {
            					
            				},
            				useInteractiveGuideline: true,
            				duration : 500,
            				xAxis : {
            					tickFormat : function(d) {
            						return d;
            					},
            					showMaxMin: false,
            				},
            				yAxis1 : {
            					tickFormat : function(d) {
            						return d3.format(',.1f')(d);
            					},
            					showMaxMin: false,
            					axisLabelDistance: 60,
        					},
            				lines1 : {
            					dispatch : {
            						renderEnd : function() {
            							
            						}
            					},
            					clipEdge: false,
            					
            				},
            				bars1 : {
            					dispatch : {
            						elementClick : function (e) {
            							
            						},
            						renderEnd : function() {
            							
            						}
            					},
            					clipEdge: false,
            				},
            				showLegend : false,
            				tooltip: {
        	                	enabled: false
        	                },
            				tooltips : false
            			}
                	};
                }
			 
			};

			return ChartGenerator;
		});
