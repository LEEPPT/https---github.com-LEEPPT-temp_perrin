define([
	'js/Util/LogUtil',
	'js/Adapters/AuditLoggingAdapter',
	'js/constants',
	'environment'
	], function(LogUtil,AuditLoggingAdapter,Constants,Environment){

		var AuditLoggingUtil = {

			 insertAuditLogging  : function(auditLogInfo) {
				 AuditLoggingAdapter.insertAuditLog(auditLogInfo,this.insertSuccessCallback,this.insertFailureCallback);
				 if(Environment.isEnableAnalytics==='Y'){
					 var analyticsData = [auditLogInfo.userID,auditLogInfo.customerName,auditLogInfo.accountName,auditLogInfo.accountNumber];
					 var event = {buttonPress: auditLogInfo.activity};
					 WL.Analytics.log(event,analyticsData.toString());
					 WL.Analytics.send();
				 }
			 },

			 insertSuccessCallback : function(data) {
				 LogUtil.logInfo('AuditLoggingUtil insertSuccessCallback');
			 },

			 insertFailureCallback : function(data) {
				 LogUtil.logInfo('AuditLoggingUtil insertFailureCallback');
			 }
			 
			};
			return AuditLoggingUtil;
		});
