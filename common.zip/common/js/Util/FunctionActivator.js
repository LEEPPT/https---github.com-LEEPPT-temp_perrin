define([
	'js/Util/LogUtil',
	'js/appState',
    'js/message'
], function(LogUtil,AppState,Message) {
	var service = {};
	var _moduleAccess = new Map();
	var _functionAccess = new Map();

	service.isAccessibleToModule = function(module) {
		var accessible = false;
		var map = _moduleAccess.get(module);
		accessible =  (map.get('isAccessible') === 1 && map.get('userRightGranted') === 1) ? true : false;
		LogUtil.logDebug('FunctionActivator -> isAccessibleToModule -> '+module+' - ' + (accessible ? 'Y' : 'N'));
		return  accessible;
	};
	service.isAccessibleToFunction = function(fn) {
		var map = _functionAccess.get(fn);
		var accessible = false;
		if (map && map.get('isAccessible') === 1 && service.isAccessibleToModule(map.get('module'))) {
			accessible = true;
		}
		LogUtil.logDebug('FunctionActivator -> isAccessibleToFunction -> '+fn+' - ' + (accessible ? 'Y' : 'N'));
		return accessible;
	};
	
	service.setModuleAccessible = function(module, isAccessible) {
		LogUtil.logDebug('FunctionActivator -> setModuleAccessible -> module: '+module+' enabled: '+isAccessible);
		var map = _moduleAccess.get(module);
		if (!map) {	map = new Map(); }
		map.set('isAccessible', (isAccessible ? 1 :0));

		_moduleAccess.set(module, map);
	};
	service.setModuleGrantedToUser = function(module, isAccessible) {
		LogUtil.logDebug('Module : ' + module);
		var map = _moduleAccess.get(module);
		
		if (!map) {	map = new Map(); }
		map.set('userRightGranted', (isAccessible ? 1 :0));
		
		_moduleAccess.set(module, map);

	};
	service.setFunctionAccessible = function(fn, module, isAccessible) {
		LogUtil.logDebug('FunctionActivator -> setFunctionAccessible -> fn: '+fn+' module: '+module+' enabled: '+isAccessible);
		var map =  new Map();
		map.set('module', module);
		map.set('isAccessible', (isAccessible ? 1 : 0));
		
		_functionAccess.set(fn, map);
	};

	service.setModuleAccessControlList = function(controlList) {
		LogUtil.logDebug('FunctionActivator -> setAccessControlList ');
		if (controlList && typeof controlList.forEach === 'function') {
			controlList.forEach(function(item) {
				service.setModuleGrantedToUser(item, true);
			});
		} else {
			LogUtil.logError('FunctionActivator -> setAccessControlList: input param should be an array');
			LogUtil.logError(controlList);
		}
	};
	
	service.numberOfAccessibleModules = function() {
		var number = 0;
		LogUtil.logInfo('FunctionActivator -> numberOfAccessibleModules');
		_moduleAccess.forEach(function(item) {
			var accessible = (item.get('isAccessible') === 1 && item.get('userRightGranted') === 1) ? true : false;
			if (accessible) { number += 1; }
		});
		return number;
	};
	
	service.showAccessDeniedMessage = function(ionicHistory) {
		var langCode = AppState.currentLangCode;
		var confirm = Message[langCode].BTN_CONFIRM;
		var reminder = Message[langCode].MSG_REMINDER;
		var message = Message[langCode].ERR_GENERAL_MESSAGE;
		WL.SimpleDialog.show(reminder,message,[{text:confirm, handler: function() {
				ionicHistory.goBack();
			}
		}]);
	};
	return service;
});