function initRequireJS(){
	requirejs.config({
		  paths: {
		    angular: 'lib/ionic/js/angular/angular.min',
		    angularTranslate: 'lib/ionic/js/angular/angular-translate.min',
		    ionic: 'lib/ionic/js/ionic.bundle.min',
		    d3: 'lib/d3/d3.min',
		    nvd3: 'lib/nvd3/nv.d3.min',
		    angularNVD3: 'lib/angularnvd3/angular-nvd3.min'
		  },
		  
		  shim: {
		      angular : {exports : 'angular'},
		      angularTranslate : {deps: ['angular']},
		      nvd3 : {deps: ['d3']},
		      angularNVD3 : {deps: ['angular','nvd3','d3']},
		      ionic :  {deps: ['angular'], exports : 'ionic'}
		  },
		  // set the loading priority especially
		  priority: [
		    'angular',
		    'ionic'
		   ]
		});
	
	requirejs(['js/wlApp'],function (wlApp) {
		wlApp.initialize();
	});
		
	}

var isWLAppMode = document.URL.indexOf( 'http://' ) === -1 && document.URL.indexOf( 'https://' ) === -1;
if ( isWLAppMode ) {    
	console.log("Entering Worklight Mode");
	document.addEventListener("deviceready", initRequireJS, false);
} else {
	console.log("Entering Web Browser Mode");
	initRequireJS();
}  
var busyIndicator = new WL.BusyIndicator(null);
setTimeout(function(){
	busyIndicator.show();
	},50);