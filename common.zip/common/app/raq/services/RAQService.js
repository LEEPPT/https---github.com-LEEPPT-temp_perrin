define([
    'app/app',
    'js/Util/LogUtil',
    'app/raq/data/RAQDAO'
], function(app, LogUtil,RAQDAO) {
    'use strict';
    app.service('RAQService', ['RAQDAO',function(RAQDAO) {
            var raqService = {};          
            raqService.getRAQConfig = function(successCallback, failureCallback) {
                var daoSuccessCallback = function(data) {
                    if (data && data.contentList) {
                        LogUtil.logDebug('RAQService : getRAQConfig : daoSuccessCallback : JSON response is true');
                        successCallback(data); 
                    } else {
                    	LogUtil.logError('RAQService : getRAQConfig : daoSuccessCallback : JSON response failed');
                    	failureCallback(data);  					
                    }
                };               
                var daoFailureCallback = function(data) {
                	LogUtil.logError('RAQService : getRAQConfig : daoFailureCallback');
                	failureCallback(data);
                };
                RAQDAO.getRAQConfigData(daoSuccessCallback,daoFailureCallback); 
            };

            raqService.getRAQPDFTemplates = function(successCallback, failureCallback) {
                var daoSuccessCallback = function(data) {
                    
                    LogUtil.logDebug('RAQService -> getRAQPDFTemplates -> daoSuccessCallback ');
                    successCallback(data); 
                };               
                var daoFailureCallback = function(data) {
                	LogUtil.logError('RAQService -> getRAQPDFTemplates -> daoFailureCallback');
                	failureCallback(data);
                };
                RAQDAO.getRAQPDFTemplates(daoSuccessCallback,daoFailureCallback);
            };
            raqService.uploadRAQPDFFiles = function(fileContent, customerName, accountName, accountNumber,serviceSuccessCallback,serviceFailureCallback) {          	
                var daoSuccessCallback = function(data) {
                    if (data) {
                        LogUtil.logDebug('RAQService -> uploadRAQPDFFiles : daoSuccessCallback : JSON response is true');
                        serviceSuccessCallback(data); 
                    } else {
                    	LogUtil.logError('RAQService -> uploadRAQPDFFiles : daoSuccessCallback : JSON response failed');
                    	serviceFailureCallback(data);  					
                    }
                };               
                var daoFailureCallback = function(data) {
                	LogUtil.logError('RAQService -> uploadRAQPDFFiles : daoFailureCallback');
                	serviceFailureCallback(data);    
                };
                RAQDAO.uploadRAQPDFFiles(fileContent, customerName, accountName, accountNumber,daoSuccessCallback, daoFailureCallback);
            };    
            raqService.saveRAQResult= function(data,successCallback,failureCallback) {
           	 LogUtil.logDebug('RAQService -> saving RAQResult' );
                var daoSuccessCallback = function() {
                    LogUtil.logDebug('RAQService -> saveRAQResult Sucess');
                    successCallback();
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('RAQService -> saveRAQResult Failure');
                    failureCallback();
                };
                RAQDAO.saveRAQResult(data,daoSuccessCallback,daoFailureCallback); 
           };
            raqService.deleteStoredRAQResult= function(id,successCallback, failureCallback) {
           	 LogUtil.logDebug('delete RAQResult' );
                var daoSuccessCallback = function(result) {
                    LogUtil.logDebug('RAQService -> deleteStoredRAQResult Sucess');
                    successCallback(result);
                };
                var daoFailureCallback = function(errObj) {
                    LogUtil.logError('RAQService -> deleteStoredRAQResult Failure');
                    failureCallback(errObj);
                };
                RAQDAO.deleteStoredRAQResult(id,daoSuccessCallback,daoFailureCallback); 
           };
            return raqService;
        }
    ]);
});

