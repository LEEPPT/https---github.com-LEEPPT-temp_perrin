define([
  'app/app',
  'js/Util/DataPersister',
  'js/Util/LogUtil',
  'js/Util/CommonUtil',
  'js/Adapters/RAQAdapter',
  'js/appState',
  'js/appConfig',
  'js/Adapters/SystemParamAdapter'
], function (app,DataPersister,LogUtil,CommonUtil,RAQAdapter,AppState,AppConfig,SystemParamAdapter) {
  'use strict';
  app.factory('RAQDAO', function(){
	  var dao = {};
	  var _data =[];
	
	  dao.getRAQConfigData = function(successCallback, failureCallback) {
		  var adapterSuccessCallback = function(data) {
	            if (data && data.responseJSON) {
	            	DataPersister.setAppDataByNameValue('raqConfig',data.responseJSON);
	            	AppState.raqConfig = CommonUtil.prepareRAQConfig(data.responseJSON);
	            	LogUtil.logInfo('RAQDAO :adapterSuccessCallback : JSON response is true');
	                successCallback(data.responseJSON);
	            } else {
	                LogUtil.logError('RAQDAO : adapterSuccessCallback  : JSON response is false');
	                failureCallback(data);
	            }
	        };	        
	       var adapterFailureCallback = function(data) {
	            LogUtil.logError('RAQDAO : getRAQConfigData : adapterFailureCallback  : Fail to invoke RAQAdapter');
	            failureCallback(data);
	        };
	        
	        if(AppState.raqConfig!==null){
	        	LogUtil.logDebug('DEBUG: getRAQConfigData from local cache');
	        	successCallback(AppState.raqConfig);
	        }else{
	        	DataPersister.getAppDataByNameValue('raqConfig',
	                   function (value) {
	                      LogUtil.logDebug('DEBUG: getRAQConfigData from local storage '+ value);
	                      if (typeof value === 'undefined' || value === 'null' || value===null) {
	                        LogUtil.logDebug('DEBUG: No RAQConfig is defined.');
	                        RAQAdapter.getRAQConfigurations(AppState.userID,adapterSuccessCallback,adapterFailureCallback);
	                        
	                      } else {
	                    	  AppState.raqConfig = CommonUtil.prepareRAQConfig(value);
	                    	  successCallback(AppState.raqConfig);
	                      }
	                  },
	                  function(errorObject){
	                	  LogUtil.logDebug('DEBUG: No RAQConfig is defined.');
	                	  RAQAdapter.getRAQConfigurations(AppState.userID,adapterSuccessCallback,adapterFailureCallback);
	                  });
	        }
	  };	
	  
	  dao.getRAQPDFTemplates = function(successCallback,failureCallback) {
		  
		  var adapterSuccessCallback = function(data) {
	            if (data && data.responseJSON && data.responseJSON.resultList && data.responseJSON.resultList.length > 0) {
	            	LogUtil.logInfo('RAQDAO -> getRAQPDFTemplates -> adapterSuccessCallback: found pdf template');
	            	AppState.raqPDFTemplate = data.responseJSON.resultList;
	                successCallback(data.responseJSON.resultList);
	            } else {
	                LogUtil.logError('RAQDAO ->getRAQPDFTemplates -> adapterSuccessCallback: no pdf template is found');
	                failureCallback(data);
	            }
	        };	 
	       var adapterFailureCallback = function(data) {
	            LogUtil.logError('RAQDAO ->getRAQPDFTemplates -> adapterSuccessCallback : Fail to invoke RAQAdapter');
	            failureCallback(data);
	        };
	        var fullFileList=AppConfig.systemParam.raqInfo.fileList; 
	        if(AppState.raqPDFTemplate!==null && AppState.raqPDFTemplate.length>0){
	        	LogUtil.logDebug('RAQDAO ->getRAQPDFTemplates from local cache');
	        	successCallback(AppState.raqPDFTemplate);
	        }else{
	        	DataPersister.getAppDataByNameValue('raqPDFTemplate',
	                   function (value) {
	                      if (typeof value === 'undefined' || value === 'null' || value===null||value.length===0) {
	                        LogUtil.logDebug('RAQDAO -> getRAQPDFTemplates : no template is found from local storage.');
	                        RAQAdapter.getRAQPDFTemplates(AppState.userID,fullFileList,adapterSuccessCallback,adapterFailureCallback);
	                        
	                      } else {
	                    	  AppState.raqPDFTemplate = value;
	                    	  LogUtil.logDebug('RAQDAO -> getRAQPDFTemplates : '+ value.length +' template is found from local storage.');
	                    	  successCallback(AppState.raqPDFTemplate);
	                      }
	                  },
	                  function(errorObject){
	                	  LogUtil.logDebug('RAQDAO -> getRAQPDFTemplates : no template is defined in local storage.');
	                	  RAQAdapter.getRAQPDFTemplates(AppState.userID,fullFileList,adapterSuccessCallback,adapterFailureCallback);
	                  });
	        }
	  };
	  
	  dao.uploadRAQPDFFiles=function(fileContent, customerName, accountName, accountNumber,successCallback, failureCallback){
		  var adapterSuccessCallback = function(data) {
	            if (data && data.responseJSON) {
	            	
	            	LogUtil.logInfo('RAQDAO :adapterSuccessCallback : uploadRAQPDFFiles success');
	                successCallback(data.responseJSON);
	            } else {
	                LogUtil.logError('RAQDAO : adapterSuccessCallback  : uploadRAQPDFFiles success');
	                failureCallback(data);
	            }
	        };	 	       
	       var adapterFailureCallback = function(data) {
	            LogUtil.logError('RAQDAO : uploadRAQPDFFiles : adapterFailureCallback  : Fail to invoke RAQAdapter');
	            failureCallback(data);
	        };
	        RAQAdapter.uploadRAQPDFFiles(AppState.userID,fileContent, customerName, accountName, accountNumber,adapterSuccessCallback, adapterFailureCallback);
		  
 
	  };

	  var setJSONStoreData = function(data, successCB, failureCB) {
		  DataPersister.setAppDataByNameValue('storedRAQResult', data, successCB, failureCB);
	  };
	  
	  dao.saveRAQResult=function(data,successCallback, failureCallback) {		 
		  var now = Date.now();
		  var raqdata;
		  //add timestamp as id 
		  if (typeof data === 'object' && !Array.isArray(data)) {
			  raqdata = data;
			  raqdata.id = now;
			  raqdata.lastModifiedDate = now;
		  } else {
			  raqdata = {
				id : now,
				data : data,
				lastModifiedDate : now
			  }; 
		  }	
		  AppState.tmpRAQResult=raqdata;
		  AppState.storedRAQResult.unshift(raqdata);
		  DataPersister.setAppDataByNameValue('storedRAQResult',AppState.storedRAQResult,function(result) {
			  LogUtil.logDebug('RAQDAO:insert RAQResult to JSONStore successful,');
			  successCallback(result);
		  }, function(errObj) {
			  LogUtil.logError('RAQDAO:Failed inserting tmpRAQResult to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  });
	  };

	  dao.deleteStoredRAQResult=function(id,successCallback, failureCallback) {		 
		  var index = -1;
		  for (var i = 0 ; i <AppState.storedRAQResult.length ; i++) {
			  if (AppState.storedRAQResult[i].id == id) {
				  index = i;
			  }
		  }
		  if (index > -1) {
    		  LogUtil.logDebug('Number of storedRAQResult in memory BEFORE deletion: '+AppState.storedRAQResult.length);
			  AppState.storedRAQResult.splice(index,1);
    		  LogUtil.logDebug('Number of RAQ in memory AFTER deletion: '+AppState.storedRAQResult.length);
			  DataPersister.setAppDataByNameValue('storedRAQResult',AppState.storedRAQResult, function(result) {
				  LogUtil.logDebug('RAQDAO:insert tmpRAQResult to JSONStore successful,');				  
				  successCallback(result);
			  }, function() {
				  LogUtil.logError('RAQDAO:Failed inserting tmpRAQResult to JSONStore: ['+errObj+']');
	    		  failureCallback(errObj);
			  });
		  } else {
    		  LogUtil.logDebug('No RAQResult is deleted because if no matching id: '+id);
			  failureCallback({msg : 'Cannot find RAQResult of this ID'});
		  }
	  };
	  return dao;
  });
});

