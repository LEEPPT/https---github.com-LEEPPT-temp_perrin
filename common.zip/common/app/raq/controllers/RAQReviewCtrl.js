define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService'
], function(LogUtil, app, AppState, Constants, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQReviewCtrl
     * @param $scope {service} controller scope
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @param $translate {service} i18n handling
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param $ionicScrollDelegate {service} for control scroll views 
     * @description 
     *   Controller for RAQ answers review  Page
     */
    app.controller('RAQReviewCtrl', [
        '$scope',
        '$translate',
        '$stateParams',
        '$ionicScrollDelegate',
        '$state',
        'RAQService',
        function($scope, $translate, $stateParams, $ionicScrollDelegate, $state, RAQService) {        	
	        	/**
	    	     * Initialization function of RAQReviewCtrl
	    	     * @memberof RAQReviewCtrl
	    	     * @function init
	    		 * @description retrieve temporary RAQ data from app storage and get parameters from RAQQuestionsCtrl
	    	     */
        	$scope.init= function(){
        		$scope.userChoices = angular.fromJson($stateParams.userChoices.split(','));            
                $scope.customerType = $stateParams.customerType;
                $scope.miscList=AppState.raqConfig.miscList;  
                $scope.raqVersion = $scope.miscList.get($scope.customerType).version;
                $scope.customerInput = angular.fromJson($stateParams.customerInput);
                $scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.questionnameList = $scope.generalInfo.questionnameList;
                $scope.reviewData = [];
                $scope.cumulativeScore = 0;
                $scope.scorerule = [];
                $scope.userchoiceID = [];
                $scope.userchoiceScore = [];
                $scope.flagLevelChg = false;
                if (AppState.tmpRAQResult.optionID) {
                    $scope.userChoices = AppState.tmpRAQResult.optionID;
                } else {
                    $scope.userChoices = angular.fromJson($stateParams.userChoices.split(','));
                    LogUtil.logDebug("RAQReviewCtrl -> init: userChoices " + $scope.userChoices);
                }
                $scope.isbottom = 0;               
                $scope.questionData = AppState.raqConfig.contentList.get(AppState.currentLangCode+'_'+$scope.customerType.toUpperCase()).questionList;
                $scope.scorerule = AppState.raqConfig.scoreMatrixList.get($scope.customerType.toUpperCase()).scoreRuleList;
                $scope.scorerule_total = $scope.scorerule?$scope.scorerule.length:null;
                $scope.levelrule = AppState.raqConfig.scoreMatrixList.get($scope.customerType.toUpperCase()).levelRuleList;
                $scope.levelrule_total = $scope.scorerule?$scope.levelrule.length:null;
                $scope.classification = AppState.raqConfig.scoreMatrixList.get($scope.customerType.toUpperCase()).classification;
                $scope.level_total = $scope.classification.length;           
                $scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);                  
                $scope.showRAQReviewData();
                $scope.populateInvestmentRestrictions();
                $scope.applyScoreRule();
                $scope.applyLevelRule();
        	};
            
            /**
    	     * invoked before calculation 
    	     * @memberof RAQReviewCtrl
    	     * @function idToindex
    		 * @description turn question ID to index, eg. 8a -> 8, 8b -> 9
    	     */
            $scope.idToindex = function(id) {
                for (var i = 0; i < $scope.questionnameList.length; i++) {
                    if (id == $scope.questionnameList[i]) {
                        return i;
                    }
                }
            };
            
            /**
    	     * display RAQ final options
    	     * @memberof RAQReviewCtrl
    	     * @function showRAQReviewData
    		 * @description push questions and options of user choices, then display data of both English and Chinese version 
    	     */
            $scope.showRAQReviewData = function (){
            	for (var i = 0; i < $scope.userChoices.length; i++) {
                    var userchoice = $scope.userChoices[i];
                    $scope.userchoiceID[i] = $scope.questionData[i].optionList[userchoice].optionID;
                    $scope.userchoiceScore[i] = $scope.questionData[i].optionList[userchoice].score;
                    var questionDataEng = AppState.raqConfig.contentList.get(Constants.LANG_EN+'_'+$scope.customerType.toUpperCase()).questionList;
                    var questionDataChi = [];
                    if (AppState.currentLangCode == Constants.LANG_SC) {  
                    	questionDataChi = AppState.raqConfig.contentList.get(Constants.LANG_SC+'_'+$scope.customerType.toUpperCase()).questionList;
                    } else {
                    	questionDataChi = AppState.raqConfig.contentList.get(Constants.LANG_TC+'_'+$scope.customerType.toUpperCase()).questionList;
                    }
                    	
                    $scope.reviewData.push({
   	                 questionDataEng: questionDataEng[i],                           
   	                 questionDataChi: questionDataChi[i],
   	                 userChoiceID: questionDataEng[i].optionList[userchoice].optionID,
   	                 userChoiceEng: questionDataEng[i].optionList[userchoice].option,                    
   	                 userChoiceChi: questionDataChi[i].optionList[userchoice].option
   	             	});
                }
            };

            /**
    	     * display reviewData according to language change
    	     * @memberof RAQReviewCtrl
    	     * @function watch currentLangCode
    		 * @description check if language changes, then display content according to language.
    		 * If simple chinese, display English and simple Chinese version;
    		 * else, display English and traditional Chinese version;
    	     */
            $scope.$watch('AppState.currentLangCode', function() {
            	$scope.reviewData=[];
            	$scope.showRAQReviewData();
            	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);	
            }, true);

            /**
    	     * invoked by apply rule function
    	     * @memberof RAQReviewCtrl
    	     * @function scoreCal
    		 * @description check parameter of rule category, 
    		 * then apply different calculation methods, calculate score according to rule category
    	     */
            $scope.scoreCal = function(ruleID, ruleCat, questionID, maxscore) {
            	var i;
                if(ruleCat==='applyOptionMinimum') {                   
                        var questionIndexMin = [];
                        var userchoice = [];
                        for (i = 0; i < questionID.length; i++) {
                            questionIndexMin[i] = $scope.idToindex(questionID[i]);
                            userchoice[i] = $scope.userChoices[questionIndexMin[i]];
                        }
                        var minchoice = Math.min(userchoice[0], Number(userchoice[1]));
                        var questionIndex1 = questionIndexMin[0];
                        var questionIndex2 = questionIndexMin[1];
                        var minscore = $scope.questionData[questionIndex1].optionList[minchoice].score + $scope.questionData[questionIndex2].optionList[minchoice].score;
                        LogUtil.logDebug("RAQReviewCtrl -> scoreCal: Question ID: " + questionID + " - score: " + minscore);
                        $scope.cumulativeScore += minscore;
                       
                }else if (ruleCat === 'applyQuestionMaximum') {                    
                        var score_tmp_max = 0;
                        for (i = 0; i < questionID.length; i++) {
                            var questionIndexMax = $scope.idToindex(questionID[i]);
                            if ($scope.userchoiceScore[questionIndexMax] > score_tmp_max) {
                                score_tmp_max = $scope.userchoiceScore[questionIndexMax];
                            }
                        }
                        if (maxscore === null || isNaN(maxscore)) {
                            $scope.maxabcde_score = score_tmp_max;
                        } else {
                            $scope.maxabcde_score = Math.min(parseInt(maxscore), score_tmp_max);
                        }                    
                        LogUtil.logDebug("RAQReviewCtrl -> scoreCal: Question ID: " + questionID + " - score: " + $scope.maxabcde_score);
                        $scope.cumulativeScore = $scope.cumulativeScore + $scope.maxabcde_score;
                }else if (ruleCat === 'default'){                   
                        var questionIndexDe = $scope.idToindex(questionID[0]);
                        $scope.cumulativeScore = $scope.cumulativeScore + $scope.userchoiceScore[questionIndexDe];
                        LogUtil.logDebug("RAQReviewCtrl -> scoreCal: Question ID: " + questionID + " - score: " + $scope.userchoiceScore[questionIndexDe]);
                }
            };
            
            /**
    	     * invoked by apply rule function
    	     * @memberof RAQReviewCtrl
    	     * @function applyScoreRule
    		 * @description get rules, conditions. 
    		 * if condition is true, get rule category and apply them according to question ID
    	     */
           $scope.applyScoreRule=function(){           
               LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule");
               for (var j = 0; j < $scope.scorerule_total; j++) {
               	   var a = 1;
                   var b = 2;
                   var c = 3;
                   var d = 4;
                   var e = 5;
                   if (($scope.scorerule[j].condition) != null) {
                       var conditiontmp = [];
                       conditiontmp = $scope.scorerule[j].condition;
                       var is_condition = "";
                       for (var m = 0; m < conditiontmp.length; m++) {
                           if (isNaN(conditiontmp[m])) {
                               is_condition = is_condition + conditiontmp[m];
                           } else {
                               var questionIndex = $scope.idToindex(conditiontmp[m]);
                               is_condition = is_condition + $scope.userchoiceID[questionIndex];
                           }
                       }
                       if (eval(is_condition)) {
                           //apply rule
                           if ($scope.scorerule[j].result.category == "applyQuestionMaximum") {
                               LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule: applyQuestionMaximum rule for Rule ID " + $scope.scorerule[j].ruleID + " in Question ID " + $scope.scorerule[j].result.questionID + " is applied");
                               $scope.scoreCal($scope.scorerule[j].ruleID, $scope.scorerule[j].result.category, $scope.scorerule[j].result.questionID, $scope.scorerule[j].result.maxScore);
                           } else {
                               LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule: applyQuestionMaximum rule for Rule ID " + $scope.scorerule[j].ruleID + " in Question ID " + $scope.scorerule[j].result.questionID + " is not applied");
                           }
                       } else {
                           LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule: applyQuestionMaximum rule for Rule ID " + $scope.scorerule[j].ruleID + " in Question ID " + $scope.scorerule[j].result.questionID + " is not applied");
                       }
                   } else if ($scope.scorerule[j].result.category == "applyOptionMinimum") {
                       LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule: applyOptionMinimum rule for Rule ID " + $scope.scorerule[j].ruleID + " in Question ID " + $scope.scorerule[j].result.questionID + " is applied");
                       $scope.scoreCal($scope.scorerule[j].ruleID, $scope.scorerule[j].result.category, $scope.scorerule[j].result.questionID, null);
                   } else {
                       LogUtil.logDebug("RAQReviewCtrl -> applyScoreRule: default rule for Rule ID " + $scope.scorerule[j].ruleID + " in Question ID " + $scope.scorerule[j].result.questionID + " is applied");
                       $scope.scoreCal($scope.scorerule[j].ruleID, $scope.scorerule[j].result.category, $scope.scorerule[j].result.questionID, null);
                   }

               }
               	
           };
           
           $scope.applyLevelRule=function(){
        	   LogUtil.logDebug("RAQReviewCtrl -> applyLevelRule");
        	   for (var k = 0; k < $scope.level_total; k++) {
        		   if (parseInt($scope.classification[k].fromScore) <= $scope.cumulativeScore && $scope.cumulativeScore <= parseInt($scope.classification[k].toScore)) {
        			   $scope.riskToleranceLevel = $scope.classification[k].level;
        			   break;
        		   }
        	   }           		
        	   for (var j = 0; j < $scope.levelrule_total; j++) {
        		   var a = 1;
        		   var b = 2;
        		   var c = 3;
        		   var d = 4;
        		   var e = 5;
        		   if (($scope.levelrule[j].condition) != null) {
        			   //check rules 
        			   var conditiontmp = [];
        			   conditiontmp = $scope.levelrule[j].condition;
        			   var is_condition = "";
        			   for (var m = 0; m < conditiontmp.length; m++) {
        				   LogUtil.logDebug("conditiontmp[m]: " + conditiontmp[m]);
        				   if (isNaN(conditiontmp[m])) {
        					   is_condition = is_condition + conditiontmp[m];
        				   } else {
        					   var questionIndex = $scope.idToindex(conditiontmp[m]);
        					   is_condition = is_condition + $scope.userchoiceID[questionIndex];
        					   LogUtil.logDebug("questionIndex: " + questionIndex);
        					   LogUtil.logDebug("$scope.userchoiceID[questionIndex]: " + $scope.userchoiceID[questionIndex]);
        				   }
        			   }
        			   LogUtil.logDebug("RAQReviewCtrl -> applyLevelRule: condition " + is_condition);
        			   if (eval(is_condition)) {
        				   if ($scope.levelrule[j].result.category == "applyLevelMaximum" && parseInt($scope.levelrule[j].result.maxLevel) < parseInt($scope.riskToleranceLevel)) {
        					   //override level
        					   $scope.flagLevelChg = true;
        					   LogUtil.logDebug("RAQReviewCtrl -> applyLevelRule: Rule ID: " + $scope.levelrule[j].ruleID + " Need to override risk tolerance level from " + $scope.riskToleranceLevel + " to " + $scope.levelrule[j].result.maxLevel);
        					   $scope.invalidRiskToleranceLevel = $scope.riskToleranceLevel;
        					   $scope.riskToleranceLevel = $scope.levelrule[j].result.maxLevel;
        					   $scope.causeChgQuestions = [];
        					   $scope.causeChgChoice = '';

        					   for (var m = 0; m < conditiontmp.length; m++) {
        						   if (!isNaN(conditiontmp[m])) {
        							   var questionIndex = $scope.idToindex(conditiontmp[m]);
        							   $scope.causeChgQuestions.push(conditiontmp[m]);
        							   if ($scope.userchoiceID[questionIndex]==conditiontmp[m+2]){
        								   $scope.causeChgChoice=conditiontmp[m+2];                                        	   
        							   }
        						   } 
        					   }
        				   } else {
        					   LogUtil.logDebug("RAQReviewCtrl -> applyLevelRule: Rule ID: " + $scope.levelrule[j].ruleID + " No need to override - hit the rule but risk matches");
        				   }
        			   } else {
        				   LogUtil.logDebug("RAQReviewCtrl -> applyLevelRule: Rule ID: " + $scope.levelrule[j].ruleID + " No need to override - does not hit the rule");
        			   }
        		   }
        	   }
           };
           
	         /**
	   	     * Event trigger by scrolling down the page
	   	     * @memberof RAQReviewCtrl
	   	     * @function checkScroll
	   		 * @description calculate the distance to top, then justify whether scroll down to the bottom 
	   	     */
            $scope.checkScroll = function() {
                var distance_top = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollPosition().top;
                var max_Scrollheight = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollView().__maxScrollTop;
                if (distance_top >= max_Scrollheight) {
                    $scope.isbottom = 1;
                }
                $scope.$apply();
            };

            /**
       	     * Event trigger by clicking edit button in front of each question
       	     * @memberof RAQReviewCtrl
       	     * @function gobackQuestions
       		 * @description get the question ID,
       		 * direct to the question that customer want to modify 
       	     */
            $scope.gobackQuestions = function(id) {
                $scope.modifyID = id;
                var param = {
                    customerType: $scope.customerType,
                    customerInput: angular.toJson($scope.customerInput),
                    initialID: $scope.modifyID,
                    userChoices: $scope.userChoices
                };
                $state.go('base.raq_questions', param, {
                    reload: true
                });
            };
            
            /**
             * Event trigger when click submit button
    	     * @memberof RAQQuestionsCtrl
    	     * @function goInvestmentRestrictions
    		 * @description passing parameters and direct to investment restrictions page
             */
            $scope.goInvestmentRestrictions = function() {
            	LogUtil.logInfo("RAQReviewCtrl -> goInvestmentRestrictions");
            	var generalInfo = {
            		questionnameList: $scope.questionnameList,
            	};
            	var param = {
            		generalInfo: angular.toJson(generalInfo),
            		userChoices: $scope.userChoices,
            		customerType: $scope.customerType,
            		customerInput: angular.toJson($scope.customerInput)
            	};
            	$state.go('base.raq_investment_restrictions', param, {
            		reload: true
            	});
            };

            /**
    	     * Event trigger by click submit button
    	     * @memberof RAQReviewCtrl
    	     * @function goResultshow 
    		 * @description passing parameters and direct to result display page
    	     */
            $scope.goResultshow = function() {
         	    LogUtil.logDebug("RAQReviewCtrl -> goResultshow: userChoiceID " + $scope.userchoiceID);
         	    var data = AppState.tmpRAQResult;
                data.optionID = $scope.userChoices;
                AppState.tmpRAQResult = data;  
                LogUtil.logDebug("RAQReviewCtrl -> goResultshow: cumulativeScore " + $scope.cumulativeScore);
                LogUtil.logDebug("RAQReviewCtrl -> goResultshow: riskToleranceLevel " + $scope.riskToleranceLevel);

                var generalInfo = {
                    questionnameList: $scope.questionnameList,
                    raqVersion : $scope.raqVersion
                };
                
                LogUtil.logDebug("RAQReviewCtrl -> goResultshow: flagLevelChg " + $scope.flagLevelChg);
                if ($scope.flagLevelChg == true) {                
                	var customerInfo = {
                			flagLevelChg:$scope.flagLevelChg,
                			invalidRiskToleranceLevel:$scope.invalidRiskToleranceLevel,
                			causeChgQuestions:$scope.causeChgQuestions,
                			causeChgChoice:$scope.causeChgChoice,
                            cumulativeScore: $scope.cumulativeScore,
                            riskToleranceLevel: $scope.riskToleranceLevel,
                            customerType: $scope.customerType,
                            customerInput: $scope.customerInput,
                            optionID: $scope.userchoiceID
                        };                	
                } else{
                	var customerInfo = {
                            cumulativeScore: $scope.cumulativeScore,
                            riskToleranceLevel: $scope.riskToleranceLevel,
                            customerType: $scope.customerType,
                            customerInput: $scope.customerInput,
                            optionID: $scope.userchoiceID
                    };                	
                }
                

                var param = {
                    generalInfo: angular.toJson(generalInfo),
                    customerInfo: angular.toJson(customerInfo)
                }; 
                
               
                $state.go('base.raq_result', param, {
                        reload: true
                    });
                
                
            };
            
            $scope.populateInvestmentRestrictions = function () {
            	$scope.iRQuestionEng = $translate.instant('RAQ_IR_QUESTION_ENG');
            	$scope.iRQuestionChi = $translate.instant('RAQ_IR_QUESTION_CHI');
            	if ($scope.customerInput) {
            		if ($scope.customerInput.isIRSelected === 'y') {
            			$scope.iRAnswerEng = $translate.instant('RAQ_IR_OPTION_YES_ENG');
                    	$scope.iRAnswerChi = $translate.instant('RAQ_IR_OPTION_YES_CHI');
                    	$scope.iRAnswerHeadingEng = $translate.instant('RAQ_IR_ANSWER_HEADING_ENG');
                    	$scope.iRAnswerHeadingChi = $translate.instant('RAQ_IR_ANSWER_HEADING_CHI');
                    	$scope.iRAnswer = $scope.customerInput.iRAnswer;
            		} else if ($scope.customerInput.isIRSelected === 'n') {
            			$scope.iRAnswerEng = $translate.instant('RAQ_IR_OPTION_NO_ENG');
                    	$scope.iRAnswerChi = $translate.instant('RAQ_IR_OPTION_NO_CHI');
            		}
            	}
            }
            
            $scope.init();
        }
    ]);
});