define([
    'app/app',
    'js/Util/DataPersister',
    'js/appState',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'app/raq/services/RAQService',
	'js/constants',
    'js/Util/FunctionActivator',
    'js/Util/Validation',
    'js/Util/AuditLoggingUtil'
], function(app, DataPersister, AppState, LogUtil, CommonUtil, RAQService, Constants, FunctionActivator,Validation,AuditLoggingUtil){
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQMainCtrl
     * @param $scope {service} controller scope
     * @param $translate {service} i18n handling     
     * @param $filter {service} for data formating
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @param $ionicModal {service} for display temporary views
     * @param $state {service} for store data in appState
     * @param $ionicHistory {service} for backFlow
     * @param $stateParams{service} for passing parameters between controllers 
     * @description 
     * Controller for RAQ Main List Page
     */
    app.controller('RAQMainCtrl', [
        '$scope',
        '$translate',
        '$filter',
        'RAQService',
        '$ionicModal',
        '$state',
        '$ionicHistory',
        '$stateParams',
        function($scope, $translate, $filter,RAQService,$ionicModal,$state, $ionicHistory,$stateParams) {
        	/**
    	     * Initialization function of RAQMainCtrl
    	     * @memberof RAQMainCtrl
    	     * @function init
    		 * @description retrieve stored RAQ data from Local storage and display
    	     */
        	$scope.init = function() {
    			LogUtil.logInfo("RAQMainCtrl -> init");

        		$scope.isNewRAQReady = false;
        		$scope.data=angular.fromJson( );
            	$scope.isSidePanelActivated = false;
            	$scope.portfoliosLength = 0;
            	$scope.levelList=[];
            	busyIndicator.show();
        		RAQService.getRAQConfig(this.getRAQConfigSuccessCallback,this.getRAQConfigFailureCallback);
            	if (FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_RAQ) === false) {
                	FunctionActivator.showAccessDeniedMessage($ionicHistory);
                	return;
        		}   
        		$scope.activatedPortfolioIndex = -1;
        		$scope.RAQListContainer = $(".panning-container > .panning-column");
        		$scope.sidePanelContainer = $(".side-panel");
            	$scope.transitionTypes = {
    					'transition':'transitionend',
    					'OTransition':'oTransitionEnd',
    					'MozTransition':'transitionend',
    					'WebkitTransition':'webkitTransitionEnd'
    			};
    			$scope.transitionKey = '';         		        		
        		for (var t in $scope.transitionTypes){
        			if ($scope.sidePanelContainer[0].style[t] !== undefined) {
        				$scope.transitionKey = t;
        				break;
        			}
        		}       			            
        	};

    		/**
    	     * Success callback function for getting RAQConfig 
    	     * @memberof RAQMainCtrl
    	     * @function getRAQConfigSuccessCallback
    		 * @description try to get relative data after SuccessCallback with RAQConfig data
    	     */        	
            $scope.getRAQConfigSuccessCallback = function(data) {
        		LogUtil.logDebug('RAQMainCtrl -> getRAQConfigSuccessCallback');          	
            	$scope.levelMap=data.levelList; 
            	$scope.levelList=$scope.levelMap.get(AppState.currentLangCode);
            	$scope.getRAQPDFTemplates();
    		}; 
    		
            /**
    	     * get levelList content according to language change
    	     * @memberof RAQMainCtrl
    	     * @function watch currentLangCode
    		 * @description get levelList content according to the current language when language changes
    	     */
        	$scope.$watch('AppState.currentLangCode',function(){
	        		$scope.levelList=$scope.levelMap.get(AppState.currentLangCode);
			},true); 
        	
    		/**
    	     * Failure callback function for getting RAQConfig
    	     * @memberof RAQMainCtrl
    	     * @function getRAQConfigFailureCallback
    		 * @description try to find cause of failure, display error message
    	     */
    		$scope.getRAQConfigFailureCallback = function(data) {
    			LogUtil.logError('RAQMainCtrl -> getRAQConfigFailureCallback ');
    			busyIndicator.hide();
    			var errorCode = '';
                var errorMsg = '';
                var errorTitle = '';
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE');
                    errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE') + errorCode;
                    LogUtil.logError('RAQMainCtrl -> getRAQConfigFailureCallback : errorCode - ' + errorCode);
                    CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure  - Error returned from ZPB',errorTitle,errorMsg,false);                    
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('RAQMainCtrl -> getRAQConfigFailureCallback : Network Info - '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION');
			  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - No internet connection',errorTitle,errorMsg,false);
			  			}else{
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE');
			  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
			  			}		                
			  		});
                }   			
            };
            
    		/**
    	     * get Templates for generating RAQ PDF
    	     * @memberof RAQMainCtrl
    	     * @function getRAQPDFTemplates 
    		 * @description getting Templates for generating RAQ PDF via RAQService
    	     */
            $scope.getRAQPDFTemplates = function (){
            	RAQService.getRAQPDFTemplates(this.getRAQPDFTemplatesSuccessCallback,this.getRAQPDFTemplatesFailureCallback);
            };
            
    		/**
    	     * Success callback function for getRAQPDFTemplates
    	     * @memberof RAQMainCtrl 
    	     * @function getRAQPDFTemplatesSuccessCallback
    		 * @description log get RAQPDFTemplates Success info
    	     */
            $scope.getRAQPDFTemplatesSuccessCallback = function(data) {
            	LogUtil.logDebug('RAQMainCtrl -> getRAQPDFTemplatesSuccessCallback ');
            	busyIndicator.hide();
            	$scope.isNewRAQReady = true;       	
    		}; 
    		/**
    	     * Failure callback function for getRAQPDFTemplates
    	     * @memberof RAQMainCtrl
    	     * @function getRAQPDFTemplatesFailureCallback
    		 * @description try to find cause of error,display error message
    	     */
    		$scope.getRAQPDFTemplatesFailureCallback = function(data) {
    			busyIndicator.hide();
    			LogUtil.logError('RAQMainCtrl -> getRAQPDFTemplatesFailureCallback ');
    			var errorCode = '';
                var errorMsg = '';
                var errorTitle = '';
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE');
                    errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE') + errorCode;
                    LogUtil.logError('RAQMainCtrl -> getRAQPDFTemplatesFailureCallback : errorCode - ' + errorCode);
                    CommonUtil.handleAppError('Retrieve RAQ PDF Templates failure  - Error returned from ZPB',errorTitle,errorMsg,false);
                    
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('RAQMainCtrl -> getRAQPDFTemplatesFailureCallback : Network Info - '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION');
			  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates and scoring matrix failure - No internet connection',errorTitle,errorMsg,false);
			  			}else{
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE');
			  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates and scoring matrix failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
			  			}  
			  		});
                }
            };
            
            /**
    	     * get storedRAQResult from local storage
    	     * @memberof RAQMainCtrl
    	     * @function loadStoredRAQ
    		 * @description load Stored RAQ from AppState, format Date for display 
    	     */
        	$scope.loadStoredRAQ = function(){
	            LogUtil.logDebug('RAQMainCtrl -> loadStoredRAQ');
	            var storedRAQResult = AppState.storedRAQResult;
	            for (var i = 0; storedRAQResult && i < storedRAQResult.length; i++) {
	            	if (storedRAQResult[i].lastModifiedDate) {
	            		storedRAQResult[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedRAQResult[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('RAQMainCtrl -> loadStoredRAQ : storedRAQResult  ' + storedRAQResult[i].id + ', displayDate: ' + storedRAQResult[i].displayDate);
	            	}else {
	            		storedRAQResult[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedRAQResult[i].id),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('RAQMainCtrl -> loadStoredRAQ : storedRAQResult  ' + storedRAQResult[i].id + ', displayDate: ' + storedRAQResult[i].displayDate);
	            	}
	            }
            	$scope.storedRAQResult = storedRAQResult;
        	};
        	
            /**
    	     * get submitModal for success view display
    	     * @memberof RAQMainCtrl
    	     * @function ionicModal fromTemplateUrl
    		 * @description read the submitModal Template according to url for pdf upload success information display
    	     */        	
        	$ionicModal.fromTemplateUrl('./app/raq/templates/raq_submit_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
        	
        	 /**
    	     * Event trigger by click close button of upload success page
    	     * @memberof RAQMainCtrl
    	     * @function hideOverlay
    		 * @description hide upload success info display 
    	     */
        	$scope.hideOverlay = function() {        		
        		$scope.submitModal.hide();
        		$state.go('base.raq_main', {  	    			
                }, {
                    reload: true
                });
        	};
        	
    		/**
    	     * Success callback function for uploadRAQPDF
    	     * @memberof RAQMainCtrl
    	     * @function uploadRAQPDFSuccessCallback
    		 * @description will delete related RAQ data without confirmation,
    		 * then show upload success information
    	     */
        	$scope.uploadRAQPDFSuccessCallback = function(data) { 
	            	LogUtil.logDebug('RAQMainCtrl -> uploadRAQ -> uploadRAQPDFSuccessCallback'); 	 
	            	$scope.deleteRAQOnly($scope.deleteId);
			    	$scope.submitModal.show();  			    	
	              };
	              
      		/**
      	     * Failure callback function for uploadRAQPDF
      	     * @memberof RAQMainCtrl
      	     * @function uploadRAQPDFFailureCallback
      		 * @description try to find cause of error,display error message
      	     */	        
	        $scope.uploadRAQPDFFailureCallback = function(data) {
	            	LogUtil.logError('RAQMainCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback'); 
	            	busyIndicator.hide();
	            	if (data && data.responseJSON && data.responseJSON.errorCode) {
                    var errorCode = data.responseJSON.errorCode;
                    LogUtil.logError('RAQMainCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - Error returned from ZPB - ' + errorCode);
                    var errorMsg = $translate.instant('ERR_SUBMIT_RAQ_ZPB_FAILURE')+'-'+errorCode;
                    WL.SimpleDialog.show($translate.instant("ERR_SUBMIT_RAQ_TITLE"), errorMsg, [{text: $translate.instant("BTN_OK"), handler: function() {
	                }}]);
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
                		var errorMsg ='';
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('Network Info : '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				LogUtil.logError('RAQMainCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - No internet connection');
			  				errorMsg = $translate.instant('ERR_SUBMIT_RAQ_INTERNET_CONNECTION');
			  			}else{
			  				LogUtil.logError('RAQMainCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - MobileFirst server connection failure');
			  				errorMsg = $translate.instant('ERR_SUBMIT_RAQ_MFP_CONNECTION_FAILURE');
			  			}
			  			WL.SimpleDialog.show($translate.instant("ERR_SUBMIT_RAQ_TITLE"), errorMsg, [{text: $translate.instant("BTN_OK"), handler: function() {        	                	
    	                }}]);
   			  		});
                } 	            	
	         }; 	
	         
        	 /**
	    	     * Event trigger when click upload button at the bottom of side panel 
	    	     * @memberof RAQMainCtrl
	    	     * @function uploadRAQ
	    		 * @description call uploadRAQPDFFiles function of RAQService and upload stored RAQ pdf according to id, 
	    		 * if succeed, call uploadRAQPDFSuccessCallback; else call uploadRAQPDFFailureCallback
	    	     */ 
        	 $scope.uploadRAQ = function(id) {  
     			LogUtil.logInfo("RAQMainCtrl -> uploadRAQ");

        		busyIndicator.show();
 	            var pdfdata= $scope.storedRAQResult[id].generatedPdf;
 	            var accountName=$scope.storedRAQResult[id].accountName;
 				var accountNumber=$scope.storedRAQResult[id].accountNumber;
 				var customerName =$scope.storedRAQResult[id].customerName;
 				$scope.deleteId=$scope.storedRAQResult[id].id;			
 				
 	            RAQService.uploadRAQPDFFiles(pdfdata,customerName, accountName, accountNumber,this.uploadRAQPDFSuccessCallback,this.uploadRAQPDFFailureCallback);
 	            var auditLogInfo = {
 	                    userID: AppState.userID,
 	                    activity: 'submit_raq',
 	                    customerName: customerName,
 	                    accountName: accountName,
 	                    accountNumber: accountNumber
 	                };
 	            AuditLoggingUtil.insertAuditLogging(auditLogInfo);
         	};
         	
         	/**
    	     * Event trigger when click create button  
    	     * @memberof RAQMainCtrl
    	     * @function createNewRAQ
    		 * @description clear tmpRAQResult, check if system is ready for new RAQ.
    		 * if ready, go to customer type page; else handleAppError
    	     */ 
         	$scope.createNewRAQ = function() {
    			LogUtil.logInfo("RAQMainCtrl -> createNewRAQ");

         		var tmp=AppState.tmpRAQResult.rmRINumber;
        		AppState.tmpRAQResult={};
 	            AppState.tmpRAQResult.rmRINumber=tmp;
 	            if($scope.isNewRAQReady){
		 	        $state.go('base.raq_select_customer_type', {    	    			
		               }, {
		                   reload: true
		               });
 	            }else {
 	            	var errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_TITLE');
	  				var errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT');
	  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates and scoring matrix failure -- createNewRAQ',errorTitle,errorMsg,false);
 	            }
  	    	};
  	    	
  	    	/**
    	     * Event trigger when click delete button of RAQ items displayed on the list
    	     * @memberof RAQMainCtrl
    	     * @function deleteRAQ
    		 * @description display ConfirmBox. If confirmed, delete relative data in local storage
    	     */
        	$scope.deleteRAQ = function(id) {  
    			LogUtil.logInfo("RAQMainCtrl -> deleteRAQ - id: "+id);

        		var _this = this;
        		CommonUtil.displayConfirmBox($translate.instant("CONF_DELETE_RAQ_TITLE"), $translate.instant("CONF_DELETE_RAQ"), $translate.instant("BTN_OK"), function() {
        			busyIndicator.show();
        			RAQService.deleteStoredRAQResult(id,_this.deleteRAQSuccessCallback,_this.deleteRAQFailureCallback);					
        		}, $translate.instant("BTN_CANCEL"), function() {
        			// Dismiss confirm box
        		});
        	};  
        	
  	    	/**
    	     * Event trigger when RAQ pdf upload successfully
    	     * @memberof RAQMainCtrl
    	     * @function deleteRAQOnly
    		 * @description will not display ConfirmBox, delete RAQ data with no confirmation
    	     */
			$scope.deleteRAQOnly = function(id) {	
    			LogUtil.logInfo("RAQMainCtrl -> deleteRAQOnly - id: "+id);

				busyIndicator.show();
    			RAQService.deleteStoredRAQResult(id,this.deleteRAQSuccessCallback,this.deleteRAQFailureCallback);						
			}; 	
      		/**
      	     * Success callback function for delete RAQ
      	     * @memberof RAQMainCtrl
      	     * @function deleteRAQSuccessCallback
      		 * @description try to update the remain RAQ data and display the list 
      	     */	
        	$scope.deleteRAQSuccessCallback = function(result) {
        		LogUtil.logDebug('RAQMainCtrl -> deleteRAQSuccessCallback');
        		$scope.$apply(function() {
        			$scope.storedRAQResult =  result;
        			busyIndicator.hide();
        		});
        	}; 
        	
      		/**
      	     * Failure callback function for delete RAQ
      	     * @memberof RAQMainCtrl
      	     * @function deleteRAQFailureCallback
      		 * @description log error info, the remain RAQ data will not change
      	     */	
        	$scope.deleteRAQFailureCallback = function(errObj) {
        		LogUtil.logError('RAQMainCtrl -> deleteRAQFailureCallback');
        		WL.SimpleDialog.show($translate.instant('ERR_DELETE_RAQ'),$translate.instant('ERR_DELETE_RAQ_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
    			busyIndicator.hide();
        	};

  	    	/**
    	     * Event trigger invoked by showHideRAQResult function
    	     * @memberof RAQMainCtrl
    	     * @function modifySidePanel
    		 * @description show or hide side Panel with relative position change 
    	     */
        	$scope.modifySidePanel = function(_action,_index){
        		switch(_action) {
        			case 'hide':
        				LogUtil.logDebug('RAQMainCtrl -> modifySidePanel : hide side panel');        				
        				$scope.sidePanelContainer.on($scope.transitionTypes[$scope.transitionKey], function(_e){
        					$scope.activatedPortfolioIndex = -1;
        					$(this).off(_e); 
        				});
        				$scope.RAQListContainer.removeClass('pan-left-25');
        				$scope.sidePanelContainer.addClass('panel-hide');
        				this.isSidePanelActivated = false;
        			break;
        			case 'show':
        				LogUtil.logDebug('RAQMainCtrl -> modifySidePanel : show side panel');
            			$scope.activatedPortfolioIndex = _index;
            			LogUtil.logDebug('levelList'+$scope.levelList);
            			if($scope.storedRAQResult[$scope.activatedPortfolioIndex].newRiskToleranceLevel){
                			$scope.level=$scope.storedRAQResult[$scope.activatedPortfolioIndex].newRiskToleranceLevel; 
                		}else{
                			$scope.level=$scope.storedRAQResult[$scope.activatedPortfolioIndex].riskToleranceLevel; 
                		}
        				$scope.RAQListContainer.addClass('pan-left-25');
        				$scope.sidePanelContainer.removeClass('panel-hide');
        				this.isSidePanelActivated = true;
            		break;
        		}
        	};
        	
        	/**
    	     * Event trigger when click side Panel or outside Panel
    	     * @memberof RAQMainCtrl
    	     * @function showHideRAQResult
    		 * @description show or hide side Panel with relative style change for RAQ items on the list
    	     */
        	$scope.showHideRAQResult = function(_evt){  
        		var clickTriggerElement = $(_evt.target),
        			classCheckingString = 'raq-main',
        			isPortfolioClicked = clickTriggerElement.hasClass('button-'+classCheckingString);
        		if (!isPortfolioClicked) {
        			if (this.isSidePanelActivated) {        				
        				this.portfolioButtons.removeClass('selected');
        				$scope.modifySidePanel('hide');
        			}
        			return;
        		}        		
        		var clickTargetId = clickTriggerElement.attr('id'),
        			clickTargetIndex = parseInt(clickTargetId.replace(classCheckingString+'-',''));        		
        		if (this.isSidePanelActivated && $scope.activatedPortfolioIndex == clickTargetIndex) {
        			clickTriggerElement.removeClass('selected');
        			$scope.modifySidePanel('hide');     		
        		} else if (this.isSidePanelActivated && $scope.activatedPortfolioIndex != clickTargetIndex) {
        			this.portfolioButtons.removeClass('selected');
        			clickTriggerElement.addClass('selected');
        			$scope.activatedPortfolioIndex = clickTargetIndex;        			
        		} else if (!this.isSidePanelActivated) {
        			clickTriggerElement.addClass('selected');
        			$scope.modifySidePanel('show',clickTargetIndex);       			
        		}   
        			       		
        	};        	
        	$scope.init();
        	$scope.loadStoredRAQ();
        }
    ]);

    app.directive('onRaqListed',['$timeout',function($timeout) {    	
        return function($scope,element,attrs) {
      	  $timeout(function(){
      		$scope.portfolioButtons = $(".button-raq-main");   
      		$scope.portfoliosLength = $scope.portfolioButtons.length;
      	  },0,false);
        };
    }]);
});