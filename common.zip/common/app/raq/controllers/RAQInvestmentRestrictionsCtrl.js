define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
], function(LogUtil, app, AppState) {
    'use strict';
    app.controller('RAQInvestmentRestrictionsCtrl', [
        '$scope',
        '$stateParams',
        '$ionicScrollDelegate',
        '$state',
        function($scope, $stateParams, $ionicScrollDelegate, $state) {
            /**
             * Initialization function of RAQInvestmentRestrictionsCtrl
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function init
             * @description 
             */
            $scope.init = function() {
                LogUtil.logInfo("RAQInvestmentRestrictionsCtrl -> init");
                $scope.iRData = {};
                $scope.isChecked = 0;
                $scope.isEditingAnswer = false;

                $scope.miscList = AppState.raqConfig.miscList;
                $scope.raqVersion = $scope.miscList.get($stateParams.customerType).version;
                
                if (AppState.tmpRAQResult.isIRSelected) {
                	$scope.iRData.isIRSelected = AppState.tmpRAQResult.isIRSelected;
                }                
                
                if (AppState.tmpRAQResult.iRAnswer) {
                	$scope.iRData.answer = AppState.tmpRAQResult.iRAnswer;
                }
            };

            /**
             * Handle the options checkbox
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function handleCheckbox
             * @description 
             */
            $scope.handleCheckbox = function() {
                if ($scope.isChecked === 0) {
                    $scope.isChecked = 1;
                } else {
                    $scope.isChecked = 0;
                }
            };

            /**
             * Handle scrolling function
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function checkScroll
             * @description 
             */
            $scope.checkScroll = function() {
                var distance_top = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollPosition().top;
                var max_Scrollheight = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollView().__maxScrollTop;
                if (distance_top >= max_Scrollheight) {
                    $scope.isbottom = 1;
                }
                $scope.$apply();
            };
            
            /**
             * When edit button in text area is clicked
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function editAnswer
             * @description 
             */
            $scope.editAnswer = function() {
                $scope.isEditingAnswer = true;
            };

            /**
             * When done button in text area is clicked
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function saveAnswer
             * @description 
             */
            $scope.saveAnswer = function() {
                $scope.isEditingAnswer = false;
            };

            /**
             * When confirm button is clicked to navigate to Result Review Page
             * @memberof RAQInvestmentRestrictionsCtrl
             * @function goResultsReview
             * @description 
             */
            $scope.goResultsReview = function() {
                LogUtil.logInfo("RAQQuestionsCtrl -> goResultsReview");
                $scope.customerInput = angular.fromJson($stateParams.customerInput);
                $scope.customerInput.isIRSelected = $scope.iRData.isIRSelected;
                if ($scope.iRData.isIRSelected === 'y') {
                	$scope.customerInput.iRAnswer = $scope.iRData.answer;
                }
                if (AppState.tmpRAQResult) {
                	AppState.tmpRAQResult.isIRSelected = $scope.iRData.isIRSelected;
                	if ($scope.iRData.isIRSelected === 'y') {
                		AppState.tmpRAQResult.iRAnswer = $scope.iRData.answer;
                    }
                }
                var param = {
                    generalInfo: $stateParams.generalInfo,
                    userChoices: $stateParams.userChoices,
                    customerType: $stateParams.customerType,
                    customerInput: angular.toJson($scope.customerInput)
                };
                $state.go('base.raq_review', param, {
                    reload: true
                });
            }
            $scope.init();
        }
    ]);
});