define([
    'app/app',
    'js/Util/DataPersister',
    'js/Util/PdfPluginUtil',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/AuditLoggingUtil',
    'js/Util/Validation'
], function(app, DataPersister, PdfPluginUtil, AppState, Constants, RAQService, LogUtil, CommonUtil, AuditLoggingUtil, Validation) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQRMSigCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $ionicScrollDelegate {service} for control scroll views
     * @param $state {service} for store data in appState
     * @param $translate {service} i18n handling
     * @param $filter {service} for data formating
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ RM Signature Page
     */
    app.controller('RAQRMSigCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        '$filter',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $state, $translate, $filter, RAQService) {
        	/**
    	     * Initialization function of RAQQuestionsCtrl
    	     * @memberof RAQRMSigCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RM signature page,
    		 * Dismiss customer witness signature view (Back flow),
    		 * Create RM signature view
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQRMSigCtrl -> init");
        		busyIndicator.show();
        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                $scope.customerInput = angular.fromJson($scope.customerInfo.customerInput);
                $scope.customerType = $scope.customerInfo.customerType;
                $scope.rmName = AppState.userInfo.userFullName;
                $scope.isResultOverridden = $scope.customerInfo.isResultOverridden;
                $scope.newRiskToleranceLevelType='';
                $scope.newRiskToleranceLevelTypeEn='';
                $scope.newRiskToleranceLevelTypeTc='';
                $scope.newRiskToleranceLevelTypeSc='';
                $scope.riskToleranceLevel = Number($scope.customerInfo.riskToleranceLevel);
                if($scope.isResultOverridden==1){
               	 	$scope.newRiskToleranceLevel = Number($scope.customerInfo.newRiskToleranceLevel);                    
                }
                $scope.questionnameList = $scope.generalInfo.questionnameList;
                $scope.optionID = $scope.customerInfo.optionID;
                $scope.rmRINumber = {};
                $scope.isSubmitted = false;
                
                cordova.exec(function() {
                    LogUtil.logDebug('RAQRMSigCtrl: dismissWitnessCustomerSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessCustomer']);

                
                var signPadX = 135;
                var signPadY = 220;
                var signPadW = 754;
                var signPadH = 250;

                cordova.exec(function() {
                    LogUtil.logDebug('RAQRMSigCtrl: createSignView success');
                    busyIndicator.hide();
                }, function() {
                	LogUtil.logDebug('RAQRMSigCtrl: createSignView failure');
                	busyIndicator.hide();
                }, 'SignPlugin', 'createSignView', ['rm', signPadX, signPadY, signPadW, signPadH]);
                
                $scope.getPDFTemplate();
                $scope.getRINumber();
                $scope.getRiskToleranceLevelType();
                $scope.preparePDF();
        	};
            
        	/**
    	     * Event trigger by click clear button
    	     * @memberof RAQRMSigCtrl
    	     * @function clearSig
    		 * @description invoke clearSignView function, reset RM signature view
    	     */ 
            $scope.clearSig = function() {
    			LogUtil.logInfo("RAQRMSigCtrl -> clearSig");

                cordova.exec(function() {
                    LogUtil.logDebug('RAQRMSigCtrl: clearSignView');
                }, function() {}, 'SignPlugin', 'clearSignView', ['rm']);
            };
            
       		/**
    	     * get Templates for generating RAQ PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function getRAQPDFTemplate
    		 * @description select Templates for generating RAQ PDF according to customerType and current language
    	     */
            // Get RAQ PDF template
            $scope.getPDFTemplate=function(){
            	LogUtil.logDebug('RAQRMSigCtrl: get templates: AppState.raqPDFTemplate ');
                var pdfLangCode = AppState.currentLangCode;
             	if(AppState.currentLangCode == Constants.LANG_EN){
             		pdfLangCode = Constants.LANG_TC;
             	}
             	var pdfTemplateId = 'raq_'+$scope.customerType+'_'+pdfLangCode;
                for (var i = 0; i < AppState.raqPDFTemplate.length; i++) {
                      if (AppState.raqPDFTemplate[i].id.toUpperCase() == pdfTemplateId.toUpperCase()) {
                             $scope.raqPDFTemplate = AppState.raqPDFTemplate[i].fileContent;
                      }
                 }                  
            };
           
            /**
    	     * get RI Number for generating RAQ PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function getRINumber
    		 * @description check if there exists data in AppState or there is new input, if not, get it from local storage 
    	     */
            $scope.getRINumber=function(){
            	if(AppState.rmRINumber){             
                    $scope.rmRINumber.num = AppState.rmRINumber;
                }else{
    	            DataPersister.getAppDataByNameValue('rmRINumber',function(value) {
    	            LogUtil.logInfo('RAQRMSigCtrl -> rmRINumber: '+value);
    	            if (typeof value === 'undefined' || value === 'null'|| value === null||value === '') {
    	                LogUtil.logDebug('RAQRMSigCtrl: No rmRINumber is stored');
    	            }else {
    		            $scope.rmRINumber.num = value;
    		            AppState.rmRINumber = value;
    	            }
                });            	
                }
                LogUtil.logDebug('RAQRMSigCtrl -> AppState.rmRINumber : '+ AppState.RINumber);
            };
            
            /**
    	     * get RiskTolerance Level and Type
    	     * @memberof RAQRMSigCtrl
    	     * @function getRiskToleranceLevelType
    		 * @description get level list first,
    		 * then get riskTolerance Level and Type of different languages
    		 * get new riskTolerance Level and Type of different languages if exists
    	     */ 
            $scope.getRiskToleranceLevelType=function(){            	 
                 $scope.levelListEn = AppState.raqConfig.levelList.get(Constants.LANG_EN);
            	 $scope.levelListTc = AppState.raqConfig.levelList.get(Constants.LANG_TC);
            	 $scope.levelListSc = AppState.raqConfig.levelList.get(Constants.LANG_SC);
            	 $scope.riskToleranceLevelTypeEn = $scope.levelListEn[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListEn[$scope.riskToleranceLevel-1].type;
              	 $scope.riskToleranceLevelTypeTc = $scope.levelListTc[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListTc[$scope.riskToleranceLevel-1].type;        	  
            	 $scope.riskToleranceLevelTypeSc = $scope.levelListSc[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListSc[$scope.riskToleranceLevel-1].type;               
            	 if ($scope.newRiskToleranceLevel) {
                    $scope.newRiskToleranceLevelTypeEn = $scope.levelListEn[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListEn[$scope.newRiskToleranceLevel-1].type;
                    $scope.newRiskToleranceLevelTypeTc = $scope.levelListTc[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListTc[$scope.newRiskToleranceLevel-1].type;
                    $scope.newRiskToleranceLevelTypeSc = $scope.levelListSc[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListSc[$scope.newRiskToleranceLevel-1].type;
               } 
            };
            
            /**
    	     * Prepare PDF generation
    	     * @memberof RAQRMSigCtrl
    	     * @function preparePDF
    		 * @description prepare data for generating PDF, 
    		 * format data of those parameters   
    	     */            
            $scope.preparePDF=function(){
            	if ($scope.customerInfo.isResultOverridden === 0) {
                    $scope.isResultMatch = 'Y';
                    $scope.isResultNotMatch = 'N';
                    $scope.customerName1 = $scope.customerInput.customerName;
                    $scope.customerName2 = '';
                } else {
                    $scope.isResultMatch = 'N';
                    $scope.isResultNotMatch = 'Y';
                    $scope.customerName1 = '';
                    $scope.customerName2 = $scope.customerInput.customerName;
                }
                if ($scope.customerInfo.isPhotoCopyRecieved == 1) {
                    $scope.isPhotoCopyRecieved = 'Y';
                } else {
                    $scope.isPhotoCopyRecieved = 'N';
                }
                
                $scope.answersList = [];
                for (var i = 0; i < $scope.questionnameList.length; i++) {
                    $scope.answersList.push({
                        'questionID': $scope.questionnameList[i],
                        'optionID': $scope.optionID[i]
                    });
                }
                
                if ($scope.customerInput.isIRSelected === 'y') {
                	$scope.isInvestmentRestriction = 'Y';
                	$scope.investmentRestriction = $scope.customerInput.iRAnswer;
                } else {
                	$scope.isInvestmentRestriction = 'N';
                }
            };
            
            /**
    	     * get levelList content according to language change
    	     * @memberof RAQRMSigCtrl
    	     * @function watch currentLangCode
    		 * @description check current language, then get levelList content according to language 
    		 * get riskToleranceLevelType according to levelList
    		 * get newRiskToleranceLevelType (if exists)
    	     */
				$scope.$watch('AppState.currentLangCode', function() {
            	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);            	
            	$scope.riskToleranceLevelType = $scope.levelList[$scope.riskToleranceLevel-1].level +' - '+$scope.levelList[$scope.riskToleranceLevel-1].type;
            	if ($scope.newRiskToleranceLevel) {
                    $scope.newRiskToleranceLevelType = $scope.levelList[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelList[$scope.newRiskToleranceLevel-1].type;
                }
                
            }, true);
            
            /**
    	     * get Template to display upload pdf success information
    	     * @memberof RAQRMSigCtrl
    	     * @function ionicModal fromTemplateUrl 
    		 * @description read the modal file according to url 
    	     */  
            $ionicModal.fromTemplateUrl('./app/raq/templates/raq_submit_success.html', {
                scope: $scope,
        		backdropClickToClose : false
            }).then(function(modal) {
                $scope.submitModal = modal;
            });            
            
            /**
    	     * Invoke from "captureSignSuccessCallback" when customer type is individual or corporate
    	     * @memberof RAQRMSigCtrl
    	     * @function generateRAQPDF
    		 * @description pass parameters for generating pdf  
    	     */
            $scope.generateRAQPDF = function() {
    			LogUtil.logInfo("RAQRMSigCtrl -> generateRAQPDF");
                var date = $filter('date')(new Date(), 'dd MMM yyyy');
                var reqData = {
                    accountName: $scope.customerInput.accountName,
                    accountNumber: $scope.customerInput.accountNumber != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '',
                    customerName: $scope.customerInput.customerName,
                    rmName: $scope.rmName,
                    rmRINumber: $scope.rmRINumber.num,
                    cumulativeScore: $scope.customerInfo.cumulativeScore + '',                   
                    riskToleranceLevelEn:$scope.riskToleranceLevelTypeEn,
                    riskToleranceLevelTc:$scope.riskToleranceLevelTypeTc,
                    riskToleranceLevelSc: $scope.riskToleranceLevelTypeSc,                   
                    isResultMatch: $scope.isResultMatch,
                    isResultNotMatch: $scope.isResultNotMatch,
                    isPhotoCopyReceived: $scope.isPhotoCopyRecieved,
                    customerName1: $scope.customerName1,
                    customerName2: $scope.customerName2,
                    newRiskToleranceLevelEn: $scope.newRiskToleranceLevelTypeEn,
                    newRiskToleranceLevelTc: $scope.newRiskToleranceLevelTypeTc,
                    newRiskToleranceLevelSc: $scope.newRiskToleranceLevelTypeSc,
                    customerSignature: $scope.customerInfo.customerSignature,
                    rmSignature: $scope.rmSignature,
                    date: date,
                    answersList: $scope.answersList,
                    inputFileContent: $scope.raqPDFTemplate,
                    // These are empty as they are for witness only
                    customerWitnessSignature: '',
                    rmWitnessSignature: '',
                    customerWitnessName: '',
                    rmWitnessName: '',
                    rmWitnessRINumber: '',
                    // Investment Restrictions
                    isInvestmentRestriction: $scope.isInvestmentRestriction,
                    investmentRestriction: $scope.investmentRestriction
                };
                // Generate PDF
                PdfPluginUtil.generateRaqPDF(reqData, this.successCallback, this.failureCallback);
            };

       	 	/**
    	     * Event trigger by click close icon of submit success page
    	     * @memberof RAQRMSigCtrl
    	     * @function hideOverlay 
    		 * @description close submit success info page 
    	     */
            $scope.hideOverlay = function() {            	
                $scope.submitModal.hide();
                $scope.isOverlay=false;
                $state.go('base.raq_select_customer_type', {  	    			
                }, {
                    reload: true
                });
            };
            
    		/**
    	     * Success Callback of saveRAQResultToLocal function
    	     * @memberof RAQRMSigCtrl
    	     * @function saveRAQResultSuccessCallback
    		 * @description Save RAQ to local, Clear RAQ data in memory,
    		 * display  upload Error message
    		 * dismiss RM signature view.
    		 * go back to select type page  		
    	     */
            $scope.saveRAQResultSuccessCallback = function() {
            	busyIndicator.hide();
                LogUtil.logDebug('RAQRMSigCtrl -> saveRAQResultResult -> saveRAQResultSuccessCallback');
                // Clear RAQ data in memory
                AppState.tmpRAQResult = {};                
                // Error message
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$scope.errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {                	
                    // back to select type page
                    $state.go('base.raq_select_customer_type', {  	    			
                    }, {
                        reload: true
                    });

                    // Dismiss RM signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('dismissRMSignView');
                    }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);
                }}]);
            };
            
            /**
    	     * Failure Callback of saveRAQResultToLocal
    	     * @memberof RAQRMSigCtrl
    	     * @function saveRAQResultFailureCallback
    		 * @description  try to find cause of error,then log error info,
    		 * Clear temporary RAQ data in memory 
    		 * Go back to select type page
    		 * dismiss RM signature view  		 	 
    	     */ 
            $scope.saveRAQResultFailureCallback = function() {
            	busyIndicator.hide();
                LogUtil.logError('RAQRMSigCtrl -> saveRAQResultResult -> saveRAQResultFailureCallback');
                // Clear RAQ data in memory
                AppState.tmpRAQResult = {};                
                // Error message
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_SUBMIT_N_SAVE_RAQ_FAILURE'),[{text:$translate.instant('BTN_OK'), handler: function() {
                    // back to select type page
                    $state.go('base.raq_select_customer_type', {  	    			
                    }, {
                        reload: true
                    });
                    // Dismiss RM signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('dismissRMSignView');
                    }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);
                }}]);
            };
            
            /**
    	     * event invoked by uploadRAQPDFFailureCallback
    	     * @memberof RAQRMSigCtrl
    	     * @function saveRAQResultToLocal
    		 * @description  invoke saveRAQResult function in  RAQService, 
    		 * if success, invoke saveRAQResultSuccessCallback
    	     */ 
            $scope.saveRAQResultToLocal = function (){
    			LogUtil.logInfo("RAQRMSigCtrl -> saveRAQResultToLocal");

            	RAQService.saveRAQResult($scope.raqResultData, $scope.saveRAQResultSuccessCallback, $scope.saveRAQResultFailureCallback);
            };
            
    		/**
    	     * Success callback function of Generate PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function Generate PDF successCallback
    		 * @description invoke uploadRAQPDFFiles function in RAQService,
    		 * if success, invoke uploadRAQPDFSuccessCallback   		
    	     */           
            $scope.successCallback = function(data) {
                LogUtil.logDebug('RAQRMSigCtrl -> generatePdf -> successCallback');
                $scope.pdfdata=data;
                var accountName = $scope.customerInput.accountName;
                var accountNumber = $scope.customerInput.accountNumber != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '';
                var customerName = $scope.customerInput.customerName;                
                // File upload
                RAQService.uploadRAQPDFFiles(data, customerName, accountName, accountNumber, $scope.uploadRAQPDFSuccessCallback, $scope.uploadRAQPDFFailureCallback);
                var auditLogInfo = {
                		userID : AppState.userID,
                		activity:'submit_raq',
                		customerName : customerName,
                		accountName : accountName,
                		accountNumber : accountNumber
                };
                AuditLoggingUtil.insertAuditLogging(auditLogInfo);
            };
    
    		/**
    	     * Success callback function of uploading PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function uploadRAQPDFSuccessCallback
    		 * @description Clear the RAQ data in memory, Show the success overlay,
    		 * Dismiss RM signature view		
    	     */
            $scope.uploadRAQPDFSuccessCallback = function(data) {  
                busyIndicator.hide();
                LogUtil.logDebug('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFSuccessCallback');
                // Clear the RAQ data in memory
                AppState.tmpRAQResult = {};
                // Dismiss RM signature view
                cordova.exec(function() {
                    LogUtil.logDebug('dismissRMSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);    
                // Show the success overlay
                $scope.submitModal.show();  
                $scope.submitRAQEnd = Date.now();
            	var responseTime = ($scope.submitRAQEnd - $scope.submitRAQStart)/1000;
	            LogUtil.logInfo('Performance Test : Submit RAQ userID=' + AppState.userID +' r='+responseTime);
            };
            
            /**
    	     * Failure Callback of uploading RAQ PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function  uploadRAQPDFFailureCallback
    		 * @description  try to Save RAQ data to local storage
    		 * log error message		 	 
    	     */ 
            $scope.uploadRAQPDFFailureCallback = function(data) {
            	// Save RAQ data to local storage
                LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback');
                var datatmp = AppState.tmpRAQResult;
                datatmp.accountNumber=$scope.customerInput.accountNumber != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '';
                datatmp.rmRINumber = $scope.rmRINumber.num;
                datatmp.generatedPdf = $scope.pdfdata;
                datatmp.riskToleranceLevel = $scope.riskToleranceLevel;
                datatmp.newRiskToleranceLevel = $scope.newRiskToleranceLevel;
                $scope.raqResultData = datatmp;
               
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - Error returned from ZPB - ' + errorCode);
                    $scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_ZPB_FAILURE')+'-'+errorCode;
                    $scope.saveRAQResultToLocal();
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('Network Info : '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - No internet connection');
			  				$scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_INTERNET_CONNECTION');
			  			}else{
			  				LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - MobileFirst server connection failure');
			  				$scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_MFP_CONNECTION_FAILURE');
			  			}			  	
			  			$scope.saveRAQResultToLocal();
   			  		});
                }
                
            };
            
            /**
    	     * Failure Callback of Generating RAQ PDF
    	     * @memberof RAQRMSigCtrl
    	     * @function  Generate PDF failureCallback
    		 * @description  log error message, go back to select type page,
    		 * Dismiss RM signature view 	 
    	     */ 
            $scope.failureCallback = function(data) {
                busyIndicator.hide();
                LogUtil.logError('RAQRMSignCtrl -> failureCallback: Generate PDF failure ');
                
                // Error message
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_SUBMIT_N_SAVE_RAQ_FAILURE'),[{text:$translate.instant('BTN_OK'), handler: function() {
                	// Clear RAQ data in memory
                    AppState.tmpRAQResult = {};
                    // back to select type page
                    $state.go('base.raq_select_customer_type', {  	    			
                    }, {
                        reload: true
                    });

                    // Dismiss RM signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('dismissRMSignView');
                    }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);
                }}]);
            };

            
            /**
    	     * Event trigger by clicking 'next' or 'submit' button
    	     * @memberof RAQCustomerSigCtrl
    	     * @function goWitnessORSubmit
    		 * @description validate rmRINumber, and try to Capture signature 		
    		 * 
    	     */            
            $scope.goWitnessORSubmit = function() {
            	$scope.submitRAQStart = Date.now();

            	$scope.isSubmitted = true;
            	LogUtil.logDebug('RAQRMSignCtrl -> goWitnessORSubmit');
                
                if(Validation.isEmpty(this.rmRINumber.num)){
                	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_RM_RI_NUMBER_EMPTY'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
                }else {
	                busyIndicator.show();
	                // Capture signature
	                cordova.exec(this.captureSignSuccessCallback, this.captureSignFailureCallback, 'signPlugin', 'captureSignature', ['rm']);
                }
            };
            
    		/**
    	     * Success callback function for capture Signature
    	     * @memberof RAQCustomerSigCtrl
    	     * @function captureSignSuccessCallback
    		 * @description Capture signature, store Signature png data and rmRINumber,
    		 * dismiss RM signature view.
    		 * 1. When the customer type is "Vulnerable", it goes to Customer Witness Page
    		 * 2. When the customer type is not "Vulnerable" (i.e. "Individual" / "Corporate"), 
    		 * Proceed to generate PDF and submit RAQ result when customer type is not "Vulnerable"
    	     */
            $scope.captureSignSuccessCallback = function(signaturePngData) {
                LogUtil.logDebug('RAQRMSignCtrl -> goWitnessORSubmit -> captureSignSuccessCallback');                    
                $scope.rmSignature = signaturePngData;               
                // Save RI number to local storage
                DataPersister.setAppDataByNameValue('rmRINumber', $scope.rmRINumber.num);
                AppState.rmRINumber = $scope.rmRINumber.num;
                LogUtil.logDebug('RAQRMSignCtrl -> goWitnessORSubmit -> RINumber after saving result:');
                LogUtil.logDebug($scope.rmRINumber.num);
            	// Get the RM name, RI number, RM signature, pass to next page
                $scope.customerInfo.rmName = $scope.rmName;
                $scope.customerInfo.rmRINumber = $scope.rmRINumber.num;
                $scope.customerInfo.rmSignature = $scope.rmSignature;
                var param = {
                    generalInfo: angular.toJson($scope.generalInfo),
                    customerInfo: angular.toJson($scope.customerInfo)
                };

                if ($scope.customerType == Constants.RAQ_CUST_TYPE_VUL) {
                	// Dismiss RM signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('RAQRMSignCtrl -> goWitnessORSubmit -> dismissRMSignView');
                    }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);
                	
                	// Go to Customer Witness Signature Page when customer type is "Vulnerable"
                    var datatmp = AppState.tmpRAQResult;
                    datatmp.rmRINumber = $scope.rmRINumber.num;                        
                    AppState.tmpRAQResult = datatmp;
                    $state.go('base.raq_customerwitness_signature', param, {
                        reload: true
                    });                    
                    busyIndicator.hide();
                } else {                	
                    $scope.generateRAQPDF();
                }
            };
            
    		/**
    	     * Failure callback function for capture Signature
    	     * @memberof RAQCustomerSigCtrl
    	     * @function captureSignFailureCallback
    		 * @description try to find the cause of error,log error info, dismiss RM signature view
    	     */
            // Capture signature failure callback
            $scope.captureSignFailureCallback = function(err) {
            	// TODO: Error handling
            	LogUtil.logError('RAQRMSignCtrl -> goWitnessORSubmit -> captureSignFailureCallback');
            	LogUtil.logError(err);
            	
            	// Dismiss RM signature view
                cordova.exec(function() {
                    LogUtil.logDebug('RAQRMSignCtrl -> goWitnessORSubmit -> dismissRMSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['rm']);
                
            	busyIndicator.hide();
            	WL.SimpleDialog.show($translate.instant('RAQ_SIG_CAPTURE_FAIL_TITLE'),$translate.instant('RAQ_SIG_CAPTURE_FAIL'),[{text:$translate.instant('BTN_OK'), handler: function() {                    	                       
            		var param = {
                            generalInfo: angular.toJson($scope.generalInfo),
                            customerInfo: angular.toJson($scope.customerInfo)
                     };
                	$state.go($state.current, param, {reload: true});
                }}]); 
            	
            };
            $scope.init();
	        $scope.preview = function() {
	              // Preview PDF
	              cordova.exec(function(data){
	                  //console.log("preview: Success");
	              }, function(data){
	              	//console.log("preview: Failure");
	              }, "PdfPlugin", "loadPdf", []);
	          };
        }
    ]);
});