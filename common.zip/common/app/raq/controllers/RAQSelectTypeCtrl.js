define(['js/Util/LogUtil',
    'app/app',
    'app/raq/services/RAQService',
    'js/appState',
    'js/constants',
    'js/Util/CommonUtil'
], function(LogUtil, app, RAQService, AppState, Constants,CommonUtil) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQSelectTypeCtrl
     * @param $scope {service} controller scope
     * @param $translate {service} i18n handling
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ Select Type Page
     */
    app.controller('RAQSelectTypeCtrl', [
        '$scope',
        '$translate',
        '$stateParams',
        '$ionicModal',
        '$state',
        'RAQService',
        function($scope, $translate, $stateParams, $ionicModal, $state, RAQService) {
        	/**
    	     * Initialization function of RAQSelectTypeCtrl
    	     * @memberof RAQSelectTypeCtrl
    	     * @function init
    		 * @description initial some variables for customer when starting a new RAQ,
    		 * Pre-fill selected customer type
    	     */
        	$scope.init = function() {
    			LogUtil.logInfo("RAQSelectTypeCtrl -> init");

        		 $scope.customer_type = [Constants.RAQ_CUST_TYPE_IND, Constants.RAQ_CUST_TYPE_VUL, Constants.RAQ_CUST_TYPE_COR];
                 $scope.customerInput = {
                     "customerName": "",
                     "accountName": "",
                     "accountNumber": ""
                 }; 
     			busyIndicator.hide();                
                 if (AppState.tmpRAQResult.customerType) {
                     $scope.selectedCustomerType = AppState.tmpRAQResult.customerType;
                 } else {
                     $scope.selectedCustomerType = null;
                 }
        		
        	};
           
        	 /**
    	     * Event trigger when "Individual" is selected
    	     * @memberof RAQSelectTypeCtrl
    	     * @function goCustomerinputIn
    		 * @description Go to Customer Input Page, and pass parameters  
    	     */            
            $scope.goCustomerinputIn = function() {
            	var data ={};
                if (AppState.tmpRAQResult.customerType==$scope.customer_type[0]){
            		data = AppState.tmpRAQResult; 
            		AppState.tmpRAQResult = data;
            	}else{
               		data.customerType=$scope.customer_type[0];  
            		AppState.tmpRAQResult = data;
            	}
                
                LogUtil.logDebug(AppState.tmpRAQResult.customerType);
                var param = {
                    customer_type: $scope.customer_type[0],
                    customerInput: angular.toJson($scope.customerInput)
                };
               
                LogUtil.logDebug($scope.customer_type[0]);
                $state.go('base.raq_customer_input', param, {
                    reload: true
                });
            };
            
       	 	/**
    	     * Event trigger when "Vulnerable" is selected
    	     * @memberof RAQSelectTypeCtrl
    	     * @function goCustomerinputVu
    		 * @description passing parameters and direct to Customer Input Page
    	     */ 
            $scope.goCustomerinputVu = function() {
            	var data ={};
				if (AppState.tmpRAQResult.customerType==$scope.customer_type[1]){
            		data = AppState.tmpRAQResult;  
            		AppState.tmpRAQResult = data;
            	}else{
            		
            		data.customerType=$scope.customer_type[1]; 
            		AppState.tmpRAQResult = data;
            	}
                
                var param = {
                    customer_type: $scope.customer_type[1],
                    customerInput: angular.toJson($scope.customerInput)
                };
                $state.go('base.raq_customer_input', param, {
                    reload: true
                });
            };
       	 	/**
    	     * Event trigger when "Corporate" is selected
    	     * @memberof RAQSelectTypeCtrl
    	     * @function goCustomerinputCo
    		 * @description passing parameters and direct to Customer Input Page 
    	     */ 
            $scope.goCustomerinputCo = function() {
            	var data = {};
                if (AppState.tmpRAQResult.customerType==$scope.customer_type[2]){
            		data = AppState.tmpRAQResult;
            		AppState.tmpRAQResult = data;
            	}else{
            		
            		data.customerType=$scope.customer_type[2]; 
            		AppState.tmpRAQResult = data;
            	}                
                var param = {
                    customer_type: $scope.customer_type[2],
                    customerInput: angular.toJson($scope.customerInput)
                };
                $state.go('base.raq_customer_input', param, {
                    reload: true
                });
            };
            $scope.init();
        }
    ]);
});