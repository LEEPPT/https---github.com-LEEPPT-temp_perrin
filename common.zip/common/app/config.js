define([
  'app/app',
  'js/message',
  'js/appState'
], function (app,translations,AppState) {
  'use strict';
  // additional config-blocks
  app.config(function ($translateProvider, $ionicConfigProvider) {
	  
	 $ionicConfigProvider.views.swipeBackEnabled(false);
	  
	 angular.forEach(translations, function(translation, lang) {
		 $translateProvider.translations(lang, translation);
		});
	  $translateProvider.preferredLanguage(AppState.currentLangCode);
	  var link = document.createElement("link");
	    link.type = "text/css";
	    link.rel = "stylesheet";
	    link.href = "css/"+AppState.currentLangCode+'/'+AppState.currentLangCode+'.css';
	    document.getElementsByTagName("head")[0].appendChild(link);
	});
});
