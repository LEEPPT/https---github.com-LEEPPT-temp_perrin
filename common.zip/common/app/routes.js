define([
  'app/app',
  // Load Controllers here
  'app/base/controllers/HomePageCtrl',
  'app/base/controllers/NavigationCtrl',
  'app/base/controllers/BaseCtrl',
  'app/portfolio/controllers/CustomerPortfoliosCtrl',
  'app/portfolio/controllers/PortfolioOverviewCtrl',
  'app/portfolio/controllers/PortfolioCreationCtrl',
  'app/portfolio/controllers/PortfolioHoldingsCtrl',
  'app/portfolio/controllers/PortfolioHistoryCtrl',
  'app/portfolio/controllers/PortfolioPerformanceCtrl',
  'app/portfolio/controllers/PortfolioComparisonCtrl',
  'app/portfolio/controllers/PortfolioCoverCtrl',
  'app/portfolio/controllers/AccountSearchCtrl',
  'app/portfolio/controllers/AccountSelectCtrl',
  'app/portfolio/controllers/AccountDetailsCtrl',
  'app/portfolio/controllers/CurrencyDistributionCtrl',
  'app/portfolio/controllers/TargetPortfolioCtrl',
  'app/portfolio/controllers/TargetPortfoliosProspectCtrl',
  'app/raq/controllers/RAQMainCtrl',
  'app/raq/controllers/RAQSelectTypeCtrl',
  'app/raq/controllers/RAQCustomerInputCtrl',
  'app/raq/controllers/RAQQuestionsCtrl',
  'app/raq/controllers/RAQInvestmentRestrictionsCtrl',
  'app/raq/controllers/RAQReviewCtrl',
  'app/raq/controllers/RAQResultCtrl',
  'app/raq/controllers/RAQResultOverrideCtrl',
  'app/raq/controllers/RAQDeclarationCtrl',
  'app/raq/controllers/RAQDisclaimerCtrl',
  'app/raq/controllers/RAQCustomerSigCtrl',
  'app/raq/controllers/RAQRMSigCtrl',
  'app/raq/controllers/RAQCustomerWitnessSigCtrl',
  'app/raq/controllers/RAQRMWitnessSigCtrl',
  'app/callreport/controllers/CallReportMainCtrl',
  'app/callreport/controllers/CallReportCreationCtrl'
], function (app) {
  'use strict';
  // definition of routes
  app.config([
    '$stateProvider',
    '$urlRouterProvider',
    function ($stateProvider, $urlRouterProvider) {
      // url routes/states
      $urlRouterProvider.otherwise('/base/homepage');

      $stateProvider
        // app states
      	.state('base', {
          url : '/base',
          templateUrl : 'app/base/templates/base.html',
          abstract : true,
          controller : 'BaseCtrl'
      	})
        .state('base.homepage', {
          url: '/homepage',
          cache: false,
          views: {
              'base': {
            	  		templateUrl: 'app/base/templates/homepage.html',
            	  		controller: 'HomePageCtrl'
              		}
          }
        })
        .state('base.customer_portfolios', {
            url: '/customer_portfolios',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/customer_portfolios.html',
		            controller: 'CustomerPortfoliosCtrl'
                }
            }
        })
        .state('base.portfolio_overview', {
            url: '/portfolio_overview/:id',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_overview.html',
		            controller: 'PortfolioOverviewCtrl'
                }
            }
        })
         .state('base.account_search', {
            url: '/account_search/:isExistingSearch/:isFromAccSearch',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/account_search.html',
		            controller: 'AccountSearchCtrl'
                }
            }
        })
        .state('base.account_select', {
            url: '/account_select/:isFromAccSearch',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/account_select.html',
		            controller: 'AccountSelectCtrl'
                }
            }
        })
        .state('base.portfolio_creation', {
            url: '/portfolio_creation',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_creation.html',
		            controller: 'PortfolioCreationCtrl'
                }
            }
        })
        .state('base.portfolio_holdings', {
            url: '/portfolio_holdings/:data/:assetCategory',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_holdings.html',
		            controller: 'PortfolioHoldingsCtrl'
                }
            }
        })
        .state('base.account_details', {
            url: '/account_details/:data',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/account_details.html',
		            controller: 'AccountDetailsCtrl'
                }
            }
        })
        .state('base.portfolio_history', {
            url: '/portfolio_history/:data/:allocationType/:graphOrDetail/:specificAsset',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_history.html',
		            controller: 'PortfolioHistoryCtrl'
                }
            }
        })
        .state('base.portfolio_performance', {
            url: '/portfolio_performance/:data',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_performance.html',
		            controller: 'PortfolioPerformanceCtrl'
                }
            }
        })
        .state('base.portfolio_comparison', {
            url: '/portfolio_comparison/:data',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_comparison.html',
		            controller: 'PortfolioComparisonCtrl'
                }
            }
        })
        .state('base.portfolio_cover', {
            url: '/portfolio_cover/:id',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/portfolio_cover.html',
		            controller: 'PortfolioCoverCtrl'
                }
            }
        })
        .state('base.currency_distribution', {
            url: '/currency_distribution/:data',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/currency_distribution.html',
		            controller: 'CurrencyDistributionCtrl'
                }
            }
        })
        .state('base.target_portfolio', {
            url: '/target_portfolio/:source/:data/:targetPortfolio/:portfolioModel',
            params: { 
              source: 'create',  
              data: null,
              targetPortfolio : null,
              portfolioModel : null
            },
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/target_portfolio.html',
		            controller: 'TargetPortfolioCtrl'
                }
            }
        })
        .state('base.target_portfolios_prospect', {
            url: '/target_portfolios_prospect',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/portfolio/templates/target_portfolios_prospect.html',
		            controller: 'TargetPortfoliosProspectCtrl'
                }
            }
        })
        .state('base.raq_main', {
            url: '/raq_main',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/raq/templates/raq_main.html',
		            controller: 'RAQMainCtrl'
                }
            }
        })
        .state('base.raq_select_customer_type', {
            url: '/raq_select_customer_type',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_select_customer_type.html',
                controller: 'RAQSelectTypeCtrl'
                }
            }
        })
        .state('base.raq_customer_input', {
            url: '/raq_customer_input/:customer_type/:customerInput/:misc',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_customer_input.html',
                controller: 'RAQCustomerInputCtrl'
                }
            }
        })
        .state('base.raq_questions', {
            url: '/raq_questions/:customerType/:customerInput/:initialID/:userChoices/:misc',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_questions.html',
                controller: 'RAQQuestionsCtrl'
                }
            }
        })
        .state('base.raq_investment_restrictions', {
            url: '/raq_investment_restrictions/:generalInfo/:userChoices/:customerType/:customerInput/:misc',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_investment_restrictions.html',
                controller: 'RAQInvestmentRestrictionsCtrl'
                }
            }
        })
        .state('base.raq_review', {
            url: '/raq_review/:generalInfo/:userChoices/:customerType/:customerInput/:misc',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_review.html',
                controller: 'RAQReviewCtrl'
                }
            }
        })
        .state('base.raq_result', {
            url: '/raq_result/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl:'app/raq/templates/raq_result.html',
                controller:'RAQResultCtrl'
                }
            }
        })
        .state('base.raq_result_override', {
            url: '/raq_result_override/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_result_override.html',
                controller: 'RAQResultOverrideCtrl'
                }
            }
        })
        .state('base.raq_declaration', {
            url: '/raq_declaration/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_declaration.html',
                controller: 'RAQDeclarationCtrl'
                }
            }
        })
        .state('base.raq_disclaimer', {
            url: '/raq_disclaimer/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_disclaimer.html',
                controller: 'RAQDisclaimerCtrl'
                }
            }
        })
        .state('base.raq_customer_signature', {
            url: '/raq_customer_signature/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_customer_signature.html',
                controller: 'RAQCustomerSigCtrl'
                }
            }
        })
        .state('base.raq_rm_signature', {
            url: '/raq_rm_signature/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_rm_signature.html',
                controller: 'RAQRMSigCtrl'
                }
            }
        })
        .state('base.raq_customerwitness_signature', {
            url: '/raq_customerwitness_signature/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_customerwitness_signature.html',
                controller: 'RAQCustomerWitnessSigCtrl'
                }
            }
        })
        .state('base.raq_rmwitness_signature', {
            url: '/raq_rmwitness_signature/:generalInfo/:customerInfo',
            cache: false,
            views: {
                'base': {
                templateUrl: 'app/raq/templates/raq_rmwitness_signature.html',
                controller: 'RAQRMWitnessSigCtrl'
                }
            }
        })
        .state('base.call_report_main', {
            url: '/call_report_main',
            cache: false,
            views: {
                'base': {
		            templateUrl: 'app/callreport/templates/call_report_main.html',
		            controller: 'CallReportMainCtrl'
                }
            }
        }).state('base.call_report_creation', {
              url: '/call_report_creation/:source/:callReport',
              cache: false,
              params: {
            	  source: 'create',
            	  callReport: null  
              },
              views: {
                  'base': {
                     templateUrl: 'app/callreport/templates/call_report_creation.html',
                     controller: 'CallReportCreationCtrl'
                  }
            }
        });
    }
  ]);
});
