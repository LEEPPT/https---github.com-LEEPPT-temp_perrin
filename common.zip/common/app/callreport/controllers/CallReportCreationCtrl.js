define([
    'app/app',
    'app/callreport/services/CallReportService',
    'js/Util/LogUtil',
    'js/constants',
    'js/appState',
    'js/Util/AuditLoggingUtil',
    'js/Util/FunctionActivator',
    'js/Util/CommonUtil'
], function(app, CallReportService, LogUtil, Constants, AppState, AuditLoggingUtil, FunctionActivator, CommonUtil) {
    'use strict';
    app.controller('CallReportCreationCtrl', [
        '$scope',
        '$translate',
        '$stateParams',
        '$filter',
        '$state',
        'CallReportService',
        '$ionicModal',
        function($scope, $translate, $stateParams, $filter, $state, CallReportService, $ionicModal) {
        	// Pre-fill report data
        	$scope.populateReportData = function() {
        		$scope.reportData = {};
        		if ($scope.callReportData && $scope.callReportData.venue) {
        			$scope.reportData.venue = $scope.callReportData.venue;
        		} else {
        			$scope.reportData.venue = null;
        		}
        			
        		if ($scope.callReportData && $scope.callReportData.id) {
        			$scope.reportData.id = $scope.callReportData.id;
        		} else {
        			$scope.reportData.id = null;
        		}
        	};
        	
        	// Pre-fill other data
        	$scope.populateOtherData = function() {
        		$scope.otherData = {};
        		// Pre-fill meeting date time
        		if ($scope.callReportData && $scope.callReportData.meetingDate && $scope.callReportData.meetingTime) {
            		$scope.otherData.meetingDateTime = new Date($filter('date')($scope.callReportData.meetingDate + 'T' + $scope.callReportData.meetingTime, 'yyyy-MM-ddTHH:mm:ss'));
        		} else {
        			$scope.otherData.meetingDateTime = new Date($filter('date')(new Date(), 'yyyy-MM-ddTHH:mm:ss'));
        		}
        		// Pre-fill meeting type
        		if ($scope.callReportData && $scope.callReportData.meetingTypeList && $scope.callReportData.meetingTypeList.length > 0) {
        			for (var i = 0; i < $scope.callReportData.meetingTypeList.length; i++) {
        				$scope.otherData.selectedMeetingType = $scope.callReportData.meetingTypeList[i].id;
        				if ($scope.callReportData.meetingTypeList[i].id === 'phone_call') {
        					$scope.otherData.meetingTypePhoneExt = $scope.callReportData.meetingTypeList[i].remarks;
        				} else if ($scope.callReportData.meetingTypeList[i].id === 'others') {
        					$scope.otherData.meetingTypeOthers = $scope.callReportData.meetingTypeList[i].remarks;
        				}
        				break;
        			}
        		}
        	};
        	
        	// Pre-fill attendee list
        	$scope.populateAttendeeList = function() {
        		$scope.attendeeList = [];
        		if ($scope.callReportData && $scope.callReportData.attendeeList && $scope.callReportData.attendeeList.length > 0) {
        			for (var i = 0; i < $scope.callReportData.attendeeList.length; i++) {
        				$scope.attendeeList.push({
        					id: 'attendee_' + i,
        					name: $scope.callReportData.attendeeList[i]
        				})
        			}
        		}
        	};
        	
        	// Pre-fill staff list
        	$scope.populateStaffList = function() {
        		$scope.staffList = [];
        		if ($scope.callReportData && $scope.callReportData.staffList && $scope.callReportData.staffList.length > 0) {
        			for (var i = 0; i < $scope.callReportData.staffList.length; i++) {
        				$scope.staffList.push({
        					id: 'staff_' + i,
        					name: $scope.callReportData.staffList[i]
        				})
        			}
        		} else {
        			$scope.staffList.push({
        				id: 'staff_0',
        				name: $scope.userFullName
        			})
        		}
        	};
        	
        	// Pre-fill main objective list
        	$scope.populateMainObjectiveList = function() {
        		$scope.mainObjectiveList = [{
        			id: 'prospecting', 
        			selected: false
        		}, {
        			id: 'acc_opening', 
        			selected: false
        		}, {
        			id: 'acc_review', 
        			selected: false
        		}, {
        			id: 'product_briefing_intro', 
        			selected: false
        		}, {
        			id: 'courtsey_call', 
        			selected: false
        		}, {
        			id: 'follow_up', 
        			selected: false
        		}, {
        			id: 'others', 
        			selected: false
        		}];
        		if ($scope.callReportData && $scope.callReportData.mainObjectiveList && $scope.callReportData.mainObjectiveList.length > 0) {
        			for (var i = 0; i < $scope.callReportData.mainObjectiveList.length; i++) {
        				for (var j = 0; j < $scope.mainObjectiveList.length; j++) {
        					if ($scope.callReportData.mainObjectiveList[i].id === $scope.mainObjectiveList[j].id) {
        						$scope.mainObjectiveList[j].selected = true;
        						if ($scope.callReportData.mainObjectiveList[i].id === 'others') {
        							$scope.otherData.mainObjectiveOthers = $scope.callReportData.mainObjectiveList[i].remarks;
        						}
        					}
        				}
        			}
        		}
        	};
        	
        	// Pre-fill meeting details
        	$scope.populateMeetingDetailsData = function() {
        		$scope.meetingDetailsData = {
            		'background': '',
            		'topic_discussed': '',
            		'products_introduced': '',
            		'follow_up': '',
            		'others': ''
            	}
        		if ($scope.callReportData && $scope.callReportData.meetingDetailsList && $scope.callReportData.meetingDetailsList.length > 0) {
        			for (var i = 0; i < $scope.callReportData.meetingDetailsList.length; i++) {
        				$scope.meetingDetailsData[$scope.callReportData.meetingDetailsList[i].id] = $scope.callReportData.meetingDetailsList[i].remarks;
        			}
        		}
            	$scope.sectionHeadingList = [{
            		'sectionID': 'general_info',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_general_info')
            	}, {
            		'sectionID': 'background',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_background')
            	}, {
            		'sectionID': 'topic_discussed',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_topic_discussed')
            	}, {
            		'sectionID': 'products_introduced',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_products_introduced')
            	}, {
            		'sectionID': 'follow_up',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_follow_up')
            	}, {
            		'sectionID': 'others',
            		'sectionIDLabel': $translate.instant('CALL_REPORT_SECTION_others')
            	}];
            	$scope.selectedSection = $scope.sectionHeadingList[0];
        	}
        	
        	// Initialize call report
        	$scope.init = function() {
        		LogUtil.logDebug('CallReportCreationCtrl -> init!');
        		
            	$scope.callReportData = angular.fromJson($stateParams.callReport);
            	
        		// initialize variables
        		$scope.lastModifiedDate = -1;
            	$scope.meetingTypeList = ['face_to_face', 'phone_call', 'others'];
            	$scope.hideMaster = false;
        		$scope.isEditingRemarks = false;
        		$scope.isEditingVenue = false;
        		$scope.isEditingAttendee = false;
        		$scope.isEditingStaff = false;
            	$scope.hasError = true;
            	$scope.isSaved = false;
            	var source = $stateParams.source;
            	if (source === 'create') {
            		$scope.isSaved = false;
            	} else {
            		$scope.isSaved = true;
            		$scope.hasError = false;
            	}
            	$scope.userID = AppState.userID;
            	if (AppState.userInfo !== null){
            		$scope.userFullName = AppState.userInfo.userFullName;
            	} else {
            		$scope.userFullName = AppState.userID;
            	}
            	
            	// pre-fill data
        		$scope.populateReportData();
        		$scope.populateOtherData();
            	$scope.populateAttendeeList();
            	$scope.populateStaffList();
            	$scope.populateMainObjectiveList();
        		$scope.populateMeetingDetailsData();
        		$scope.getLastModifiedDate();
        	};
        	
        	// Prepare submit overlay     	
            $ionicModal.fromTemplateUrl('./app/callreport/templates/call_report_save_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
            
            // Hide submit overlay
            $scope.hideSubmitOverlay = function() {
                $scope.submitModal.hide();
                $state.go('base.call_report_main', {}, {reload: true});
            };
            
            // Edit meeting details
            $scope.editRemarks = function(){
//            	$scope.tempData = $scope.meetingDetailsData[$scope.selectedSection.sectionID];
            	this.isEditingRemarks = true;
//            	$scope.selectedObject = this;
//            	$('textarea').bind('blur', function(e) {
//            		var tempData = $scope.selectedObject.tempData || '';
//            		console.log(tempData);
//                	$scope.meetingDetailsData[$scope.selectedSection.sectionID] = '' + tempData;
//                	if(!$scope.selectedObject.hasError && tempData.length > 3000){
//                		$scope.selectedObject.hasError = true;
//                		$scope.selectedObject.errorMsg = $translate.instant('ERR_MEETING_DETAILS_INVALID_LENGTH');
//                	}
//            	});
            };
            
            
            // Save meeting details
            $scope.saveRemarks = function(){
//            	var tempData = this.tempData || '';
            	this.isEditingRemarks = false;
//            	$scope.meetingDetailsData[$scope.selectedSection.sectionID] = '' + tempData;
//            	if(!this.hasError && tempData.length > 3000){
//            		this.hasError = true;
//                    this.errorMsg = $translate.instant('ERR_MEETING_DETAILS_INVALID_LENGTH');
//            	}
            };
            
            //Refresh Call Report
        	$scope.refreshCallReport = function() {
                LogUtil.logDebug('CallReportMainCtrl -> refreshCallReport : id: '+$scope.tempReport.id);
                var param = {
    			    	data: null,
    			    	source : 'call_report_creation',
    			    	callReport : angular.toJson($scope.tempReport)
    			    };    				
    			$state.go('base.call_report_creation', param, {reload: false, notify: false});
        	};
            
            $scope.getLastModifiedDate = function(){
                if ($scope.callReportData != null && $scope.callReportData != undefined && $scope.callReportData.lastModifiedDate != null && $scope.callReportData.lastModifiedDate != undefined) {
                	$scope.lastModifiedDate = CommonUtil.getDateTimeString($filter('date')(new Date($scope.callReportData.lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
                }
            }

            
            // Edit venue
            $scope.editVenue = function(){
            	this.isEditingVenue = true;
            };
            
            // Save venue
            $scope.saveVenue = function() {
            	this.isEditingVenue = false;
            };
            
            // Toggle hide master
        	$scope.toggleHideMaster = function() {
        		$scope.hideMaster = !$scope.hideMaster;
        	};
        	
        	// Populate meeting details
            $scope.showLoadingAndPopulateSectionData = function(_section) {
            	$scope.selectedSection = angular.fromJson(_section);
            	$scope.tempData = $scope.meetingDetailsData[$scope.selectedSection.sectionID];
            };
            
            // Save call report to local
            $scope.saveCallReportToLocal = function(data) {
            	var source = $stateParams.source;
            	LogUtil.logInfo('CallReportCreationCtrl -> saveCallReportToLocal, source: ' + source);
            	$scope.tempReport = data;
            	if (source === 'create' && !$scope.isSaved) {
            		CallReportService.addCallReport(data, this.addCallReportSuccessCallback, this.addCallReportFailureCallback);
        		} else {
           			CallReportService.updateCallReport(data, this.updateCallReportSuccessCallback, this.updateCallReportFailureCallback);
        		}
            };
            
            // Save call report to local before submit
            $scope.saveCallReportToLocalBeforeSubmit = function(data, callback) {
            	var source = $stateParams.source;
            	LogUtil.logInfo('CallReportCreationCtrl -> saveCallReportToLocalBeforeSubmit, source: ' + source);
            	$scope.tempReport = data;
            	if (source === 'create' && !$scope.isSaved) {
            		CallReportService.addCallReport(data, this.callback, this.callback);
        		} else {
           			CallReportService.updateCallReport(data, this.callback, this.callback);
        		}
            };
            
            // Add call report success callback
            $scope.addCallReportSuccessCallback = function(id) {
            	LogUtil.logInfo('CallReportCreationCtrl -> addCallReportSuccessCallback');
            	$scope.$apply(function(){
            		$scope.reportData.id = id;
            		$scope.isSaved = true;
                   	$scope.lastModifiedDate = CommonUtil.getDateTimeString($filter('date')(Date.now(),'dd MMM yyyy, HH:mm'), true);
            	});
            	$scope.refreshCallReport();
            	busyIndicator.hide();              
            };
            
            // Add call report failure callback
            $scope.addCallReportFailureCallback = function() {
            	LogUtil.logInfo('CallReportCreationCtrl -> addCallReportFailureCallback');
            	busyIndicator.hide();
            };
            
            // Update call report success callback
            $scope.updateCallReportSuccessCallback = function(id) {
            	LogUtil.logInfo('CallReportCreationCtrl -> updateCallReportSuccessCallback');
            	$scope.$apply(function(){
            		$scope.isSaved = true;
                   	$scope.lastModifiedDate = CommonUtil.getDateTimeString($filter('date')(Date.now(),'dd MMM yyyy, HH:mm'), true);
            	});
            	$scope.refreshCallReport();
            	busyIndicator.hide();
            };
            
            // Update call report failure callback
            $scope.updateCallReportFailureCallback = function() {
            	LogUtil.logInfo('CallReportCreationCtrl -> updateCallReportFailureCallback');
            	busyIndicator.hide();
            };
            
            // Delete call report success callback
            $scope.deleteCallReportSuccessCallback = function(id) {
            	LogUtil.logInfo('CallReportCreationCtrl -> deleteCallReportSuccessCallback');
            	busyIndicator.hide();
            };
            
            // Delete call report failure callback
            $scope.deleteCallReportFailureCallback = function() {
            	LogUtil.logInfo('CallReportCreationCtrl -> deleteCallReportFailureCallback');
            	busyIndicator.hide();
            };
            
            // Submit call report success callback
            $scope.submitCallReportSuccessCallback = function(data) {
            	LogUtil.logInfo('CallReportCreationCtrl -> submitCallReportSuccessCallback');
				$scope.deleteCallReport(data.id);
            	busyIndicator.hide();
	            $scope.submitModal.show();
            };
            
            // Submit call report failure callback
            $scope.submitCallReportFailureCallback = function(data) {
            	LogUtil.logInfo('CallReportCreationCtrl -> submitCallReportFailureCallback');
            	busyIndicator.hide();
            	var errorMsg = '';
            	if(data.errorCode){
            		errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_ZPB_FAILURE')+data.errorCode;
            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'), errorMsg, [{text:$translate.instant('BTN_OK'), handler: function() {
                        $state.go('base.call_report_main', {}, {reload: true});
            		}}]);
            	} else {
            		$scope.getNetworkStatus();
            	}	
            };
            
            // Get network status
            $scope.getNetworkStatus = function() {
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('CallReportCreationCtrl -> Network Info : '+networkInfo.isNetworkConnected);
		  			var errorMsg = '';
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_NO_INTERNET_CONNECTION');
	            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'), errorMsg, [{text:$translate.instant('BTN_OK'), handler: function() {
	                        $state.go($state.current, {}, {reload: true});
	            		}}]);
		  			}else{
		  				errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_MFP_CONNECTION_FAILURE');
		  				WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'), errorMsg, [{text:$translate.instant('BTN_OK'), handler: function() {
		  	                $state.go($state.current, {}, {reload: true});
		  				}}]);
		  			}
        		});	 
            };
            
            // Delete call report
            $scope.deleteCallReport = function(id){
        		CallReportService.deleteCallReportByID(id,this.deleteCallReportSuccessCallback,this.deleteCallReportFailureCallback);
        	};
            
        	// Save call report
            $scope.saveCallReport = function() {
            	LogUtil.logInfo('CallReportCreationCtrl -> saveCallReport');
      		    var now = Date.now();
                var reportData = {
                		id: $scope.reportData.id,
                		attendeeList: $scope.getAttendeeList(),
                		staffList: $scope.getStaffList(),
                		meetingDate: $scope.getMeetingDate(),
                		meetingTime: $scope.getMeetingTime(),
                    	venue: $scope.reportData.venue,
                    	mainObjectiveList: $scope.getMainObjectiveList(),
                    	meetingTypeList: $scope.getMeetingTypeList(),
                    	meetingDetailsList: $scope.getMeetingDetailsList(),
                    	lastModifiedDate: now
                };
                $scope.tempReport = reportData;
                if ($scope.validateCallReport(reportData)) {
                	$scope.saveCallReportToLocal(reportData);
                }
            };
            
            // Submit call report
            $scope.submitCallReport = function() {
            	LogUtil.logInfo('CallReportCreationCtrl -> submitCallReport');
            	var now = Date.now();
                var reportData = {
                		id: $scope.reportData.id,
                		attendeeList: $scope.getAttendeeList(),
                		staffList: $scope.getStaffList(),
                		meetingDate: $scope.getMeetingDate(),
                		meetingTime: $scope.getMeetingTime(),
                    	venue: $scope.reportData.venue,
                    	mainObjectiveList: $scope.getMainObjectiveList(),
                    	meetingTypeList: $scope.getMeetingTypeList(),
                    	meetingDetailsList: $scope.getMeetingDetailsList(),
                    	lastModifiedDate: now
                };
                if ($scope.validateCallReport(reportData)) {
                	$scope.saveCallReportToLocalBeforeSubmit(reportData, CallReportService.submitCallReport(reportData, this.submitCallReportSuccessCallback, this.submitCallReportFailureCallback));
                }
            }
            
            // Add attendee text box
            $scope.addNewAttendeeTextBox = function() {
            	var newItemNo = 0;
            	if ($scope.attendeeList && $scope.attendeeList.length > 0) {
            		newItemNo = $scope.attendeeList.length + 1;
            	}
                $scope.attendeeList.push({'id': 'attendee_' + newItemNo});
            };
            
            // Add staff text box
            $scope.addNewStaffTextBox = function() {
            	var newItemNo = 0;
            	if ($scope.staffList && $scope.staffList.length > 0) {
            		newItemNo = $scope.staffList.length + 1;
            	}
                $scope.staffList.push({'id': 'staff_' + newItemNo});
            };
            
            // Remove attendee text box
            $scope.removeAttendeeTextBox = function(id) {
            	$scope.attendeeList.splice(id, 1);
            }
            
            // Remove staff text box
            $scope.removeStaffTextBox = function(id) {
            	$scope.staffList.splice(id, 1);
            }
            
            // Start edit attendee
            $scope.startEditAttendee = function() {
            	$scope.isEditingAttendee = true;
            };
            
            // Finish edit attendee
            $scope.finishEditAttendee = function() {
            	$scope.isEditingAttendee = false;
            }
            
            // Start edit attendee
            $scope.startEditStaff = function() {
            	$scope.isEditingStaff = true;
            };
            
            // Finish edit attendee
            $scope.finishEditStaff = function() {
            	$scope.isEditingStaff = false;
            }
            
            // Get attendee list
            $scope.getAttendeeList = function() {
            	var attendeeList = [];
            	if ($scope.attendeeList && $scope.attendeeList.length > 0) {
            		for (var i = 0; i < $scope.attendeeList.length; i++) {
            			if ($scope.attendeeList[i].name) {
            				attendeeList.push($scope.attendeeList[i].name);
            			}
            		}
            	}
            	return attendeeList;
            }
            
            // Get staff list
            $scope.getStaffList = function() {
            	var staffList = [];
            	if ($scope.staffList && $scope.staffList.length > 0) {
            		for (var i = 0; i < $scope.staffList.length; i++) {
            			if ($scope.staffList[i].name) {
            				staffList.push($scope.staffList[i].name);
            			}
            		}
            	}
            	return staffList;
            }
            
            // Get main objective list
            $scope.getMainObjectiveList = function() {
            	var mainObjectiveList = [];
            	if ($scope.mainObjectiveList && $scope.mainObjectiveList.length > 0) {
            		for (var i = 0; i < $scope.mainObjectiveList.length; i++) {
            			if ($scope.mainObjectiveList[i].selected) {
            				mainObjectiveList.push({
            					'id': $scope.mainObjectiveList[i].id,
            					'remarks': $scope.otherData.mainObjectiveOthers
            				});
            			}
            		}
            	}
            	return mainObjectiveList;
            }
            
            // Get meeting type list
            $scope.getMeetingTypeList = function() {
            	var meetingTypeList = [];
            	var remarks = '';
            	var selectedMeetingType = $scope.otherData.selectedMeetingType;
            	if (selectedMeetingType != undefined && selectedMeetingType != null) {
	            	if ($scope.otherData.selectedMeetingType === 'phone_call') {
	            		remarks = $scope.otherData.meetingTypePhoneExt;
	            	} else if ($scope.otherData.selectedMeetingType === 'others') {
	            		remarks = $scope.otherData.meetingTypeOthers;
	            	}
	            	meetingTypeList.push({
	            		'id': $scope.otherData.selectedMeetingType,
	            		'remarks': remarks
	            	});
            	}
            	return meetingTypeList;
            }
            
            // Get meeting date
            $scope.getMeetingDate = function() {
            	var meetingDate = null;
            	var date = $scope.otherData.meetingDateTime;
            	if (date != undefined && date != null && date instanceof Date) {
            		meetingDate = $filter('date')(date, 'yyyy-MM-dd','+0000');
            	}
            	return meetingDate;
            }
            
            // Get meeting time
            $scope.getMeetingTime = function() {
            	var meetingTime = null;
            	var date = $scope.otherData.meetingDateTime;
            	if (date != undefined && date != null && date instanceof Date) {
            		meetingTime = $filter('date')(date, 'HH:mm:ss','+0000');
            	}
            	return meetingTime;
            }
            
            // Get meeting details
            $scope.getMeetingDetailsList = function() {
            	var meetingDetailsList = [];
            	if ($scope.meetingDetailsData) {
                	meetingDetailsList.push({
        				'id': 'background',
        				'remarks': $scope.meetingDetailsData['background']
        			});
                	meetingDetailsList.push({
        				'id': 'topic_discussed',
        				'remarks': $scope.meetingDetailsData['topic_discussed']
        			});
                	meetingDetailsList.push({
        				'id': 'products_introduced',
        				'remarks': $scope.meetingDetailsData['products_introduced']
        			});
                	meetingDetailsList.push({
        				'id': 'follow_up',
        				'remarks': $scope.meetingDetailsData['follow_up']
        			});
                	meetingDetailsList.push({
        				'id': 'others',
        				'remarks': $scope.meetingDetailsData['others']
        			});
            	}
            	return meetingDetailsList;
            }
            
            // Validate call report
            $scope.validateCallReport = function(reportData) {
            	// Meeting Date is mandatory
            	if (reportData.meetingDate === null || reportData.meetingDate === undefined || reportData.meetingDate === '') {
            		$scope.errorMsg = $translate.instant('ERR_MEETING_DATE_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// Meeting Time is mandatory
            	if (reportData.meetingTime === null || reportData.meetingTime === undefined || reportData.meetingTime === '') {
            		$scope.errorMsg = $translate.instant('ERR_MEETING_TIME_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// If Meeting Type is face_to_face, Venue is mandatory
            	if (reportData.meetingTypeList && reportData.meetingTypeList.length > 0 && reportData.meetingTypeList[0].id === 'face_to_face' && 
            			(reportData.venue === null || reportData.venue === undefined || reportData.venue === '')) {
            		$scope.errorMsg = $translate.instant('ERR_VENUE_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// If Meeting Type is others, Others textbox is mandatory
            	if (reportData.meetingTypeList && reportData.meetingTypeList.length > 0 && reportData.meetingTypeList[0].id === 'others' && 
            			(reportData.meetingTypeList[0].remarks === null || reportData.meetingTypeList[0].remarks === undefined || reportData.meetingTypeList[0].remarks === '')) {
            		$scope.errorMsg = $translate.instant('ERR_MEETING_TYPE_OTHERS_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// If Meeting Type is phone_call, Others textbox is mandatory
            	if (reportData.meetingTypeList && reportData.meetingTypeList.length > 0 && reportData.meetingTypeList[0].id === 'phone_call' && 
            			(reportData.meetingTypeList[0].remarks === null || reportData.meetingTypeList[0].remarks === undefined || reportData.meetingTypeList[0].remarks === '')) {
            		$scope.errorMsg = $translate.instant('ERR_MEETING_TYPE_PHONE_CALL_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// If Meeting Objective is others or phone_call, Others textbox is mandatory
            	var meetingObjectiveOthers = $filter('filter')(reportData.mainObjectiveList, {id : 'others'});
            	if (meetingObjectiveOthers !== null && meetingObjectiveOthers.length !== 0 && 
            			(meetingObjectiveOthers[0].remarks === null || meetingObjectiveOthers[0].remarks === undefined || meetingObjectiveOthers[0].remarks === '')) {
            		$scope.errorMsg = $translate.instant('ERR_MEETING_OBJECTIVE_OTHERS_EMPTY');
            		$scope.hasError = true;
            		return false;
            	}
            	// Reset error message if validation is passed
            	if (!$scope.hasError) {
            		$scope.$apply(function(){
                		$scope.hasError = false;
                	});
            	}
            	$scope.errorMsg = "";
            	return true;
            }
            
            // Call initialize
            $scope.init();
        }
    ]);
});