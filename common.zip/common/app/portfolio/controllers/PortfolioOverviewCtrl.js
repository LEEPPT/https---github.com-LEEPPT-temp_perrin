define([
  'app/app',
  'app/portfolio/services/CustomerPortfolioService',
  'js/Util/ChartGenerator',
  'js/Util/LogUtil',
  'js/Util/Validation',
  'js/appConfig',
  'js/appState',
  'js/constants',
  'js/Util/FunctionActivator'
], function (app, CustomerPortfolioService, ChartGenerator, LogUtil, Validation, AppConfig, AppState, Constants, FunctionActivator) {
  'use strict';

  app.controller('PortfolioOverviewCtrl', [
	'$scope',
    'CustomerPortfolioService',
    '$translate',
    '$stateParams',
    '$filter',
    '$ionicModal',
    '$state',
    '$ionicHistory',
    function ($scope,CustomerPortfolioService,$translate,$stateParams, $filter,$ionicModal,$state, $ionicHistory) {
		
		$scope.init = function(){
			$scope.assetAllocationData = [];
			$scope.chartApi = {};
			$scope.colorMap = ChartGenerator.getCategoryColorMap();
			
			$scope.hasAssetClassNegativeVal = false;
			$scope.isTotalAUMZero = false;
			$scope.currentLang = AppState.currentLangCode;
					
			$scope.bottomChartHeight = '220';

			var portfolioID = $stateParams.id;
			$scope.loadFunctionActivation();
			CustomerPortfolioService.getCustomerPortfolioByID(portfolioID, this.getPortfolioSuccessCallback);
		};
		
		$scope.getPortfolioSuccessCallback = function(data) {
			$scope.portfolioName = data.portfolioName;
			$scope.portfolioCurrency = $translate.instant(data.portfolioCurrency);
			$scope.nat = $filter('currency')(data.totalAUM, '', 2);
			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate(data);
			
			if (!Validation.isEmpty(data.performanceAnalysis) && data.performanceAnalysis.detailsList!==undefined && data.performanceAnalysis.detailsList !== null && data.performanceAnalysis.detailsList.length > 0) {
				$scope.setReturnPercentages(data);
			}
			
			$scope.portfolioData = data;
			$scope.displayLatestAssetAllocation(data);
			
			if (data.totalAUM === 0) {
				$scope.isTotalAUMZero = true;
			}
			
			data.hasAssetClassNegativeVal = $scope.hasAssetClassNegativeVal;
			data.isTotalAUMZero = $scope.isTotalAUMZero;
			
			$scope.setLinkSet(data);
		};
		$scope.setReturnPercentages = function(data) {
			//add by LGM 20160419 start
			$scope.monthlyReturnPercentBigger = '';
			$scope.monthlyReturnPercentSmaller = '';
			$scope.yearReturnPercentBigger = '';
			$scope.yearReturnPercentSmaller = '';
			$scope.monthlyReturnPercentIcon = '';
			$scope.monthlyReturnPercentSign = '';
			$scope.yearReturnPercentIcon = '';
			$scope.yearReturnPercentSign = '';
			
			var monthlyReturnPercen = data.performanceAnalysis.detailsList[0].monthlyReturnPercent;
			if (monthlyReturnPercen === null) monthlyReturnPercen = 0;
			var monthlyReturnPercentArray = monthlyReturnPercen.toFixed(2).split(".");
			$scope.monthlyReturnPercentBigger = monthlyReturnPercentArray[0];
			$scope.monthlyReturnPercentSmaller = '.'+monthlyReturnPercentArray[1];
			var yearReturnPercent = data.performanceAnalysis.detailsList[0].yearToLastSixMonthReturnPercent;
			if (yearReturnPercent === null) yearReturnPercent = 0;
			var yearReturnPercentArray = yearReturnPercent.toFixed(2).split(".");
			$scope.yearReturnPercentBigger = yearReturnPercentArray[0];
			$scope.yearReturnPercentSmaller = '.'+yearReturnPercentArray[1];
			$scope.monthlyReturnPercentIcon = (monthlyReturnPercen >= 0)?'ion-arrow-up-a':'ion-arrow-down-a';
			$scope.yearReturnPercentIcon = (yearReturnPercent >= 0)?'ion-arrow-up-a':'ion-arrow-down-a';
			$scope.monthlyReturnPercentSign = '%';
			$scope.yearReturnPercentSign = '%';
			
			if($scope.monthlyReturnPercentBigger.length > 5) {
				$scope.monthLen = 6;
			} else {
				$scope.monthLen = $scope.monthlyReturnPercentBigger.length;
			}
			
			if($scope.yearReturnPercentBigger.length > 5) {
				$scope.yearLen = 6;
			} else {
				$scope.yearLen = $scope.yearReturnPercentBigger.length;
			}
			LogUtil.logInfo("PortfolioOverviewCtrl -> setReturnPercentages : mon : " + $scope.monthLen + "   year="+ $scope.yearLen );
			//add by LGM 20160419 end
		};
		$scope.setLinkSet = function(data) {
			$scope.linkTitle = [$translate.instant('PO_ACCOUNT_DETAILS'), $translate.instant('PO_PORTFOLIO_HOLDINGS'), $translate.instant('PO_PORTFOLIO_COMPARISON'), $translate.instant('PO_TARGET_PORTFOLIO'), $translate.instant('PO_RAQ')];
			$scope.linkHref = ['#account_details','#portfolio_holdings','#portfolio_comparison','#target_portfolio','#raq'];
			var linkSet = [];
			for (var i = 0 ; i < $scope.linkTitle.length ; i++) {
				if (!$scope.isAccessibleToFNTargetPortfolio && $scope.linkHref[i] === '#target_portfolio') {
					continue;
				} else if ((data.hasAssetClassNegativeVal) && ($scope.linkHref[i] === '#portfolio_comparison' || $scope.linkHref[i] === '#target_portfolio')) {
					continue;
				} else if ((data.isTotalAUMZero) && ($scope.linkHref[i] === '#target_portfolio')) {
					continue;
				}
				linkSet.push({
					title: $scope.linkTitle[i].toUpperCase(),
					href: $scope.linkHref[i]
				});
			}
			$scope.linkSet = linkSet;
		};
		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
    		scope : $scope
    	}).then(function(modal){
    		$scope.disclaimerModal = modal;
    	});
    	$scope.showDisclaimer = function() {
    		$scope.disclaimerModal.show();
    	};
    	$scope.hideDisclaimer = function() {
    		$scope.disclaimerModal.hide();
    	};
    	$scope.showDetail = function (label, needApply) {
    		LogUtil.logInfo('PortfolioOverviewCtrl -> showDetail : assetShown : '+$scope.assetShown);
    		if (label === $scope.assetShown) {
    			$scope.slideOutAssetDetailToRight();
    			$scope.assetShown = '';
                return;
    		}
            for (var i = 0; i < this.assetAllocationData.length ; i++) {
                if (this.assetAllocationData[i].assetClassID === label) {
                	$scope.displayAssetHistory(this.portfolioData,label);
                	
                	$scope.reduceChartAndLegendOpacity();
	    			$scope.restoreOpacityOfAsset($scope.assetAllocationData[i].assetClassID, $scope.assetAllocationData[i].color);
               	 	if ($scope.assetShown === undefined || !$scope.assetShown || '' === $scope.assetShown) {
               		 	$('.portfolio_overview_asset_details').animate({right:'+=320px'},400,'swing',$scope.toShowAssetDetails);
    	    		}
    	    		$scope.assetShown = label;
                    
                    var detail = {
                    	category: $scope.assetAllocationData[i].legendLabel,
                    	amount : $filter('number',2)($scope.assetAllocationData[i].amount),
                    	percentage : $scope.assetAllocationData[i].percentage,
                    	holdingCNT : 0
                    };

                    for (var j = 0 ; j < this.portfolioData.portfolioHoldingsList.length; j++) {
                    	if ((this.portfolioData.portfolioHoldingsList[j].sectionID === this.assetAllocationData[i].assetClassID) && this.portfolioData.portfolioHoldingsList[j].contentList &&this.portfolioData.portfolioHoldingsList[j].contentList.length > 0) {
                    		detail.holdingCNT = this.portfolioData.portfolioHoldingsList[j].contentList.length;
                    	}
                    }
                    $scope.detail = detail;
                    if (needApply) { $scope.$apply(); }
                } 
            }
    	};
    	$scope.reduceChartAndLegendOpacity = function() {
			$('.nv-pie .nv-slice').stop().animate({opacity : 0.4});
            $('.asset_allocation_entry').stop().animate({opacity : 0.4});
            $('.portfolio_overview_charts').stop().animate({opacity : 0.4});
    	};
    	$scope.restoreOpacityOfAsset = function(assetClassID, color) {
			$('.nv-pie .nv-slice[fill="'+color+'"]').stop().animate({'opacity':1});
            $('.asset_allocation_entry.'+assetClassID).stop().animate({'opacity':1});
    	};
    	$scope.slideOutAssetDetailToRight = function() {
			$('.portfolio_overview_asset_details').animate({right:'-=320px'},400,'swing',$scope.toHideAssetDetails);
            $('.nv-pie .nv-slice').animate({opacity:1});
            $('.asset_allocation_entry').animate({opacity:1});
            $('.portfolio_overview_charts').animate({opacity:1});
    	};
    	$scope.toHideAssetDetails = function() {
			$('.portfolio_overview_asset_details').css('right','-358px');
		};
		$scope.toShowAssetDetails = function(){
			$('.portfolio_overview_asset_details').css('right','-38px');
		};
    	$scope.goPortfolioHoldings = function() {
    		var param = {
    				data: angular.toJson(this.portfolioData),
    				assetCategory : $scope.assetShown
    				};
    		$state.go('base.portfolio_holdings', param, {reload: true});
    	};
    	$scope.goCurrencyDistribution = function(){
			var param = {
	    			data: angular.toJson(this.portfolioData)
	    		};
			$state.go('base.currency_distribution', param, {reload: true});
		};
		$scope.goAssetHistory = function(category){
			var param = {
	    			data: angular.toJson(this.portfolioData)
	    		};
			if (category) {
				param.specificAsset = category;
			}
			$state.go('base.portfolio_history', param, {reload: true});
		};
		$scope.goPerformanceDetail = function(){
			var param = {
	    			data: angular.toJson(this.portfolioData)
	    		};
			$state.go('base.portfolio_performance', param, {reload: true});
		};
		
    	// Function to redirect the links in right hand side
		$scope.redirect = function(link) {
			var param = {};
			if (link === '#account_details') {
				param.data = angular.toJson(this.portfolioData);
		    	$state.go('base.account_details', param, {reload: true});
			} else if (link === '#portfolio_holdings') {
				$scope.goPortfolioHoldings();
			} else if (link === '#portfolio_comparison') {
				param.data = angular.toJson(this.portfolioData);
			    $state.go('base.portfolio_comparison', param, {reload: true});
			} else if (link === '#target_portfolio') {
				param = {
			    	data: angular.toJson(this.portfolioData),
			    	source : 'portfolio_overview'
			    };
			    $state.go('base.target_portfolio', param, {reload: true});
			} else if (link === '#raq') {
			    $state.go('base.raq_select_customer_type', param, {reload: true});
			}
		};
		$scope.displayLatestAssetAllocation = function(data) {
			if (!data.assetAllocationHistoryList || data.assetAllocationHistoryList.length === 0) {
				LogUtil.logInfo('PortfolioOverviewCtrl -> displayLatestAssetAllocation : Cannot obtain assetAllocationHistoryList for this portfolio');
				return;
			}
			for (var i = 0 ; i < data.assetAllocationHistoryList[0].detailsList.length; i++) {
				var entry = data.assetAllocationHistoryList[0].detailsList[i];
				if (typeof entry.percentage === 'undefined') {
					entry.percentage = ((entry.amount/data.totalAUM)*100).toFixed(2);
				}
				if (Number(entry.amount) < 0) {
					$scope.hasAssetClassNegativeVal = true;
				}
				if (Number(entry.amount) !== 0 ) {
					this.assetAllocationData.push(entry);
				}
			}
			LogUtil.logInfo('PortfolioOverviewCtrl -> displayLatestAssetAllocation : assetAllocationData '+this.assetAllocationData.length);
			if (this.assetAllocationData.length === 0) {
				$scope.isTotalAUMZero = true;
			}
			
            $scope.setAssetAllocationChartData();
		};
		$scope.setAssetAllocationChartData = function() {
			var portfolioAssetClassList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
            var legendConfig = new Map();
            var _this = this;
            portfolioAssetClassList.forEach(function(item) {
            		legendConfig.set(item.key,{label: $translate.instant(item.key),color: _this.colorMap.get(item.key)});
    	    });
            LogUtil.logInfo('PortfolioOverviewCtrl -> setAssetAllocationChartData : legendConfig '+legendConfig.size);
            
            $scope.assetAllocationData = ChartGenerator.createLegendByData($scope.assetAllocationData,legendConfig);
            $scope.displayAllocationData = [];
			for (i = 0 ; i < $scope.assetAllocationData.length ; i++) {
				var row = [($scope.assetAllocationData[i])];

				if(i !== $scope.assetAllocationData.length-1) {
					row.push($scope.assetAllocationData[++i]);
				}
				$scope.displayAllocationData.push(row);
			}
			var donutChartOption = ChartGenerator.createBasicDonutChartOption();
	    	donutChartOption.chart.pie = {
	    		dispatch : {
                    elementClick : function (e) {
                    	$scope.showDetail(e.data.key,true);
                    }
	    		}
	    	};
	    	var assetAllocationChartData = [];
            
	    	for (i = 0 ; i < $scope.assetAllocationData.length ; i++) {
	    		var obj = {
	    				key : $scope.assetAllocationData[i].assetClassID,
	    				y: Number($scope.assetAllocationData[i].percentage),
	    				color : $scope.assetAllocationData[i].color
	    		};
	    		assetAllocationChartData.push(obj);
            }
	    	$scope.assetAllocationChart = {
	    		options : donutChartOption,
	    		data :assetAllocationChartData
	    	};
		};
		$scope.displayCurrencyDistribution = function(data){
			var currencyDistributionChartOption = $scope.getCurrencyDistributionChartOptions();

			var currencyDistributionData = [];
	    	if (data.currencyDistributionList.length === 0) {
	    		currencyDistributionData.push({x : '', y : 0});
	    		currencyDistributionChartOption.chart.forceY = [0,1];
	    		currencyDistributionChartOption = $scope.setChartNoDataStyle(currencyDistributionChartOption);
	    	} else {
	    		data.currencyDistributionList.forEach(function(item) {
		    		if (Number(item.amount) !== 0) {
			    		currencyDistributionData.push({x : item.currency, y : Number(item.amount)});
		    		}
		    	});
	    		if (data.currencyDistributionList.length === 1) {
	    			currencyDistributionData = [{
	    				x: '',
	    				y: 0
                    }, currencyDistributionData[0], {
                        x: ' ',
                        y: 0
                    }];
                }
	    	}
	    	
			$scope.currencyDistributionChart = {
	    		options:currencyDistributionChartOption,
	    		data : [
    		        {
					    key: 'Currency Distribution',
					    values: currencyDistributionData
					}
	    		]
		    };
		};
		$scope.getCurrencyDistributionChartOptions = function() {
			var currencyDistributionChartOption = ChartGenerator.createBasicBarChartOption();
	    	currencyDistributionChartOption.chart.height = $scope.bottomChartHeight;
	    	if ($scope.enabled30Group === 2 && $scope.enabled40Group === 1) {
	    		currencyDistributionChartOption.chart.width = 280;
	    	}

	    	currencyDistributionChartOption.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
	    	currencyDistributionChartOption.chart.yAxis.rotateYLabel = false;
	    	currencyDistributionChartOption.chart.yAxis.axisLabel = $scope.portfolioCurrency;
	    	currencyDistributionChartOption.chart.yAxis.axisLabelDistance = -18;
	    	currencyDistributionChartOption.chart.margin.left = 50;
	    	currencyDistributionChartOption.chart.multibar = {
	    		dispatch: {
	    			elementClick: function() {
	    				$scope.goCurrencyDistribution();
                    }
                }
	    	};
	    	var currencyChartColorSets = ChartGenerator.getGoldenColorSet();
	    	currencyDistributionChartOption.chart.color = function(d) {
	    		if (d >= 0) {
	    			return currencyChartColorSets[0];
	    		}else {
	    			return currencyChartColorSets[1];
	    		}
	    	};
	    	return currencyDistributionChartOption;
		};
		$scope.displayPortfolioHistory = function(data){
			var historyChartOption = $scope.getPortfolioHistoryChartOptions();
            var historyData = [];

            var cateData = {};
            cateData.key = 'net_asset_values';
            cateData.values = [];
            cateData.color = this.colorMap.get('net_asset_values');
            		            	
            var selectedMonthData = data.netAssetValueHistoryList.length > 2 ? data.netAssetValueHistoryList.slice(0,3) : data.netAssetValueHistoryList;
            var isAllZero = true;
            for (var i = 2; i >= 0 ; i--) {
            	var monthData = selectedMonthData[i];
            	if (monthData) {
	            	for (var n in monthData.detailsList) {
	            		var item = monthData.detailsList[n];
	            		if (item.category === 'net_asset_values') {
	            			var amount = Number(item.amount);
	            			if (amount !== 0) { isAllZero = false; }
	            			cateData.values.push({x : monthData.month, y : amount});
	            		}
	            	}
            	} else {
            		$scope.isPortfolioHistoryError = true;
            		break;
            	}
            }
            if (isAllZero) { 
            	historyChartOption = $scope.setChartNoDataStyle(historyChartOption); 
            }
            historyData.push(cateData);
            
			$scope.portfolioHistoryChart = {
		    		options:historyChartOption,
		    		data : historyData
		    };
		};
		$scope.getPortfolioHistoryChartOptions = function () {
			var historyChartOption = ChartGenerator.createBasicBarChartOption();
            historyChartOption.chart.height = $scope.bottomChartHeight;
            historyChartOption.chart.xAxis.tickFormat = ChartGenerator.axisMonthFormatter;
            historyChartOption.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
            historyChartOption.chart.yAxis.rotateYLabel = false;
            historyChartOption.chart.forceY = [0];
            historyChartOption.chart.multibar = {
        		dispatch : {
        			elementClick : function () {
                    	$scope.goAssetHistory();
                    }
        		}
            };
            historyChartOption.chart.yAxis.axisLabel = $scope.portfolioCurrency;
            historyChartOption.chart.yAxis.axisLabelDistance = -18;
            historyChartOption.chart.margin.left = 50;
           
            return historyChartOption;
		};
		$scope.displayAssetHistory = function(data,category){
			var assetHistoryChartOption = $scope.getAssetHistoryChartOptions();
			
	        var assetHistoryData = [];

	        var cateData = {};
        	cateData.key=category;
        	cateData.values = [];
        	cateData.color = this.colorMap.get(category);

        	var selectedMonthData = data.assetAllocationHistoryList.length >= 3 ? data.assetAllocationHistoryList.slice(0,3) : data.assetAllocationHistoryList;
        	for (var index = selectedMonthData.length - 1 ; index >= 0; index--) {
        		var monthData = selectedMonthData[index];
        		for (var i in monthData.detailsList) {
        			var item = monthData.detailsList[i];
        			if (item.assetClassID === category) {
        				item.amount = Number(item.amount);
        				cateData.values.push({x : monthData.month, y : item.amount});
        			}
        		}
        	}
        	
	        assetHistoryData.push(cateData);

	        $scope.assetHistoryChart = {
	        	options:assetHistoryChartOption,
			   	data : assetHistoryData
			};
		};
		$scope.getAssetHistoryChartOptions = function() {
			var assetHistoryChartOption = ChartGenerator.createBasicBarChartOption();
			assetHistoryChartOption.chart.height = this.bottomChartHeight;
			assetHistoryChartOption.chart.xAxis.tickFormat = ChartGenerator.axisMonthFormatter;
			assetHistoryChartOption.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
			assetHistoryChartOption.chart.yAxis.rotateYLabel = false;
			assetHistoryChartOption.chart.yAxis.axisLabel = $scope.portfolioCurrency;
			assetHistoryChartOption.chart.yAxis.axisLabelDistance = 0;
			assetHistoryChartOption.chart.multibar = {
				dispatch : {
					elementClick : function () {
						$scope.goAssetHistory($scope.assetShown);
					}
				}
			};
			return assetHistoryChartOption;
		};
		$scope.displayPerformance = function(data){
			var performanceChartOption = $scope.getPerformanceChartOptions();
			 	
		 	var performanceData = [];
		 	var xTicks = 0;
		 	var lastedYear;
		 	if (!Validation.isEmpty(data.performanceAnalysis) && data.performanceAnalysis.detailsList !==undefined && data.performanceAnalysis.detailsList !== null && data.performanceAnalysis.detailsList.length > 0) {
		 		var selectedMonthData = data.performanceAnalysis.detailsList.length > 6 ? selectedMonthData = data.performanceAnalysis.detailsList.slice(0,6) : data.performanceAnalysis.detailsList;
		 		
	            if (selectedMonthData !== null && selectedMonthData.length > 0) {
	            	for (var i = 0; i < selectedMonthData.length ; i++) {
		            	var monthData = selectedMonthData[i];
		            	if (i === 0) {
		            		lastedYear = monthData.year;
		            	}
		            	performanceData.push({x : $scope.convertMonth(monthData.month, monthData.year, lastedYear), y : Number(monthData.yearToLastSixMonthReturnPercent)});
		            	xTicks++;
		            }
	            }
		 	}
		 	performanceChartOption.chart.xAxis.ticks = xTicks;
		 	
			$scope.performanceChart = {
	    		options:performanceChartOption,
	    		data : [
    		        {
    		        	key : 'Performance',
    		        	values : performanceData,
    		        	color: '#3FA9F5',
    		        	area: true
    		        }
	    		]
		    };
		};
		$scope.highlightPoints = function() {
			var target = d3.select('#performanctChart svg');
			if ($scope.hasZeroResultD3Select(target)) { return; }
			var data = d3.select('#performanctChart svg').datum();
            
			target = d3.select('#performanctChart .nv-groups');
			if ($scope.hasZeroResultD3Select(target)) { return; }

            d3.select('#performanctChart .nv-groups')
                .selectAll("circle.linePoint")
                .remove();
            
            target = d3.select('#performanctChart .nv-groups');
			if ($scope.hasZeroResultD3Select(target)) { return; }

            var points = d3.select('#performanctChart .nv-groups')
                .selectAll("circle.linePoint")
                .data(data[0].values);
            
            points.enter().append("circle")
                .attr("class", "linePoint")
                .attr("cx", function(d) { return $scope.chartApi.performance.getScope().chart.xAxis.scale()(d.x); })
                .attr("cy", function(d) { return $scope.chartApi.performance.getScope().chart.yAxis.scale()(d.y); })
                .attr("r", 5);
		};
		$scope.convertMonth = function(currentMonth, currentYear, lastedYear) {
			if (currentYear == lastedYear) {
				return currentMonth;
			} else {
				return currentMonth - 12;
			}
		};
		$scope.getPerformanceChartOptions = function() {
			var performanceChartOption = ChartGenerator.createBasicLineChartOption();
		 	performanceChartOption.chart.height = this.bottomChartHeight;
		 	performanceChartOption.chart.xAxis.tickFormat = ChartGenerator.axisMonthYearFormatter3;
		 	performanceChartOption.chart.yAxis.tickFormat = ChartGenerator.axisPercentFormater;
		 	performanceChartOption.chart.xAxis.axisLabel = '';
            performanceChartOption.chart.xAxis.rotateLabels = -45;
            performanceChartOption.chart.yAxis.axisLabel = '';
            performanceChartOption.chart.yAxis.axisLabelDistance = 0;
            performanceChartOption.chart.yAxis.showMaxMin = true;
            performanceChartOption.chart.forceY = [0];
		 	performanceChartOption.chart.callback = $scope.highlightPoints;
		 	performanceChartOption.chart.lines = {
			 		dispatch: {
			 			renderEnd: function(){
			            	$scope.highlightPoints();
			        	}
	            	}
            };
		 	return performanceChartOption;
		};
		$scope.getPortfolioFailureCallback = function() {
			alert('Cannot retrieve data for this portfolio');
		};
		$scope.hasZeroResultD3Select = function(res) {
			return (res.length === 1 && res[0].length === 1 && res[0][0] === null) ? true : false;
		};
		$scope.stylingByStringLen = function(_str,_sclPoint,_valPoint) {
			var styles = "", scalePoint = _sclPoint, valuePoint = _valPoint,
				numStr = (_str+"").replace(/[&\/\\#,+()$~%.'":*?<>{}]/g,""),
				numLen = numStr.length,
				spcChrLen = (_str+"").length - numLen,
				strLenScale = numLen + (spcChrLen/2),
				scaleMeasure = strLenScale - scalePoint;
			
			if (scaleMeasure > 0)
			styles += "font-size:"+(valuePoint-scaleMeasure)+"px";
			return styles;
		};
		$scope.loadFunctionActivation = function() {
			// By Module
			$scope.isAccessibleToModuleTargetPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_TARGET_PROF);
			$scope.isAccessibleToModuleCustomerPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CUST_PROF);
			$scope.isAccessibleToModuleRAQ = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_RAQ);
			// By Function
			$scope.isAccessibleToFNAccountDetails = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_ACCOUNT_DETAILS);
			$scope.isAccessibleToFNPortfolioHoldings = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HOLDINGS);
			$scope.isAccessibleToFNPortfolioComparison = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_COMPARISON);
			$scope.isAccessibleToFNTargetPortfolio = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_TARGET_PORTFOLIO);
			$scope.isAccessibleToFNRAQ = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_RAQ);
			
			$scope.isAccessibleToFNCurrencyDistribution = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_CURRENCY_DISTRIBUTION);
			$scope.isAccessibleToFNPortfolioHistory = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HISTORY);
			$scope.isAccessibleToFNPerformance = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PERFORMANCE);

			$scope.columnWidth30Group = [$scope.isAccessibleToFNCurrencyDistribution, $scope.isAccessibleToFNPortfolioHistory];
			$scope.columnWidth40Group = [$scope.isAccessibleToFNPerformance];
			
			var enabled30Group = 0, enabled40Group = 0;
			$scope.columnWidth30Group.forEach(function(item){ enabled30Group += (item ? 1 : 0); });
			$scope.columnWidth40Group.forEach(function(item){ enabled40Group += (item ? 1 : 0); });
			$scope.enabled30Group = enabled30Group;
			$scope.enabled40Group = enabled40Group;
			
	        if ($scope.isAccessibleToModuleCustomerPortfolio === false) {
	        	FunctionActivator.showAccessDeniedMessage($ionicHistory);
	        	return;
			}
		};
		$scope.isAccessibleToLinks = function(href) {
			var mapping = {
				'#account_details' : $scope.isAccessibleToFNAccountDetails,
				'#portfolio_holdings' : $scope.isAccessibleToFNPortfolioHoldings,
				'#portfolio_comparison' : $scope.isAccessibleToFNPortfolioComparison,
				'#target_portfolio' : $scope.isAccessibleToFNTargetPortfolio,
				'#raq' : $scope.isAccessibleToFNRAQ
			};
			return mapping[href];
		};
		$scope.getColumnWidthClass = function(column) {
			var width = "";
			
			if ('performance' === column && $scope.isAccessibleToFNPerformance) {
				if ($scope.enabled30Group === 1) {
					width = 'col-60';
				} else if ($scope.enabled30Group === 2) {
					width = 'col-40';
				}
			} else {
				if (("currencyDistribution" === column && $scope.isAccessibleToFNCurrencyDistribution) || ("history" === column && $scope.isAccessibleToFNPortfolioHistory)) {
					if ($scope.enabled40Group === 0 && $scope.enabled30Group === 2) {
						width = 'col-50';
					} else if ($scope.enabled40Group === 1 && $scope.enabled30Group === 1) {
						width = 'col-40';
					} else if ($scope.enabled40Group === 1 && $scope.enabled30Group === 2) {
						width = 'col-30';
					}
				}
			}
			return width;
		};
		$scope.setChartNoDataStyle = function(option) {
			option.chart.forceY = [0,1];
	 		option.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
	 		option.chart.xAxis.showMaxMin = false;
	 		
	 		return option;
		};
		$scope.init();
		$scope.displayCurrencyDistribution($scope.portfolioData);
		$scope.displayPortfolioHistory($scope.portfolioData);
		$scope.displayPerformance($scope.portfolioData);
    }
  ]);
  /*
   * Adjust chart width after "ng-class" rendered
   * http://stackoverflow.com/questions/27786814/watch-to-monitor-change-in-class-on-directive-firing-1-cycle-late
   */
  app.directive('flexibleDiv', function() {
      return {
          scope: {
              opts: '='
          },
          link: function(scope, element, attr) {
              scope.$watch(function() {
                  return element.attr('class');
              }, updateWidth);

              function updateWidth() {
                  setTimeout(function() {
                      scope.opts.chart.width = element.find("nvd3").parent().width();
                      element.css('opacity', 1);
                  }, 0);
              }
          }
      };
  });
});
