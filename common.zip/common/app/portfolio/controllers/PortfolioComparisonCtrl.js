define([
    'app/app',
    'app/portfolio/services/CustomerPortfolioService',
    'js/Util/ChartGenerator',
    'js/appConfig',
	'js/constants',
	'js/appState',
    'js/Util/FunctionActivator',
    'js/Util/LogUtil'
  ], function (app,CustomerPortfolioService,ChartGenerator,AppConfig,Constants,AppState,FunctionActivator,LogUtil) {
    'use strict';

    app.controller('PortfolioComparisonCtrl', [
        '$scope',
    	'CustomerPortfolioService',
    	'$translate',
    	'$stateParams',
    	'$filter',
        '$state',
        '$ionicSideMenuDelegate',
        '$ionicModal',
    	function ($scope, CustomerPortfolioService, $translate, $stateParams, $filter, $state, $ionicSideMenuDelegate, $ionicModal) {
        	
        	$scope.init = function () {
        		$scope.data = angular.fromJson($stateParams.data);
        		
        		$scope.portfolioName = $scope.data.portfolioName;

    			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);

        		for (var l in $scope.modelLibSets) {
        			$scope.modelLibSets[l].label = $translate.instant("std_pf_model_" + $scope.modelLibSets[l].model);
        		}
        		for (var c in $scope.currentDataSet) {
        			$scope.currentDataSet[c].label = $translate.instant("std_pf_model_" + $scope.currentDataSet[l].model);
        			$scope.currentDataTotal += $scope.currentDataSet[c].value;
        		}
        		
        		var currentData = [];
        		$scope.data.assetAllocationHistoryList[0].detailsList.forEach(function(item){
        			currentData.push({
        				name : item.assetClassID || item.category,
        				value : item.percentage
        			});
        		});
        		$scope.currentDataSet = currentData;
        		
        		$scope.assembleModelData();
        		$scope.isAccessibleToTargetPortfolio = (FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_TARGET_PORTFOLIO) && $scope.data.totalAUM !== 0);

        	};

    		$scope.contentLayoutIndex = 1;
    		$scope.contentLayoutLib = [{ name: "graph", label: $translate.instant("PC_GRAPH"), selector: ".model-data-container .chart-container", checked: false},
    		                           { name: "table", label: $translate.instant("PC_DETAILS"), selector: ".model-data-container .table-container", checked: true}];
    		$scope.contentLayoutShowTable = true;
    		
    		$scope.currentDataTotal = 0;
     		$scope.modelLibSets = AppConfig.systemParam.stdPortfolioModel.modelList;
    		$scope.portfolioModelData = [];
    		$scope.modelTableData = [];
    		$scope.portfolioModelIndex = 0;
    		$scope.portfolioModelAssetTotal = 0;
    		$scope.portfolioModelChart = {};
    		$scope.calPercentage = function(_val){
    			if (_val === 0) return "0.00";
    			return (_val).toFixed(2);
    		};
    		$scope.calDividing = function (_val,_base) {
    			return this.calPercentage((_val / _base) * 100);
    		};
    		$scope.capitalize = function(_str) {
    			return _str.replace(/_n_/g," & ").replace(/_/g," ")
    			.replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); });
    		};
    		$scope.getAssetPercentage = function(_amount,_type) {
    			var denom = (_type=="current")?this.currentDataTotal:this.portfolioModelAssetTotal;
    			return this.calDividing(_amount,denom);
    		};
    		$scope.getModelDiffFromCurrent = function(_idx) {
    			var result = Number(this.currentDataSet[_idx].value) - Number(this.modelLibSets[this.portfolioModelIndex].distribution[_idx].value);
    			return this.calPercentage(result);
    		};
    		$scope.assembleModelData = function() {
        		var donutChartOption = ChartGenerator.createBasicModelChartOption();
        		var donutChartColorSets = ChartGenerator.getCategoryColorMap();
                var bulletChartOption = ChartGenerator.createBasicBulletChartOption();
                bulletChartOption.chart.width = 450;
                                
                var bulletChartData = [];
                var multiBarData = [],  multiBarDataLastRow = [];

    			this.portfolioModelData = [];
    			this.modelTableData = [];
    			this.portfolioModelAssetTotal = 0;
    			var maxRange = 0;
    			var len = this.modelLibSets[this.portfolioModelIndex].distribution.length - 1;
    			/*
    			 * When using a big nvd3 div instead of one nvd3 chart in one row
    			 * 
    			 * entries with 0 value are still presented in the graph and this is not what we want
    			 * 
    			 * For example, when showing Savings & current. There will be a space which are 0-value bars for "time deposit", "bond", etc...
    			 * 
    			 */
        		for (var itm in this.modelLibSets[this.portfolioModelIndex].distribution) {
                    var currentValue = $scope.currentDataSet[itm].value;
        			var modelData = this.modelLibSets[this.portfolioModelIndex].distribution;
        			
        			this.portfolioModelData.push({
        				key: modelData[itm].assetClass,
        				y: modelData[itm].value,
        				color: donutChartColorSets.get(modelData[itm].assetClass)
        			});
        			this.modelTableData.push({
        				label: $translate.instant(modelData[itm].assetClass),
        				amount: modelData[itm].value,
        				color: donutChartColorSets.get(modelData[itm].assetClass)
        			});
        			this.portfolioModelAssetTotal += modelData[itm].value;
        			
        			var currentData = {};
        			currentData.key = "current";
        			currentData.color = "#222";
        			currentData.values = [{
        				x : modelData[itm].assetClass,
        				y : currentValue
        			}];
        			if (currentValue > maxRange) {
        				maxRange = currentValue;
        			}
        			
        			var stdData = {};
        			stdData.key = modelData[itm].assetClass;
        			stdData.color = donutChartColorSets.get(modelData[itm].assetClass);
        			stdData.values = [{
        				x : modelData[itm].assetClass,
        				y : modelData[itm].value
        			}];
        			if (modelData[itm].value > maxRange) {
        				maxRange = modelData[itm].value;
        			}
        			if (Number(itm) === len) {
            			multiBarDataLastRow.push(stdData);
            			multiBarDataLastRow.push(currentData);
        			} else {
            			multiBarData.push([stdData, currentData]);
        			}
        		}
        		maxRange = Number(maxRange.toFixed(0))+1;
        		while (maxRange%5 !== 0 && maxRange < 100){
        			maxRange += 1;
        		}
        		var tick = 0;
        		var tickValues = [0];
        		while(tick < maxRange) {
        			tick += 5;
        			tickValues.push(tick);
        		}
        		
                var multiBarOptions = ChartGenerator.createHorizontalBarChartOption();
                var multiBarOptionsLastRow = ChartGenerator.createHorizontalBarChartOption();
                
        		multiBarOptions.chart.forceY = [0,maxRange];
        		multiBarOptions.chart.yAxis.tickValues = tickValues;
        		multiBarOptionsLastRow.chart.forceY = [0,maxRange];
        		multiBarOptionsLastRow.chart.yAxis.tickValues = tickValues;
        		
        		$scope.multiBarChart = { options : multiBarOptions, data : multiBarData };
        		$scope.multiBarChartLastRow = { options : multiBarOptionsLastRow, data : multiBarDataLastRow };
               		
        		this.portfolioModelChart = {
        			options: donutChartOption,
        			data: this.portfolioModelData
        		};

    		};
    		$scope.isLastRow = function(value, index) {
    			return (index === ($scope.modelTableData.length-1)) ? true : false;
    		};
    		$scope.isNotLastRow = function(value, index) {
    			return (index === ($scope.modelTableData.length-1)) ? false : true;
    		};
    		$scope.toggleLayout = function() {
    			if (this.contentLayoutIndex == 1) {
    				$(this.contentLayoutLib[1].selector).show();
    				$(this.contentLayoutLib[0].selector).hide();
    			} else {
    				$(this.contentLayoutLib[1].selector).hide();
    				$(this.contentLayoutLib[0].selector).show();
    			}
    		};
    		$scope.switchLayout = function(index) {
    			if (!$scope.contentLayoutLib[index].checked) {
    				$scope.contentLayoutLib[0].checked = !$scope.contentLayoutLib[0].checked;
        			$scope.contentLayoutLib[1].checked = !$scope.contentLayoutLib[1].checked;
        			this.contentLayoutIndex = index+0;
        			this.toggleLayout();
    			}
    		};
    		$scope.switchModel = function(_opr) {
    			var libLen = this.modelLibSets.length,
    			indexJumpTo = this.portfolioModelIndex + _opr;
    			if (indexJumpTo >= libLen || indexJumpTo < 0) return;
    			this.portfolioModelIndex = indexJumpTo;
    			this.assembleModelData();
    		};
    		$scope.goToTargetPortfolio = function() {
    			var param = {
        				data: angular.toJson($scope.data),
        				portfolioModel: angular.toJson(this.modelLibSets[this.portfolioModelIndex].distribution),
        				source : 'portfolio_comparison'
    			};
        		$state.go('base.target_portfolio', param, {reload: true});
    		};
    		/*
             * Hijack nvd3 bullet chart marker
             * Change shape from triangle to circle
             * Fill the marker according to the assetClassID
             */
            $scope.bulletChartCustomisation = function () {
            	var bulletChartMarkers = $('.portfolio_comparison_bullet_chart path.nv-markerTriangle');
                bulletChartMarkers.attr('d','M 0 -8 a 8 8 0 1 0 0.0001 0');
            
                for (var index in bulletChartMarkers.toArray()) {
                	$(bulletChartMarkers.toArray()[index]).css('fill',$scope.modelTableData[index].color);
                }
            };
            $ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
        		scope : $scope
        	}).then(function(modal){
        		$scope.disclaimerModal = modal;
        	});
        	$scope.showDisclaimer = function() {
        		$scope.disclaimerModal.show();
        	};
        	$scope.hideDisclaimer = function() {
        		$scope.disclaimerModal.hide();
        	};
            $scope.isContentLong = function(index) {
            	return ($scope.modelTableData[index].label.length > 20 ? true : false);
            };
            $scope.disableSideMenuSwipeGesture = function() {
    			$ionicSideMenuDelegate.canDragContent(false);
    		};
    		$scope.enableSideMenuSwipeGesture = function() {
    			$ionicSideMenuDelegate.canDragContent(true);
    		};
    		$scope.init();
    		
        }
    ]);
    
    app.directive('onToggleListed',['$timeout',function($timeout) {
        return function($scope,element,attrs) {
      	  $timeout(function(){
      		$scope.layoutToggleButtons = $('.ui-toggle-bar .button-toggle');
      		$($scope.layoutToggleButtons[$scope.contentLayoutIndex]).addClass('selected');
      		$scope.toggleLayout();
      	  },0,false);
        };
    }]);
});