define([
    'app/app',
    'app/portfolio/services/AccountService',
    'js/Util/Validation',
    'js/appConfig',
    'js/Util/LogUtil'
], function(app, AccountService, Validation, AppConfig, LogUtil) {
    'use strict';

    app.controller('AccountSelectCtrl', [
        '$scope',
        '$translate',
        '$state',
        '$stateParams',
        'AccountService',
        function($scope, $translate, $state, $stateParams, AccountService) {
        	$scope.init = function() {
	            $scope.searchResult = AccountService.accountSearchResult;
	            $scope.sortKey = 'accountNumber';
	            $scope.sortOrderRule = 'ascn';
	            $scope.hasError = false;
	            $scope.isFromAccSearch = false;
	        	
	            if ($stateParams.isFromAccSearch !== undefined && $stateParams.isFromAccSearch === 'Y') {
	                LogUtil.logInfo('AccountSelectCtrl -> init : isFromAccSearch is true');
	                $scope.isFromAccSearch = true;
	            } 
	            var selectedAccount = 0;
	            var selectedAccountOutsideSearchResult = AccountService.selectedAccounts.length;
	            
	            angular.forEach($scope.searchResult, function(value, key) {
	                LogUtil.logTrace('AccountSelectCtrl -> init : account number: '+value.accountNumber);
	                value.isSelected = Validation.isExistInSelectedAccount(AccountService.selectedAccounts, value.accountNumber);
	                if (value.isSelected) {
	                	selectedAccount += 1;
	                	selectedAccountOutsideSearchResult -= 1;
	                } 
	                value.isDisabled = !$scope.isFromAccSearch && Validation.isExistInSelectedAccount(AccountService.selectedAccounts, value.accountNumber);
	            });
	            $scope.numberOfSelectedAccountOutsideSearchResult = selectedAccountOutsideSearchResult;
	            $scope.numberOfSelectedAccount = selectedAccount;
        	};
            $scope.createPortfolio = function() {
                angular.forEach($scope.searchResult, function(value, key) {
                	AccountService.selectedAccounts = AccountService.selectedAccounts.filter(function(item) {
                		return (item.accountNumber === value.accountNumber && !value.isSelected) ? false : true ;
                	});
                    if (value.isSelected && !Validation.isExistInSelectedAccount(AccountService.selectedAccounts, value.accountNumber)) {
                        AccountService.selectedAccounts.push(value);
                    }
                });
                if (AccountService.selectedAccounts.length === 0) {
                    this.hasError = true;
                    this.errorMsg = $translate.instant('ERR_NO_ACCOUNT_SELECTED');
                } else if (AccountService.selectedAccounts.length > AppConfig.systemParam.configMap.get('i_accCountLimit')) {
                    this.hasError = true;
                    this.errorMsg = $translate.instant('ERR_NUM_OF_ACCOUNT_EXCEEDED').replace('[selectAccountLimit]',AppConfig.systemParam.configMap.get('i_accCountLimit'));
                } else {
                    $state.go('base.portfolio_creation', {}, {
                        reload: true
                    });
                }
            };
            $scope.searchAgain = function() {
                angular.forEach($scope.searchResult, function(value, key) {
                    if (value.isSelected && !Validation.isExistInSelectedAccount(AccountService.selectedAccounts, value.accountNumber)) {
                        AccountService.selectedAccounts.push(value);
                    }
                });
                $state.go('base.account_search', {
                	isExistingSearch: 'Y',
                	isFromAccSearch: 'Y'
                }, {
                    reload: true
                });
            };
            $scope.sortSearchResult = function(sortKey) {
            	if (this.sortKey == sortKey){
            		this.sortOrderRule = (this.sortOrderRule == 'ascn')? 'desc':'ascn';
            	}else {
            		this.sortOrderRule = 'ascn';
            	}
                busyIndicator.show();
                LogUtil.logInfo('AccountSelectCtrl -> sortSearchResult : sortKey is :' + sortKey);
                $scope.sortKey = sortKey;
                $scope.searchResult = AccountService.sortSearchResultByKey($scope.searchResult, $scope.sortKey, this.sortOrderRule);
                busyIndicator.hide();
            };
            $scope.calculateTotalSelectedAccount = function() {
            	var selected = 0;
            	var outsideSelected = $scope.numberOfSelectedAccountOutsideSearchResult;
            	angular.forEach($scope.searchResult, function(value, key) {
                    if (value.isSelected) {
                        selected += 1;
                    }else if(Validation.isExistInSelectedAccount(AccountService.selectedAccounts, value.accountNumber)) {
                    	$scope.removeFromSelectedAccount(value.accountNumber);
                    	
                    }
                });
            	
            	$scope.numberOfSelectedAccount = selected;
            	selected += $scope.numberOfSelectedAccountOutsideSearchResult;
            	$scope.overAccountSelectionLimit = (selected > AppConfig.systemParam.configMap.get('i_accCountLimit'));
            	if (selected === 0) {
            		$scope.hasError = true;
            		$scope.errorMsg = $translate.instant('ERR_NO_ACCOUNT_SELECTED');
                } else if ($scope.overAccountSelectionLimit) {
                	$scope.hasError = true;
                	$scope.errorMsg = $translate.instant('ERR_NUM_OF_ACCOUNT_EXCEEDED').replace('[selectAccountLimit]',AppConfig.systemParam.configMap.get('i_accCountLimit'));
                }else {
                	$scope.hasError = false;
            		$scope.errorMsg = '';
                }
            };
            $scope.removeFromSelectedAccount = function(accountNumber) {
                
                angular.forEach(AccountService.selectedAccounts, function(value, key) {

                    if (value.accountNumber === accountNumber) {
                    	
                    	AccountService.selectedAccounts.splice(key,1);
                    }
                });
            };
            $scope.init();
        }
    ]);
});