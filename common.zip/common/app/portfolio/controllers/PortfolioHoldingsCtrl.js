define([
    'app/app',
    'js/Util/ChartGenerator',
    'app/portfolio/services/CustomerPortfolioService',
    'js/Util/LogUtil',
    'js/constants',
    'js/appState',
    'js/Util/FunctionActivator'
], function(app, ChartGenerator, CustomerPortfolioService, LogUtil, Constants, AppState, FunctionActivator) {
    'use strict';
    app.controller('PortfolioHoldingsCtrl', [
        '$scope',
        '$translate',
        '$stateParams',
        'CustomerPortfolioService',
        '$filter',
        '$state',
        '$timeout',
        '$ionicModal',
        '$ionicScrollDelegate',
        function($scope, $translate, $stateParams, CustomerPortfolioService, $filter, $state, $timeout, $ionicModal,$ionicScrollDelegate) {
			$scope.init = function() {
				$scope.data = angular.fromJson($stateParams.data);
	            $scope.portfolioCurrency = CustomerPortfolioService.getPortfolioCurrency($scope.data);
	            $scope.portfolioName = CustomerPortfolioService.getPortfolioName($scope.data);
	            $scope.portfolioHoldings = CustomerPortfolioService.getPortfolioHoldings($scope.data);
	            $scope.templateKey = "default";
	            $scope.itemLayoutPool = {
	                'product-profile-with-no': ["stock"],
	                'product-profile': ["unit_trust", "bond", "structured_products"],
	                'deposit-detail': ["time_deposit", "loans"],
	                'deposit-detail-linked': ["linked_deposit"],
	                'transaction-detail': ["option_derivatives_contract"],
	                'transaction-detail-exchange': ["forward_foreign_exchange"],
	                'transaction-detail-pending': ["pending_settlement"],
	                'currency-value': ["savings_n_current"]
	            };
	            // Headers by default formatted by 2 decimal places, except the followings
	            $scope.headerWithZeroDP = ["shares", "nominal_value"];
	            $scope.headerWithFourDP = ["market_price", "unit", "avg_unit_cost", "strike_price", "knock_out_price", "reference_value"];
	            $scope.headerWithSixDP = ["forward_rate"];
	            
	            $scope.itemWithGraph = ["savings_n_current","time_deposit","linked_deposit","stock","unit_trust","bond","structured_products"];
				$scope.hasNegativeValue = CustomerPortfolioService.hasNegativePercentageAssetAllocationHistory($scope.data);
	            $scope.isAccessibleToFNPortfolioHistory = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HISTORY);
	            
	            var selectedSectionID = "savings_n_current"; // default
	        	LogUtil.logInfo("PortfolioHoldingsCtrl -> init : $stateParams.assetCategory: " + $stateParams.assetCategory);
	            if (typeof $stateParams.assetCategory !== 'undefined' && $stateParams.assetCategory !== "") {
	            	selectedSectionID = $stateParams.assetCategory;
	            }
	        	LogUtil.logInfo("PortfolioHoldingsCtrl -> init : selectedSectionID: " + selectedSectionID);
	            $scope.populateSectionData(selectedSectionID);
	            $scope.sectionHeadingList = [];
	            for (var i = 0; i < $scope.portfolioHoldings.length; i++) {
	            	$scope.sectionHeadingList.push({
	            		"sectionID": $scope.portfolioHoldings[i].sectionID,
	            		"sectionIDLabel" : $translate.instant($scope.portfolioHoldings[i].sectionID)
	            	});
	            }
	            $scope.selectedSectionID = selectedSectionID;
	            $scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);
	            
			};
    		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
        		scope : $scope
        	}).then(function(modal){
        		$scope.disclaimerModal = modal;
        	});
        	$scope.showDisclaimer = function() {
        		$scope.disclaimerModal.show();
        	};
        	$scope.hideDisclaimer = function() {
        		$scope.disclaimerModal.hide();
        	};
        	$scope.toggleHideMaster = function() {
        		$scope.hideMaster = !$scope.hideMaster;
        	};
            var holdingLabelWithCurrency = ["principal_in_base_market", "deposit_amount_in_base_market", "market_value_in_base_market", "remaining_notional_amount"];
            $scope.goToHistory = function () {
            	var param = {
    				data: angular.toJson($scope.data),
    				specificAsset : $scope.selectedSectionID
				};
        		$state.go('base.portfolio_history', param, {reload: true});
            };
            $scope.showLoadingAndPopulateSectionData = function(_sectionID) {
            	busyIndicator.show();          	
            	$timeout(function(){
            		$scope.populateSectionData(_sectionID);
            	});
            };
            $scope.changeRowWidth=function(s){
            	var classname='width-700';
            	if ( s==="deposit-detail" || s==="transaction-detail-pending" ) classname = "width-700";
            	else if (s === "transaction-detail-exchange") classname = "width-910";
            	else if (s==="product-profile-with-no" || s==="product-profile")  classname='width-810';
            	else if (s==="transaction-detail") classname = "width-1000";
            	else if (s==="deposit-detail-linked")  classname='width-1020';
            	else  classname='width-700';
            	return classname;
            };
            $scope.getCellWidth = function(label) {
            	var width;
            	var columnWidth = {
            		'ccy' : '80px',
            		'buy_ccy' : '110px',
            		'sell_ccy' : '110px',
            		'trade_date' : '130px',
            		'value_date' : '130px',
            		'strike_price' : '130px',
            		'effective_date' : '120px',
            		'due_date' : '120px',
            		'underlying' : '150px',
            		'forward_rate' : '150px',
            		'interest_rate' : '105px',
            		'settlement_date' : '170px',
            		'buy_amount' : '170px',
            		'sell_amount' : '170px',
            		'shares' : '110px',
            		'unit' : '110px',
            		'nominal_value' : '110px',
            		'market_price' : '110px',
            		'avg_unit_cost' : '110px',
            		'account_type' : '220px',
            		'knock_out_price' : '150px',
            		'shares_notional_per_fixing' : '200px',
            		'remaining_notional_amount' : '250px',
            		'pending_settlement_amount' : '250px',
            		'pending_settlement_value' : '250px'
            	};
            	width = columnWidth[label] ? columnWidth[label] : '170px';
            	return width;
            };
            $scope.populateSectionData = function(_sectionID) {
            	$timeout(function(){
            		busyIndicator.hide();
            	});
                $ionicScrollDelegate.$getByHandle('holdingTable').scrollTop();

                $scope.selectedSectionID = _sectionID;
                var portfolioHoldingsBySectionID = CustomerPortfolioService.getPortfolioHoldingsBySectionID($scope.data, _sectionID);
                if (portfolioHoldingsBySectionID === -1) {
                	alert('No portfolio holdings can be found');
                }
                if (portfolioHoldingsBySectionID) {
	                var tmplSelectionSettings = {
	                    catKeyName: portfolioHoldingsBySectionID.sectionID,
	                    tmplKey: "default",
	                    completed: false
	                };
	                angular.forEach($scope.itemLayoutPool, function(_val, _key) {
	                    if (!this.completed && _val.indexOf(this.catKeyName) >= 0) {
	                        this.tmplKey = "" + _key;
	                        this.completed = true;
	                    }
	                }, tmplSelectionSettings);
	                $scope.holdingData = {
	                    id: portfolioHoldingsBySectionID.headerList,
	                    labels: [],
	                    values: portfolioHoldingsBySectionID.contentList,
	                    types: portfolioHoldingsBySectionID.typeList,
	                    layoutKey: tmplSelectionSettings.tmplKey
	                };
	                for (var t = 0; t < $scope.holdingData.id.length; t++) {
	                    if (holdingLabelWithCurrency && holdingLabelWithCurrency.indexOf($scope.holdingData.id[t]) > -1) {
	                        $scope.holdingData.labels.push($translate.instant($scope.holdingData.id[t] + "_" + $scope.portfolioCurrency));
	                    } else {
	                        $scope.holdingData.labels.push($translate.instant($scope.holdingData.id[t]));
	                    }
	                }

	                $scope.portfolioCurrency = $translate.instant($scope.portfolioCurrency);
	                $scope.totalAmountValue = $filter("currency")(portfolioHoldingsBySectionID.amount, "", 2);
	                
	               	$scope.proportion = $scope.hasNegativeValue ? '--' : portfolioHoldingsBySectionID.percentage;
	                
	                $scope.numOfHoldings = portfolioHoldingsBySectionID.totalRecords;
	                $scope.sectionHeadings = $translate.instant(portfolioHoldingsBySectionID.sectionID);

	                // Plot Asset History Data Graph
	                var assetHistoryChartOption = ChartGenerator.createBasicBarChartOption();
        			assetHistoryChartOption.chart.height = this.bottomChartHeight;
        			assetHistoryChartOption.chart.xAxis.tickFormat = ChartGenerator.axisMonthFormatter;
        			assetHistoryChartOption.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
        			assetHistoryChartOption.chart.yAxis.rotateYLabel = false;
        			assetHistoryChartOption.chart.yAxis.axisLabel = $scope.portfolioCurrency;
        			assetHistoryChartOption.chart.yAxis.axisLabelDistance = 0;
        			assetHistoryChartOption.chart.yAxis.ticks = 5;
        			assetHistoryChartOption.chart.yAxis.showMaxMin = true;
        			assetHistoryChartOption.chart.forceY = [0,1];
        			assetHistoryChartOption.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
        			assetHistoryChartOption.chart.multibar = {
    					dispatch : {
    						elementClick : function () {
    							$scope.goToHistory();
    						}
    					}
        			};
        			
        			var colorMap = ChartGenerator.getCategoryColorMap();
	                var categoryData = {};
	                categoryData.key = _sectionID;
	                categoryData.values = [];
	                categoryData.color = colorMap.get(_sectionID);
	                var historyData = CustomerPortfolioService.getAssetAllocationHistoryByAssetClass($scope.data, _sectionID, 3);
	                for (var i = historyData.length - 1; i >= 0; i--) {
	                	categoryData.values.push({
	                		x: historyData[i].month,
	                		y: Number(historyData[i].amount)
	                	});
	                }
	                var assetHistoryData = [];
	    	        assetHistoryData.push(categoryData);
	                $scope.assetHistoryChart = {
	                	options: assetHistoryChartOption,
	        			data: assetHistoryData
	                };
                } else {
                	LogUtil.logError("PortfolioHoldingsCtrl -> populateSectionData : portfolioHoldingsBySectionID is null");
                }
            };

			$scope.containsGraph = function() {
				var containsGraph = false;
				$scope.itemWithGraph.forEach(function(item){
					if (item === $scope.selectedSectionID) {
						containsGraph = true;
					}
				});
            	return containsGraph;
            };
            $scope.init();
        }
    ]);
});