define([
  'app/app',
  'js/constants',
  'js/Util/FunctionActivator'
], function (app, Constants, FunctionActivator) {
  'use strict';
  
  app.controller('PortfolioCoverCtrl', [
	'$scope',
	'$state',
	'$stateParams',
	'$ionicGesture',
	'$ionicSideMenuDelegate',
	'$timeout',
	'$ionicHistory',
	function ($scope, $state, $stateParams,$ionicGesture,$ionicSideMenuDelegate,$timeout, $ionicHistory) {
		var portfolioID = $stateParams.id;
		var screenCover, lockSlider, gestureIndcr, sliderOpacity, indcrOpacity,
		dragStartPosX = null, dragMovedPosX = 0,
		dragLimitPx = 120, toUnlock = false;
		if (FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CUST_PROF) === false) {
			FunctionActivator.showAccessDeniedMessage($ionicHistory);
		}
		 
		$scope.goPortfolioOverview = function() {
    		var param = {
    			id: portfolioID
    		};
    		$state.go('base.portfolio_overview', param, {reload: true});
    	};
    	$scope.panHandler = function(evt) {
    		var evtType = evt.type, evtTarget = evt.target;
    		switch (evtType) {
	    		case 'dragstart':
	    			$ionicSideMenuDelegate.canDragContent(false);
	   				dragStartPosX = dragStartPosX ? dragStartPosX : evt.gesture.center.pageX;
	    			break;
	    		case 'drag':
	    			dragMovedPosX = (evt.gesture.center.pageX - dragStartPosX).toFixed(2);
	    			dragMovedPosX = Math.min(Math.max(parseFloat(dragMovedPosX), 0), dragLimitPx);
	    			sliderOpacity = Math.min(Math.max(parseFloat((dragMovedPosX/dragLimitPx).toFixed(2)), 0.7), 1);
	    			indcrOpacity = parseFloat((1 - parseFloat(dragMovedPosX/dragLimitPx) * 1).toFixed(2));
	        		console.log('>>>>>>>>>>>>>>>>>>>> sliderOpacity: ',sliderOpacity);
	    			lockSlider.css({
						'-webkit-transform': 'translate('+dragMovedPosX+'px,0)',
						'opacity': sliderOpacity
					});
	    			gestureIndcr.css({ 'opacity': indcrOpacity });
	    			toUnlock = (dragMovedPosX >= dragLimitPx);
	    			break;
	    		case 'release':
	    			$ionicSideMenuDelegate.canDragContent(true);
	    			if (toUnlock) {
	    				toUnlock = false;
	    				$scope.goPortfolioOverview();
	    			} else {
		    			dragStartPosX = null;
		    			dragMovedPosX = 0;
		    			lockSlider.css({
							'-webkit-transform': 'translate(0,0)',
							'opacity': 0.7
						});
		    			gestureIndcr.css({
		    				'opacity': 1
		    			});
	    			}
	    			break;
    		}
    		
    	};
    	$scope.init = function(){
    		screenCover = $('ion-view.view-splash-screen');
    		lockSlider = $('.app-lock-bar .panning-label');
    		gestureIndcr = $('.app-lock-bar .panning-sign');
    		$ionicGesture.on('dragstart drag release',
            this.panHandler,screenCover);
    	};
    	
    	$scope.init();
	}]);
});