define([
    'app/app',
    'app/portfolio/services/CustomerPortfolioService',
    'app/portfolio/services/TargetPortfolioService',
    'js/Util/ChartGenerator',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/Validation',
    'js/appConfig',
    'js/appState',
    'js/Util/AuditLoggingUtil',
    'js/Util/PdfPluginUtil',
	'js/constants',
	'js/message',
    'js/Util/FunctionActivator',
    
], function(app,CustomerPortfolioService,TargetPortfolioService,ChartGenerator,LogUtil,CommonUtil,Validation,AppConfig,AppState,AuditLoggingUtil,PdfPluginUtil, Constants, Message, FunctionActivator) {
    'use strict';
    app.controller('TargetPortfolioCtrl', [
        '$scope',
        '$rootScope',
        'CustomerPortfolioService',
        'TargetPortfolioService',
        '$translate',
        '$stateParams',
        '$filter',
        '$state',
        '$ionicModal',
        '$timeout',
        '$ionicHistory',
       
        function($scope, $rootScope, CustomerPortfolioService,TargetPortfolioService,$translate,$stateParams,$filter,$state,$ionicModal,$timeout, $ionicHistory) {
        	$scope.isUpdate = false;
        	$scope.isEditingRemarks = false;
        	$scope.isProspect = false;
        	$scope.isShowTarget = true;
        	$scope.remarksDisplay = '';
        	$scope.tableModelData = new Map();
        	$scope.targetPortfolioChartData = [];
        	$scope.currentPortfolioChartData = [];
        	$scope.portfolioAssetClassList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
            $scope.dragScalePercentage = 0;
            $scope.colorMap = ChartGenerator.getCategoryColorMap();
            $scope.availablePercentage = 100;
            $scope.focusIndex = 0;
            $scope.targetPortfolioData = {
            		inputTotalAUM : ''
            };
            $scope.hasError = true;
            $scope.rmName = AppState.userInfo.userFullName;
            $scope.errorIndex=-1;
            $scope.clickBlock = false;
            $scope.clickBlockCountRange = 450;
            $scope.clickBlockTimer = null;
    		
            $scope.switchChart = function(mode){
        		if(mode==='current'){
        			$scope.isShowTarget = false;
        		}else if(mode==='target'){
        			$scope.isShowTarget = true;
        		}
        		$scope.portfolioModelLib.forEach(function(object,index){
        			if (mode == object.name) {
        				object.checked = true;
        			}else {
        				object.checked = false;
        			}
        		});
        	};
        	$scope.remarksCharLimit = AppConfig.targetPortfolioProspectRemarksCharacterLimit;
        	
    		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
        		scope : $scope
        	}).then(function(modal){
        		$scope.disclaimerModal = modal;
        	});
        	$scope.showDisclaimer = function() {
        		$scope.disclaimerModal.show();
        	};
        	$scope.hideDisclaimer = function() {
        		$scope.disclaimerModal.hide();
        	};
        	$scope.setupClickBlock = function(){
        		if ($scope.clickBlockTimer !== null){
        			$timeout.cancel($scope.clickBlockTimer);
        		}
				$scope.clickBlock = true;
				$scope.clickBlockTimer = $timeout(function(){
					$scope.clickBlock = false;
					$scope.clickBlockTimer = null;
				}, $scope.clickBlockCountRange);
        	};
        	$scope.moveArrayOrder = function(_arr,_oldIdx,_toIdx) {
        		var resultArr = [];
        		_arr.forEach(function(item) { resultArr.push(item); });
        		if (_oldIdx >= resultArr.length) {
        	        var k = _toIdx - resultArr.length;
        	        while ((k--) + 1) {
        	        	resultArr.push(undefined);
        	        }
        	    }
        		resultArr.splice(_toIdx, 0, resultArr.splice(_oldIdx, 1)[0]);
        	    return resultArr;
        	};
        	$scope.universalClick = function(_evt){
        		LogUtil.logDebug('TargetPortfolioCtrl -> universalClick');
        		$scope.errorMsg = '';
        		
        		LogUtil.logDebug('TargetPortfolioCtrl -> universalClick : '+_evt.toString());
        		_evt.stopPropagation();
        		if ($scope.clickBlock) {
        			return false;
        		}
        		if($scope.isProspect){
        		    if(!$scope.validatePorfolioName()){
        		    	return false;
        		    }else if(!$scope.validateAUM()){
        		    	this.assembleTableData.forEach(function(item){
    	            		item.targetAmount = 0.00;
    	            	});
        		    	return false;
        		    }else {
        		    	var aum = this.getNumberOnlyInputTotalAUM();
        		    	LogUtil.logDebug('TargetPortfolioCtrl -> universalClick: aum is '+aum);
        		    	$scope.targetPortfolioData.inputTotalAUM = $filter('currency')(aum, '', 2);
        		    	this.assembleTableData.forEach(function(item){
    	            		item.targetAmount = Number(aum * item.targetPercentage / 100).toFixed(2);
    	            	});
        		    }
        		}
        		if ($scope.isUpdate && $scope.updateIndex !== undefined && $scope.updateIndex !== null) {
        			LogUtil.logDebug('TargetPortfolioCtrl -> universalClick: is updating target percentage');
        			var parmSettings = {};
        			parmSettings.changeState = true;
        			$scope.saveUpdate(parmSettings);
        			$scope.dimOtherAssetClasses();
        		}else {
        			$scope.hasError = false;
        		}
        		$scope.setupClickBlock();
        		return false;
        	};
            $scope.initTargetPortfolio = function(){
        		var _this = this;
                this.portfolioAssetClassList.forEach(function(item) {
                	var targetPercentage = 0;
            		var targetAmount = 0;
            		var editable = true;
                	if(item.key==='savings_n_current'){
                		targetPercentage = 100;
                		targetAmount = $scope.totalAUM;
                		editable = false;
                	}
                	$scope.tableModelData.set(item.key,{	
                									assetClassID : item.key,
                									label: $translate.instant(item.key),
                									color: _this.colorMap.get(item.key),
                									targetPercentage:targetPercentage,
                									targetAmount:targetAmount,
                									currentPercentage : 0,
                									isUpdate : false,
                									editable : editable,
                									updateTargetPercentage : targetPercentage,
                									updateCurrentPercentage : 0
                								});
                	var obj = {
    	    				key : item.key,
    	    				y: targetPercentage,
    	    				color : _this.colorMap.get(item.key)
    	    		};
                	$scope.targetPortfolioChartData.push(obj);
        	    });
            };
            
            $scope.displayTargetPortfolio = function(targetPortfolio){
            	if(targetPortfolio!==null){
            		LogUtil.logInfo('TargetPortfolioCtrl -> displayTargetPortfolio : targetPortfolio is '+angular.toJson(targetPortfolio));
            		$scope.targetPortfolioData.inputTotalAUM = targetPortfolio.totalAUM; // unformatted the AUM to avoid validation error
                	$scope.targetPortfolioData.targetPortfolioName = targetPortfolio.portfolioName;
                	$scope.targetPortfolioID = targetPortfolio.id;
                	$scope.remarksData = targetPortfolio.remarksData ? targetPortfolio.remarksData : '' ;

                	var colorMap = ChartGenerator.getCategoryColorMap();
                	targetPortfolio.assetAllocationList.forEach(function(item) {
                		var editable = true;
                		if(item.assetClassID==='savings_n_current'){
                    		editable = false;
                    	}
                		$scope.tableModelData.set(item.assetClassID,{	
                    									assetClassID : item.assetClassID,
                    									label: $translate.instant(item.assetClassID),
                    									color: colorMap.get(item.assetClassID),
                    									targetPercentage:item.percentage,
                    									targetAmount:item.amount,
                    									isUpdate : false,
                    									editable : editable,
                    									updateTargetPercentage : item.percentage
                    								});
                    	var obj = {
        	    				key : item.assetClassID,
        	    				y: item.percentage,
        	    				color : colorMap.get(item.assetClassID)
        	    		};
                    	$scope.targetPortfolioChartData.push(obj);
            	    });
            	}
            };
            $scope.initCurrentPortfolio = function(data){
            	$scope.portfolioName = data.portfolioName;
            	$scope.remarksData = data.remarksData ? data.remarksData : '' ;

            	if (!$scope.isProspect && data !== null) {
    	            var currentPortfolioData = CustomerPortfolioService.getLatestAssetAllocation(data);
    	            currentPortfolioData.forEach(function(item) {
    	            	$scope.tableModelData.get(item.assetClassID).currentPercentage = item.percentage;
    	            	$scope.tableModelData.get(item.assetClassID).updateCurrentPercentage = item.percentage;
    	            	var obj = {
    		    				key : item.assetClassID,
    		    				y: Number(item.percentage),
    		    				color : $scope.tableModelData.get(item.assetClassID).color
    		    		};
    	            	$scope.currentPortfolioChartData.push(obj);
    	            });
                }
            	
            };
            $scope.editTargetPercentage = function(assetClassID,index,_evt){
            	if (_evt) { _evt.stopPropagation(); }
            	$scope.focusIndex = index;
            	if ($scope.clickBlock) { return false; }
            	this.isEditingRemarks = false;
            	
            	LogUtil.logInfo('TargetPortfolioCtrl -> editTargetPercentage : for '+this.assembleTableData[index].targetPercentage);
            	
            	var focusDataItem = this.assembleTableData[index];
            	if (focusDataItem.updateTargetPercentage === undefined) {
            		focusDataItem.updateTargetPercentage = focusDataItem.targetPercentage;
            	}
            	$scope.dimOtherAssetClasses(index);
            	
            	this.assembleTableData.forEach(function(item){ item.isUpdate = false; });
            	
            	if(this.isProspect && Validation.isEmpty(this.getNumberOnlyInputTotalAUM())){
            		alert('Please input value number to AUM');
            	} else {
	            	$scope.isUpdate = true;
	            	$scope.updateIndex = index;
	            	focusDataItem.isUpdate = true;
	            	focusDataItem.availableRange = Number(this.assembleTableData[0].targetPercentage) + Number(focusDataItem.updateTargetPercentage); 
	            	$('label input').attr('disabled',true);
	            	setTimeout(function(){ $('label input:visible').removeAttr('disabled'); }, 500);
            	}
            	if (focusDataItem.callBeforeEdit !== undefined){ focusDataItem.callBeforeEdit(); }
            	$scope.setupClickBlock();
            	return false;            	
            };
            $scope.translateCurrency = function(_val,_decimalDigitLen) {
            	var result, decimalLen = (_decimalDigitLen === undefined)? 2:_decimalDigitLen;
            	result = $filter('currency')(_val,'',decimalLen);
            	return result;
            };
            $scope.dimOtherAssetClasses = function(index) {
            	if (!index) {
                	$('.currentChart .nv-pie .nv-slice').animate({opacity : 1});
                	$('.assembleTableRow').animate({opacity : 1});
            	} else {
            		var focusDataItem = this.assembleTableData[index];
                	$('.currentChart .nv-pie .nv-slice').animate({opacity : 0.4});
        			$('.currentChart .nv-pie .nv-slice[fill="'+focusDataItem.color+'"]').stop().css('opacity',1);
        			
        			$('.assembleTableRow').animate({opacity : 0.4});
        			$('.assembleTableRow.row'+index).stop().css('opacity',1);
            	}
            };
            $scope.inputChangeHandler = function(_val,_idx){
            	LogUtil.logDebug('TargetPortfolioCtrl -> inputChangeHandler');
            	$scope.errorIndex=_idx;
            	$scope.saveUpdate({ changeState: false });
            	
            };
            $scope.validateTargetPercentage = function(targetPercentage,availRange) {
            	
            	if (Validation.isEmpty(targetPercentage)) {
					$scope.hasError = true;
                    $scope.errorMsgPercent = $translate.instant('ERROR_TARGET_PERCENTAGE_EMPTY');
            		return false;
            	}else if(isNaN(Number(targetPercentage))) {
            		$scope.hasError = true;
                    $scope.errorMsgPercent = $translate.instant('ERROR_TARGET_PERCENTAGE_INVALID_FORMAT');
            		return false;
            	}else if(Number(parseFloat(targetPercentage).toFixed(2))<0){
            		$scope.hasError = true;
                    $scope.errorMsgPercent = $translate.instant('ERROR_TARGET_PERCENTAGE_BELOW_MIN');
            		return false;
            	}else if (Number(parseFloat(availRange).toFixed(2)) - Number(parseFloat(targetPercentage).toFixed(2)) <0 ) {
            		$scope.hasError = true;
                    $scope.errorMsgPercent = $translate.instant('ERROR_TARGET_PERCENTAGE_ABOVE_MAX').replace('[availRange]',Number(parseFloat(availRange).toFixed(2)));
                    
					return false;
				}else {
					$scope.hasError = false;
                    $scope.errorMsgPercent = '';
                    return true;
				}
            };            
            $scope.validateAUM = function() {
            	$scope.errorMsg = '';
            	var aum = this.getNumberOnlyInputTotalAUM();
            	console.log('haha'+aum);
            	if (aum === '') {
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_AUM_EMPTY');
            		return false;
            	} else if(isNaN(Number(aum))){
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_AUM_INVALID_FORMAT');
                    return false;
            	} else if (Number(aum)<0){
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_AUM_BELOW_MIN');
                    return false;
            	} else if (Number(aum)>999999999999.99){
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_AUM_ABOVE_MAX');
                    return false;
            	} else {
            		return true;
            	} 
            };
            
            $scope.validatePorfolioName = function() {
            	$scope.errorMsg = '';
            	var portfolioName = this.targetPortfolioData.targetPortfolioName;
            	if (Validation.isEmpty(portfolioName)) {
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_PORTFOLIO_NAME_EMPTY');
            		return false;
            	}else if(portfolioName.length>55){
            		$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_PORTFOLIO_NAME_INVALID_LENGTH');
            		return false;
            	}else {
            		return true;
            	}
            };
            $scope.saveUpdate = function(_options) {
				var index = $scope.updateIndex;
				var restPercentage = 0;
				var totalAmount = 0;
				var originalTotalAmount = 0;
				var targetDataItem = this.assembleTableData[index];
				var totalPercentage = 100;
				var availRange = targetDataItem.availableRange;
				var updateTargetPercentage = targetDataItem.updateTargetPercentage;
				if($scope.validateTargetPercentage(updateTargetPercentage,availRange)){ 
					$scope.hasError = false; 
				} else { 
					return;
				}
				
                LogUtil.logDebug('TargetPortfolioCtrl -> saveUpdate: updateTargetPercentage = ' + updateTargetPercentage);
				if ($scope.isProspect){
					totalAmount = this.getNumberOnlyInputTotalAUM();
					originalTotalAmount = this.getNumberOnlyInputTotalAUM();
					LogUtil.logDebug('TargetPortfolioCtrl -> saveUpdate: this.inputTotalAUM = ' + this.getNumberOnlyInputTotalAUM());
					LogUtil.logDebug('TargetPortfolioCtrl -> saveUpdate: this.targetPortfolioName = ' + this.targetPortfolioData.targetPortfolioName);
					
				}else {
					totalAmount = this.totalAUM;
					originalTotalAmount = this.totalAUM;
				}
				
				
				targetDataItem.targetPercentage = Number(parseFloat(updateTargetPercentage).toFixed(2));
				restPercentage = availRange - Number(targetDataItem.targetPercentage);
				var result = originalTotalAmount * Number(targetDataItem.targetPercentage)/100;
				LogUtil.logInfo('TargetPortfolioCtrl -> saveUpdate: result is '+result);
				targetDataItem.targetAmount = result.toFixed(2);
								
				// Update the value of Saving & Current
				this.assembleTableData[0].targetPercentage = restPercentage;
				this.assembleTableData[0].targetAmount = (totalAmount * restPercentage / 100).toFixed(2);
				$scope.availablePercentage = restPercentage;
				
				// Update the available range of percentage after each update
				targetDataItem.availableRange = targetDataItem.targetPercentage + this.assembleTableData[0].targetPercentage;
				
				LogUtil.logInfo('TargetPortfolioCtrl -> saveUpdate : saveings_n_current is '+this.assembleTableData[0].targetPercentage);
				LogUtil.logInfo('TargetPortfolioCtrl -> saveUpdate : updating item is '+this.assembleTableData[index].targetPercentage);
				LogUtil.logInfo('TargetPortfolioCtrl -> saveUpdate : total % is '+restPercentage);
				
				if (_options === undefined || _options.changeState) {
					this.assembleTableData[index].isUpdate = false;
					$scope.isUpdate = false;
				}
				this.refreshTargetPortfolioChart();
            };
            
            $scope.refreshTargetPortfolioChart = function(){
            	var targetPortfolioChartData = [];
            	var _this = this;
            	this.assembleTableData.forEach(function(item){
            		var obj = {
    	    				key : item.assetClassID,
    	    				y: item.targetPercentage,
    	    				color : _this.colorMap.get(item.assetClassID)
    	    		};
                	targetPortfolioChartData.push(obj);
            	});
            	targetPortfolioChartData = $scope.moveArrayOrder(targetPortfolioChartData,0,targetPortfolioChartData.length-1);
            	$scope.targetChart.data = targetPortfolioChartData;
            };
            // Prepare submit overlay     	
            $ionicModal.fromTemplateUrl('./app/portfolio/templates/targetportforlio_save_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
            $scope.hideSubmitOverlay = function() {
                $scope.submitModal.hide();
                $state.go($state.current, {}, {reload: true});
            };
            
            $scope.saveTargetPortfolio = function(){
            	$scope.saveStart = Date.now();
            	busyIndicator.show();
            	var assetAllocationList = [];
            	var assetAllocationFormated = [];
            	this.assembleTableData.forEach(function(item){
            		var obj = {
    	    				assetClassID : item.assetClassID,      	    				
    	    				percentage: item.targetPercentage,
    	    				amount : item.targetAmount    				
    	    		};
            		assetAllocationList.push(obj);
            	});       
            	
            	this.assembleTableData.forEach(function(item){
            		var oobj = {
    	    				assetClassID : Message[Constants.LANG_EN][item.assetClassID],		
    	    				percentage: item.targetPercentage.toFixed(2),
    	    			    amount :$filter('currency')(item.targetAmount, "", 2) 
    	    				
    	    		};
            		assetAllocationFormated.push(oobj);
            	});       
            	var targetPortfolioToSubmit = {
            			portfolioName : this.targetPortfolioData.targetPortfolioName,
            			totalAUM : this.getNumberOnlyInputTotalAUM(),
            			assetAllocationList : assetAllocationList,
            			assetAllocationFormated:assetAllocationFormated,
            			remarksData :this.remarksData,
            			lastModifiedDate : Date.now(),
            			rmName:$scope.rmName,
            			dateTime:$filter('date')(new Date(),'dd MMM yyyy'),
            			totalAUMFormated:this.targetPortfolioData.inputTotalAUM
            	};
            	LogUtil.logInfo('TargetPortfolioCtrl -> saveTargetPortfolio : generating PDF for targetPortfolio.');          
            	LogUtil.logInfo(targetPortfolioToSubmit);
            	if ($scope.source ==='target_portfolios_prospect' || $scope.source ==='homepage'){
            		targetPortfolioToSubmit.id = this.targetPortfolioID;	
           		}         	
            	PdfPluginUtil.generateTargetPortfolioPDF(targetPortfolioToSubmit,this.generatePDFsuccessCallback,this.generatePDFFailureCallback);
            	
            };
            
            //TODO: Generate PDF successCallback: upload PDF
            $scope.generatePDFsuccessCallback = function(data) {            	            	   
           		LogUtil.logDebug('TargetPortfolioCtrl -> generatePDFsuccessCallback : generate PDF success');			 
				LogUtil.logDebug('TargetPortfolioCtrl -> generatePDFsuccessCallback : attempt to uploadTargetPortfolioPDF');				
				var uploadTargetPortfolioPDFSuccessCallback = function(data) { 	
					LogUtil.logDebug('TargetPortfolioCtrl -> generatePDFsuccessCallback -> uploadTargetPortfolioPDFSuccessCallback');
					if ($scope.source ==='target_portfolios_prospect' || $scope.source ==='homepage'){
						$scope.deletePortfolio(data.id);
					}
					busyIndicator.hide();
		            $scope.submitModal.show();
					$scope.saveEnd = Date.now();
	                var responseTime = ($scope.saveEnd - $scope.saveStart)/1000;
	                LogUtil.logInfo('Performance Test : Upload Target Portfolio userID='+AppState.userID+' r='+responseTime);
	             };	             
	            var uploadTargetPortfolioPDFFailureCallback = function(data) { 
	            	busyIndicator.hide();
	            	LogUtil.logDebug('TargetPortfolioCtrl -> generatePDFsuccessCallback -> uploadTargetPortfolioPDFFailureCallback');	        
	            	$scope.savePortfolioToLocal(data);	
	            	var errorMsg = '';
	            	if(data.errorCode){
	            		errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_ZPB_FAILURE')+data.errorCode;
	            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),alertMsg,[{text:$translate.instant('BTN_OK'), handler: function() {
	                        $state.go($state.current, {}, {reload: true});
	            		}}]);
	            	} else {
	            		$scope.getNetworkStatus();
	            	}	            	
	              };       
	            TargetPortfolioService.uploadTargetPortfolioPDF(data,uploadTargetPortfolioPDFSuccessCallback,uploadTargetPortfolioPDFFailureCallback);	
	            var auditLogInfo = {
	               		userID : AppState.userID,
	               		activity:'submit_target_portfolio',
	               		customerName : null,
	               		accountName : null,
	               		accountNumber : null
	               };
	            AuditLoggingUtil.insertAuditLogging(auditLogInfo);
            };
            $scope.getNetworkStatus = function() {
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('TargetPortfolioCtrl -> Network Info : '+networkInfo.isNetworkConnected);
		  			var errorMsg = '';
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_NO_INTERNET_CONNECTION');
	            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'), errorMsg, [{text:$translate.instant('BTN_OK'), handler: function() {
	                        $state.go($state.current, {}, {reload: true});
	            		}}]);
		  			}else{
		  				errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_MFP_CONNECTION_FAILURE');
		  				WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'), errorMsg, [{text:$translate.instant('BTN_OK'), handler: function() {
		  	                $state.go($state.current, {}, {reload: true});
		  				}}]);
		  			}
        		});	 
            };
          //generate PDF fail
            $scope.generatePDFFailureCallback = function(data) {           	
                busyIndicator.hide();               
            	LogUtil.logDebug('TargetPortfolioCtrl -> generatePDFFailureCallback : generate PDF failed'); 
            	$scope.savePortfolioToLocal(data);  
            	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),$translate.instant('ERR_GENERATE_TARGET_PORTFOLIO_PDF_FAILURE'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
            };
            $scope.savePortfolioToLocal= function(data) {
            	if($scope.source ==='create'){
            		TargetPortfolioService.addTargetPortfolio(data,this.addPortfolioSuccessCallback,this.addPortfolioFailureCallback);
        		}else if ($scope.source ==='target_portfolios_prospect' || $scope.source ==='homepage'){
           			TargetPortfolioService.updateTargetPortfolio(data,this.updatePortfolioSuccessCallback,this.updatePortfolioFailureCallback);
        		}
            };
            
            $scope.addPortfolioSuccessCallback = function(id) {
            	LogUtil.logInfo('TargetPortfolioCtrl -> addPortfolioSuccessCallback');            	
            	busyIndicator.hide();              
            };
            $scope.addPortfolioFailureCallback = function() {
            	LogUtil.logInfo('TargetPortfolioCtrl -> addPortfolioFailureCallback');
            	busyIndicator.hide();
            };
            $scope.updatePortfolioSuccessCallback = function(id) {
            	LogUtil.logInfo('TargetPortfolioCtrl -> updatePortfolioSuccessCallback');
            	busyIndicator.hide();
            	
            };
            $scope.updatePortfolioFailureCallback = function() {
            	LogUtil.logInfo('TargetPortfolioCtrl -> updatePortfolioFailureCallback');
            	busyIndicator.hide();
            	
            };
            
            $scope.deletePortfolio = function(id){
        		TargetPortfolioService.deleteTargetPortfolioByID(id,this.deletePortfolioSuccessCallback,this.deletePortfolioFailureCallback);
        	};
        	$scope.deletePortfolioSuccessCallback = function(result) {
            	LogUtil.logInfo('TargetPortfolioCtrl -> deletePortfolioSuccessCallback');
            	busyIndicator.hide();
            };
            $scope.deletePortfolioFailureCallback = function(errObj) {
            	LogUtil.logInfo('TargetPortfoliosProspectCtrl -> deletePortfolioFailureCallback');
            	busyIndicator.hide();
            };
              
            $scope.initTargetPortfolioByModel = function(portfolioModel){
            	var colorMap = ChartGenerator.getCategoryColorMap();
            	var _this = this;
                portfolioModel.forEach(function(item) {
                	var editable = true;
                	if (item.assetClass == 'savings_n_current') {
                		editable = false;
                	}
                	var targetAmount = _this.totalAUM * Number(item.value)/100;
                	$scope.tableModelData.set(item.assetClass,{	
            									assetClassID : item.assetClass,
            									label: $translate.instant(item.assetClass),
            									color: colorMap.get(item.assetClass),
            									targetPercentage:item.value,
            									targetAmount:targetAmount.toFixed(2),
            									currentPercentage : 0,
            									isUpdate : false,
            									editable : editable,
            									updateTargetPercentage : item.value+0,
            									updateCurrentPercentage : 0
                								});
                	var obj = {
	    				key : item.assetClass,
	    				y: item.value,
	    				color : colorMap.get(item.assetClass)
    	    		};
                	$scope.targetPortfolioChartData.push(obj);
        	    });
            	
            };
            
            $scope.editRemarks = function(){
            	// At this moment, textarea is rendered
            	$('textarea[ng-model=remarksData]').prop('maxlength',$scope.remarksCharLimit);
            	this.isEditingRemarks = true;
            	
            };
            
            $scope.saveRemarks = function(){
            	var remarksData = this.remarksData || '';
            	this.isEditingRemarks = false;
        		this.remarksDisplay = ''+remarksData;
            	if(!this.hasError && remarksData.length > 2000){
            		this.hasError = true;
                    this.errorMsg = $translate.instant('ERR_REMARKS_INVALID_LENGTH');
            	}      		
            };
            
            $scope.editAUM = function() {
            	LogUtil.logInfo('TargetPortfolioCtrl -> editAUM');
            	$scope.targetPortfolioData.inputTotalAUM = $scope.getNumberOnlyInputTotalAUM();
            	
            	
            };
            
            $scope.getNumberOnlyInputTotalAUM = function() {
            	var originalInput = $scope.targetPortfolioData.inputTotalAUM;
            	
            	var resultInput = '';
            	if(typeof originalInput==='undefined'){
            		resultInput = undefined;
            	}else if(!Validation.isEmpty(originalInput)){
            		resultInput = originalInput.toString().replace(/,/g,'').replace('.00','');
            	}
            	return resultInput;
            
            };
            
            $scope.init = function (){
            	$scope.isUpdate = false;
            	$scope.isEditingRemarks = false;
            	$scope.isProspect = false;
            	$scope.isShowTarget = true;
            	$scope.remarksDisplay = '';
            	$scope.tableModelData = new Map();
            	$scope.targetPortfolioChartData = [];
            	$scope.currentPortfolioChartData = [];
            	$scope.portfolioAssetClassList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
                $scope.dragScalePercentage = 0;
                $scope.colorMap = ChartGenerator.getCategoryColorMap();
                $scope.availablePercentage = 100;
                $scope.focusIndex = 0;
                $scope.targetPortfolioData = {
                		inputTotalAUM : ''
                };
                $scope.hasError = true;
                $scope.rmName = AppState.userInfo.userFullName;
                $scope.errorIndex=-1;
                $scope.clickBlock = false;
                $scope.clickBlockCountRange = 450;
                $scope.clickBlockTimer = null;
   	        	var data = angular.fromJson($stateParams.data);
	        	var targetPortfolio = angular.fromJson($stateParams.targetPortfolio);
	        	var portfolioModel = angular.fromJson($stateParams.portfolioModel);
	        	$scope.source = $stateParams.source;
	        	var date = (data && data.lastUpdateDate) ? new Date(data.lastUpdateDate) : new Date(); 
	        	
				$scope.lastUpdate = CommonUtil.getDateTimeString($filter('date')(date,'dd MMM yyyy'), false);
				if (data && data.portfolioCurrency) {
					$scope.portfolioCurrency = $translate.instant(data.portfolioCurrency);
				}
	
	        	LogUtil.logInfo('TargetPortfolioCtrl source is '+$scope.source);
	
	            if($scope.source ==='create'){
	    			$scope.isProspect = true;
	    			$scope.totalAUM = 0;
	    			$scope.initTargetPortfolio();
	    		}else if ($scope.source ==='target_portfolios_prospect' || $scope.source ==='homepage'){
	    			$scope.isProspect = true;
	    			$scope.displayTargetPortfolio(targetPortfolio);
	    		}else if($scope.source ==='portfolio_overview'){
	    			$scope.totalAUM = Number(data.totalAUM);
	    			$scope.initTargetPortfolio();
	    			$scope.initCurrentPortfolio(data);
	    		}else if($scope.source ==='portfolio_comparison'){
	    			$scope.totalAUM = Number(data.totalAUM);
	    			$scope.initTargetPortfolioByModel(portfolioModel);
	    			$scope.initCurrentPortfolio(data);
	    		}
	            
	            if (!$scope.isProspect) {
	            	$scope.portfolioModelLib = [{
	            		name: 'current', translateKey: 'TP_CURRENT',
	            		checked: false
	            	},{
	            		name: 'target', translateKey: 'TP_TARGET',
	            		checked: true
	            	}];
	            }else {
	            	if (FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_TARGET_PROF) === false) {
		            	FunctionActivator.showAccessDeniedMessage($ionicHistory);
		            	return;
		    		}
	            }
	            $rootScope.pageFunctionality = $scope.isProspect ? 'targetPortfolios' : 'customerPortfolios';
	            $scope.remarksDisplay = $scope.remarksData  || '';
	            
	            $scope.assembleTableData = Array.from($scope.tableModelData.values());
	            $scope.availablePercentage = $scope.assembleTableData[0].targetPercentage;
	            
	            var targetChartOption = ChartGenerator.createBasicModelChartOption();
	            
	            $scope.targetChart = {
		    			options : targetChartOption,
		    			data :$scope.targetPortfolioChartData
		    	};
	            $scope.returnObj = function(_obj){
	            	return _obj;
	            };
	            var currentChartOption = ChartGenerator.createBasicModelChartOption();
	            currentChartOption.chart.pie.dispatch.elementClick = function(e) {
	            	var assetClassID = e.data.key;
	            	var index = -1;
	            	for (var itm in $scope.assembleTableData) {
	            		var entry = $scope.assembleTableData[itm];
	            		if (entry.assetClassID === assetClassID && entry.editable) {
	            			index = Number(itm);
	            		}
	            	}
	            	if (index > -1) {
	                	$scope.editTargetPercentage(assetClassID, index);
	            	} else {
	            		//No dimmed asset classes
	            		$scope.dimOtherAssetClasses(); 
	            	}
	            };
	            $scope.currentChart = {
		    			options : currentChartOption,
		    			data :$scope.currentPortfolioChartData
		    	};
	            
            };

            $scope.init();
        }
    ]);

    app.directive('setupSliderBar',['$ionicGesture','$ionicSideMenuDelegate','$timeout',
        function($ionicGesture,$ionicSideMenuDelegate,$timeout) {
        return function($scope,element,attrs) {
        	var slideTrigger = element.find('.slider-trigger'),
        	slideReading = element.find('.slider-reading'),
        	slideTrack = element.find('.slider-bar-wrap'),
        	slideMeasurement = element.find('.slider-measurement'),
        	slideContainer = slideTrigger.parent(),
        	sliderScalePx = slideContainer.width(), // The key part for slider width
        	dataSrc = $scope[attrs.srcDataKey][parseInt(attrs.srcDataIndex)],
        	dragStartPosX = null, dragMovedPosX = 0, dragStartPerctValue = 0,
        	dragEndCallbackTimer = null, dragCount = 0,
        	dragEndCallbackCountTime = 300, dragCountTime = 10;
        	
        	$scope.dragCallback = function(){
        		$scope.saveUpdate({
        			changeState: false
        		});
        	};
        	$scope.callBefore = function() {
        		$scope.translateScale.setup();
        	};
        	$scope.translatePosX = function(_perct,_valueStyle){
        		if (_perct === undefined) {
        			return;
        		}        		
            	var translateValue = (sliderScalePx*_perct/dataSrc.availableRange).toFixed(2),
            	translateStatement = 'translate('+translateValue+'px,0)',
            	valueStyle = _valueStyle || 'STRING';
    			if (valueStyle === 'OBJECT')
    				return {
						'-webkit-transform': translateStatement
					};
    			else
    				return '-webkit-transform:'+translateStatement+';';
            };
            $scope.translateScale = {
            	startPtX: Number(element.find(".slider-container").css('marginLeft').replace('px','')), 
            	endPtX: 0, startPercent: 0, endPercent: 0, limitPtX: 0, currentPtX: 0,
            	scaleLen: Number(element.find(".slider-container").css('width').replace('px','')),
            	setup: function(){
            		this.endPtX = Number(this.scaleLen + this.startPtX);
            		if (!$scope.isProspect) {
	            		if (dataSrc.currentPercentage <= dataSrc.availableRange) {
	            			this.endPercent = dataSrc.availableRange;
	            			this.limitPtX = this.endPtX + 0;
	                		this.currentPtX = Number(((dataSrc.currentPercentage / dataSrc.availableRange * this.scaleLen) + this.startPtX).toFixed(2));
	                		slideContainer.css({'width':''});
	            			sliderScalePx = slideContainer.width();
	            			slideTrack.css({'width':''});
	            			slideTrack.children().css({'width':''});
	            		} else {
	            			this.endPercent = dataSrc.currentPercentage;
	            			this.limitPtX = Number(((dataSrc.availableRange / dataSrc.currentPercentage * this.scaleLen) + this.startPtX).toFixed(2));
	            			this.currentPtX = this.endPtX + 0;
	            			var newSlideTrackWidth = this.limitPtX - this.startPtX;
	            			slideContainer.width(newSlideTrackWidth);
	            			sliderScalePx = slideContainer.width();
	            			slideTrack.width(newSlideTrackWidth);
	            			slideTrack.children().width('100%');
	            		}
	            		dataSrc.sliderScalePx = sliderScalePx;
            		} else {
            			this.endPercent = dataSrc.availableRange;
            			this.limitPtX = this.endPtX + 0;
            		}
            	}
            };
        	
        	
        	$scope.sliderDragFunction = function(evt){
        		if (!dataSrc.isUpdate) return false;
        		var evtType = evt.type, evtTarget = evt.target, targetPercentage;
        		switch (evtType) {
        		
        		case 'dragstart':
        			$ionicSideMenuDelegate.canDragContent(false);
        			if (dragStartPosX === null) {
        				dragStartPosX = evt.gesture.center.pageX;
        			}
        			targetPercentage = dataSrc.updateTargetPercentage ? dataSrc.updateTargetPercentage.toFixed(2) : 0; 
        			dragStartPerctValue = parseFloat(targetPercentage);
        			slideReading.addClass('activated');
        			break;
        		case 'drag':
        			var updatedPercentage = 0;
        			dragMovedPosX = Number((evt.gesture.center.pageX - dragStartPosX).toFixed(2));
        			updatedPercentage = dragStartPerctValue + parseFloat((dataSrc.availableRange*dragMovedPosX/sliderScalePx).toFixed(2));
        			updatedPercentage = Math.min(Math.max(updatedPercentage, 0), dataSrc.availableRange);
        			$scope.$apply(function(){
        				dataSrc.updateTargetPercentage = parseFloat(updatedPercentage.toFixed(2));
        			});
        			if (dragCount === dragCountTime) {
    					dragCount = 0;
    					$scope.dragCallback();
    					if (dragEndCallbackTimer !== null) {
    						$timeout.cancel(dragEndCallbackTimer);
    					}
        			} else {
        				dragCount ++;
	        			if (dragEndCallbackTimer !== null) {
	        				$timeout.cancel(dragEndCallbackTimer);
	        			}
	        			dragEndCallbackTimer = $timeout($scope.dragCallback, dragEndCallbackCountTime);
        			}
        			break;
        		case 'release':
        			$ionicSideMenuDelegate.canDragContent(true);
        			dragStartPosX = null;
        			dragMovedPosX = 0;
        			dragStartPerctValue = 0;
        			slideReading.removeClass('activated');
        			break;
        		}
        		
        	};
        	
        	$scope.init = function(){
        		
        		dataSrc.sliderScalePx = sliderScalePx;
            	$ionicGesture.on('dragstart drag release',
                this.sliderDragFunction,element.find('.slider-trigger'));
        		var styleStatement = this.translatePosX(dataSrc.updateTargetPercentage,'OBJECT');
        		dataSrc.callBeforeEdit = this.callBefore;
        	};
        	$scope.init();
        };
    }]);
    
});