define([
  'app/app',
  'js/Util/DataPersister',
  'js/Util/LogUtil',
  'js/appState',
  'js/Adapters/PortfolioAdapter'
], function (app,DataPersister,LogUtil,AppState,PortfolioAdapter) {
  'use strict';

  app.factory('TargetPortfolioDAO', function(){
	  var dao = {};
	  var _data =[];
	  /*
	   * The following 3 functions are only called internally
	   */
	  var getJSONStoreData = function(successCallback, failureCallback) {
	      DataPersister.getAppDataByNameValue('storedTargetPortfolio',successCallback,failureCallback);
	  };
	  var setJSONStoreData = function(data, successCB, failureCB) {
		  DataPersister.setAppDataByNameValue('storedTargetPortfolio', data, successCB, failureCB);
	  };
	  var initJSONStore = function (successCallback, failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list for all target portfolios');
		  
		  getJSONStoreData(function(data){
	    	  if (typeof data === 'undefined' || data === null || data === "null") {
	    		data = [];  
	    		setJSONStoreData(data);
	    	  }
	    	  AppState.storedTargetPortfolio = data;
	    	  successCallback(data);
	      }, function(errObj) {
	    	  failureCallback(errObj);
	      });
	  };  
	  /*
	   * Construct dao
	   */
	  dao.listAll = function(successCallback,failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list of target portfolios');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Successfully retrieved list of target portfolios');
			  AppState.storedTargetPortfolio = result;
			  if (typeof successCallback === 'function') {
				  successCallback(result);
			  }
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed initialising JSONStore for target portfolio: ['+errObj.err+']'+errObj.msg);

    		  if (typeof failureCallback === 'function') {
    			  failureCallback(result);
			  }
		  };
		  initJSONStore(invocationSuccessCallback, invocationFailureCallback);
	  };
	  dao.retrieveTargetPortfolioByID = function(id, successCallback, failureCallback) {
		  var portfolio = null;
		  
		  for (var i = 0 ; i < AppState.storedTargetPortfolio.length ; i++) {
			  if (String(AppState.storedTargetPortfolio[i].id) === id) {
				  portfolio = AppState.storedTargetPortfolio[i];
			  }
		  }
		  
		  if (portfolio) {
			  LogUtil.logDebug('Found target portfolio for id: '+id);
			  successCallback(portfolio);
		  } else {
			  LogUtil.logDebug('No target portfolio in memory matched id: '+id);
			  failureCallback({msg: 'Cannot find target portfolio'});
		  }
	  };
	  dao.addTargetPortfolio = function(data, successCallback, failureCallback) {
		  var now = Date.now();
		  var portfolio;
		  if (typeof data === 'object' && !Array.isArray(data)) {
			  portfolio = data;
			  portfolio.id = now;
			  portfolio.lastModifiedDate = now;
		  } else {
			  portfolio = {
				id : now,
				data : data,
				lastModifiedDate : now
			  }; 
		  }
		  
		  LogUtil.logDebug('Number of target portfolio in memory BEFORE insert: '+AppState.storedTargetPortfolio.length);
		  AppState.storedTargetPortfolio.unshift(portfolio);
		  LogUtil.logDebug('Number of target portfolio in memory AFTER insert: '+AppState.storedTargetPortfolio.length);
		  LogUtil.logDebug('ID of inserted portfolio is '+portfolio.id);

		  LogUtil.logDebug('Attempt to insert target portfolio to JSONStore');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of target portfolio in JSONStore AFTER insert: '+result.length);
			  AppState.storedTargetPortfolio = result;
			  successCallback(portfolio.id);
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed inserting target portfolio to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  setJSONStoreData(AppState.storedTargetPortfolio,invocationSuccessCallback,invocationFailureCallback);
		  
		 
	  };
	  dao.deleteTargetPortfolioByID = function(id, successCallback, failureCallback) {
		  var index = -1;
		  for (var i = 0 ; i <AppState.storedTargetPortfolio.length ; i++) {
			  if (AppState.storedTargetPortfolio[i].id == id) {
				  index = i;
			  }
		  }
		  if (index > -1) {
    		  LogUtil.logDebug('Number of target portfolio in memory BEFORE deletion: '+AppState.storedTargetPortfolio.length);
			  AppState.storedTargetPortfolio.splice(index,1);
    		  LogUtil.logDebug('Number of target portfolio in memory AFTER deletion: '+AppState.storedTargetPortfolio.length);
			  var invocationSuccessCallback = function(result) {
				  LogUtil.logDebug('Number of target portfolio in JSONStore AFTER deletion: '+result.length);
				  AppState.storedTargetPortfolio = result;
				  successCallback(result);
			  };
			  var invocationFailureCallback = function(errObj) {
	    		  LogUtil.logError('Failed deleting target portfolio in JSONStore: ['+errObj.err+']'+errObj.msg);
	    		  failureCallback(errObj);
			  };
			  setJSONStoreData(AppState.storedTargetPortfolio, invocationSuccessCallback,invocationFailureCallback);

		  } else {
    		  LogUtil.logDebug('No portfolio is deleted because if no target portfolio matching id: '+id);
			  failureCallback({msg : 'Cannot find target portfolio'});
		  }
	  };
	  dao.updateTargetPortfolio = function(data, successCallback, failureCallback) {
		  var id = data.id;
		  LogUtil.logDebug('updatePortfolio id: '+id);
		  for (var i = 0 ; i < AppState.storedTargetPortfolio.length ; i++) {
			  if (AppState.storedTargetPortfolio[i].id === id) {
				  AppState.storedTargetPortfolio[i] = data;
			  }
		  }
		  LogUtil.logDebug(AppState.storedTargetPortfolio);
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of target portfolio in JSONStore AFTER insert: '+result.length);
			  successCallback();
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed updating target portfolio to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  
		  setJSONStoreData(AppState.storedTargetPortfolio, invocationSuccessCallback, invocationFailureCallback);
	  };
	  dao.uploadTargetPortfolioPDF=function(targetPortfolioToSubmit, successCallback, failureCallback){
		  var adapterSuccessCallback = function(data) {
	            if (data && data.responseJSON) {	            	
	            	LogUtil.logInfo('TargetPortfolioDAO :adapterSuccessCallback : uploadTargetPortfolioPDF success');
	                successCallback(targetPortfolioToSubmit);
	            } else {
	                LogUtil.logError('TargetPortfolioDAO : adapterSuccessCallback  : uploadTargetPortfolioPDF error');
	                failureCallback(targetPortfolioToSubmit);
	            }
	        };	 	       
	       var adapterFailureCallback = function(data) {
	            LogUtil.logError('TargetPortfolioDAO : uploadTargetPortfolioPDF : adapterFailureCallback  : Fail to invoke TargetPortfolioAdapter');
	            if (data && data.responseJSON && data.responseJSON.errorCode) {
	            	targetPortfolioToSubmit.errorCode = data.responseJSON.errorCode;
	            }
	            failureCallback(targetPortfolioToSubmit);
	        };
	        PortfolioAdapter.uploadTargetPortfolioPDFFiles(AppState.userID,targetPortfolioToSubmit.fileContent,adapterSuccessCallback, adapterFailureCallback);
		  
 
	  };
	  
	  return dao;
  });
});
