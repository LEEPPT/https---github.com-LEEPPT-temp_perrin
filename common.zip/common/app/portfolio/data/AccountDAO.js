define([
    'app/app',
    'js/Util/DataPersister',
    'js/Util/LogUtil',
    'js/Adapters/AccountAdapter'
], function(app, DataPersister, LogUtil,AccountAdapter) {
    'use strict';

    app.factory('AccountDAO', function() {
        var dao = {};
        dao.getAccountsBySearchCriteria = function(searchCriteria, successCallback, failureCallback) {
            var adapterSuccessCallback = function(result) {
                if (result && result.responseJSON && result.responseJSON.isSuccessful) {
                    LogUtil.logInfo('AccountDAO : getAccountsBySearchCriteria : adapterSuccessCallback : isSuccessful in JSON response is true');
                    successCallback(result);
                } else {
                    LogUtil.logError('AccountDAO : getAccountsBySearchCriteria : adapterSuccessCallback : isSuccessful in JSON response is false');
                    failureCallback(result);
                }
                
            };
            var adapterFailureCallback = function(data) {
                LogUtil.logError('AccountDAO : getAccountsBySearchCriteria : adapterFailureCallback : Fail to invoke AccountAdapter');
                failureCallback(data);
            };
            AccountAdapter.getEntitledAccounts(searchCriteria, adapterSuccessCallback, adapterFailureCallback);
            
        };
        return dao;
    });
});