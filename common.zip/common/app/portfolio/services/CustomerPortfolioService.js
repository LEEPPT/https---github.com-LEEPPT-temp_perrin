define([
    'app/app',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/DataMaskingUtil',
    'app/portfolio/data/CustomerPortfolioDAO'
], function(app, LogUtil, CommonUtil, DataMaskingUtil, CustomerPortfolioDAO) {
    'use strict';

    app.service('CustomerPortfolioService', ['CustomerPortfolioDAO', '$filter',
        function(CustomerPortfolioDAO, $filter) {
            var customerPortfolioService = {};
            customerPortfolioService.generateCustomerPortfolio = function(customerInfo, successCallback, failureCallback) {
                var daoSuccessCallback = function(data) {
                    if (data && data.responseJSON && data.responseJSON.isSuccessful) {
                        var result = data.responseJSON;
                        var portfolioData = {};
                        portfolioData.portfolioName = customerInfo.portfolioName;
                        portfolioData.portfolioCurrency = result.portfolioCurrency;
                        portfolioData.totalAUM = result.totalAUM;
                        portfolioData.lastUpdateDate = result.lastUpdateDate;
                        angular.forEach(result.accountList, function(value, key) {
                            value.accountName = DataMaskingUtil.maskAccountName(value.accountName);
                            value.accountNumber = DataMaskingUtil.maskAccountNumber(value.accountNumber);
                        });
                        portfolioData.accountList = result.accountList;
                        portfolioData.assetAllocationHistoryList = result.assetAllocationHistoryList;
                        portfolioData.netAssetValueHistoryList = result.netAssetValueHistoryList;
                        portfolioData.currencyDistributionList = result.currencyDistributionList;
                        portfolioData.portfolioHoldingsList = result.portfolioHoldingsList;
                        portfolioData.performanceAnalysis = result.performanceAnalysis;
                        portfolioData.benchmarkConfig = result.benchmarkConfig;
                        if (portfolioData.benchmarkConfig) {
	                        for (var i = 0; i < portfolioData.benchmarkConfig.length; i ++) {
	                        	portfolioData.benchmarkConfig[i].display = true;
	                        }
                        }
                        
//                        if ((!portfolioData.netAssetValueHistoryList || portfolioData.netAssetValueHistoryList.length < 3) || 
//                        		(!portfolioData.assetAllocationHistoryList || portfolioData.assetAllocationHistoryList.length < 3) ||
//                        		(!portfolioData.performanceAnalysis || !portfolioData.performanceAnalysis.detailsList || portfolioData.performanceAnalysis.detailsList.length < 6)) {
//                        	data.responseJSON.errorCode = 'ERR_INSUFFICIENT_PORTFOLIO_DATA';
//                        	LogUtil.logInfo('CustomerPortfolioService -> generateCustomerPortfolio -> daoSuccessCallback : data do not meet prerequiste for charts: ' + portfolioData);
//                        	failureCallback(data.responseJSON);
//                        } else {
                        	LogUtil.logInfo('CustomerPortfolioService -> generateCustomerPortfolio -> daoSuccessCallback : ' + portfolioData);
                            customerPortfolioService.saveCustomerPortfolio(portfolioData, successCallback, failureCallback);
//                        }
                    } else {
                        LogUtil.logError('CustomerPortfolioService -> generateCustomerPortfolio -> daoSuccessCallback : isSuccessful is false');
                        failureCallback(data.responseJSON);
                    }
                };
                var daoFailureCallback = function(data) {
                    LogUtil.logError('CustomerPortfolioService -> generateCustomerPortfolio -> daoFailureCallback');
                    failureCallback(data.responseJSON);
                };
                CustomerPortfolioDAO.getCustomerPortfolio(customerInfo, daoSuccessCallback, daoFailureCallback);
            };
            customerPortfolioService.saveCustomerPortfolio = function(portfolioData, successCallback, failureCallback) {
                LogUtil.logDebug('CustomerPortfolioService -> saveCustomerPortfolio : ' + portfolioData);
                var daoSuccessCallback = function(id) {
                    LogUtil.logInfo('CustomerPortfolioService -> saveCustomerPortfolio -> daoSuccessCallback : id = ' + id);
                    successCallback(id);
                };
                var daoFailureCallback = function(errorObj) {
                    LogUtil.logError('CustomerPortfolioService -> saveCustomerPortfolio -> daoFailureCallback : Customer portfolio data cannot be save to local storage');
                    errorObj.errorCode = 'ERR_CUSTOMER_PORTFOLIO_SAVE_FAIL';
                    failureCallback(null);
                };

                CustomerPortfolioDAO.addPortfolio(portfolioData, daoSuccessCallback, daoFailureCallback);
            };
            customerPortfolioService.getCustomerPortfolioByID = function(portfolioID, successCallback, failureCallback) {
                LogUtil.logInfo('CustomerPortfolioService -> getCustomerPortfolioByID : ' + portfolioID);
                var daoSuccessCallback = function(data) {
                    LogUtil.logInfo('CustomerPortfolioService -> getCustomerPortfolioByID -> daoSuccessCallback : ' + portfolioID);
                    successCallback(data);
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('CustomerPortfolioService -> getCustomerPortfolioByID -> daoFailureCallback');
                    failureCallback();
                };

                CustomerPortfolioDAO.retrievePortfolio(portfolioID, daoSuccessCallback, daoFailureCallback);
            };
            customerPortfolioService.updateCustomerPortfolioByID = function(data, successCallback, failureCallback) {
                LogUtil.logInfo('CustomerPortfolioService -> updateCustomerPortfolioByID : ' + data.id);
                var daoSuccessCallback = function() {
                    LogUtil.logInfo('CustomerPortfolioService -> updateCustomerPortfolioByID -> daoSuccessCallback');
                    successCallback(data);
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('CustomerPortfolioService -> updateCustomerPortfolioByID -> daoFailureCallback');
                    failureCallback();
                };
                CustomerPortfolioDAO.updatePortfolio(data, daoSuccessCallback, daoFailureCallback);
            };
            customerPortfolioService.deleteCustomerPortfolioByID = function(id, successCallback, failureCallback) {
                LogUtil.logInfo('CustomerPortfolioService -> deleteCustomerPortfolioByID : ' + id);
                var daoSuccessCallback = function(result) {
            		LogUtil.logInfo('CustomerPortfolioService -> deleteCustomerPortfolioByID -> daoSuccessCallback');
            		
                	if (typeof successCallback === 'function') {
                		successCallback(result);
                	}
                };
                var daoFailureCallback = function(errObj) {
            		LogUtil.logInfo('CustomerPortfolioService -> deleteCustomerPortfolioByID -> daoFailureCallback');

                	if (typeof failureCallback === 'function') {
                		failureCallback(errObj);
                	}
                };
            	CustomerPortfolioDAO.deletePortfolio(id, daoSuccessCallback, daoFailureCallback);
            };
            /*
             * Return portfolio ID @param {Object} data @return {String} portfolioID
             */
            customerPortfolioService.getPortfolioID = function(data) {
                var portfolioID = data.id;
                LogUtil.logInfo('CustomerPortfolioService -> getPortfolioID: ' + portfolioID);
                return portfolioID;
            };

            /*
             * Return portfolio name @param {Object} data @return {String}
             * portfolioName
             */
            customerPortfolioService.getPortfolioName = function(data) {
                    var portfolioName = data.portfolioName;
                    LogUtil.logInfo('CustomerPortfolioService -> getPortfolioName: ' + portfolioName);
                    return data.portfolioName;
                };

            /*
             * Return portfolio currency @param {Object} data @return {String}
             * portfolioCurrency
             */
            customerPortfolioService.getPortfolioCurrency = function(data) {
                    var portfolioCurrency = data.portfolioCurrency;
                    LogUtil.logInfo('CustomerPortfolioService -> getPortfolioCurrency: ' + portfolioCurrency);
                    return data.portfolioCurrency;
                };

            /*
             * 
             */
            customerPortfolioService.getLatestAssetAllocation = function(data) {
                var latestAssetAllocation = [];
                for (var i = 0; i < data.assetAllocationHistoryList[0].detailsList.length; i++) {
                    var entry = data.assetAllocationHistoryList[0].detailsList[i];
                    if (typeof entry.percentage === 'undefined') {
                        entry.percentage = ((entry.amount / data.totalAUM) * 100)
                            .toFixed(2);
                    }
                    if (Number(entry.percentage) !== 0) {
                        latestAssetAllocation.push(entry);
                    }
                }
                LogUtil.logInfo('CustomerPortfolioService -> getLatestAssetAllocation');
                LogUtil.logDebug('CustomerPortfolioService -> getLatestAssetAllocation : '+latestAssetAllocation);
                return latestAssetAllocation;
            };

            /*
             * Return latest asset allocation object by data and assetClassID @param
             * {Object} data @param {String} assetClassID @return {Object} latest
             * asset allocation object Example:
             * {"amount":27879613.28,"percentage":25.56,"category":"stock","color":"#EC8626","legendLabel":"Stock"}
             */
            customerPortfolioService.getLatestAssetAllocationByAssetClass = function(data, assetClassID) {
                var latestAssetAllocationByAssetClass = null;
                for (var i = 0; i < data.assetAllocationHistoryList[0].detailsList.length; i++) {
                    var entry = data.assetAllocationHistoryList[0].detailsList[i];
                    if (entry.assetClassID === assetClassID) {
                        // to assetClassID
                        latestAssetAllocationByAssetClass = entry;
                        break;
                    }
                }
                LogUtil.logInfo('CustomerPortfolioService -> getLatestAssetAllocationByAssetClass');
                LogUtil.logDebug('CustomerPortfolioService -> getLatestAssetAllocationByAssetClass : '+latestAssetAllocationByAssetClass);
                return latestAssetAllocationByAssetClass;
            };

            /*
             * 
             */
            customerPortfolioService.getAssetAllocationHistory = function(data) {
                var assetAllocationHistory = data.assetAllocationHistoryList;
                LogUtil.logInfo('CustomerPortfolioService -> getAssetAllocationHistory');
                LogUtil.logDebug('CustomerPortfolioService -> getAssetAllocationHistory : ' +assetAllocationHistory);
                return assetAllocationHistory;
            };

            /*
             * 
             */
            customerPortfolioService.getAssetAllocationHistoryByAssetClass = function(data, assetClassID, upToMonth) {
            	var assetAllocationHistoryByAssetClass = [];
            	if (data && data.assetAllocationHistoryList && data.assetAllocationHistoryList.length > 0) {
            		var historyList = data.assetAllocationHistoryList;
            		for (var i = 0; i < historyList.length && i < upToMonth; i++) {
            			var detailsList = historyList[i].detailsList;
            			for (var j = 0; detailsList && j < detailsList.length; j++) {
            				if (detailsList[j].assetClassID === assetClassID) { //TODO: change category to assetClassID
            					assetAllocationHistoryByAssetClass.push({
            						month: historyList[i].month,
            						year: historyList[i].year,
            						amount: detailsList[j].amount
            					});
                			}
            			}
            		}
            	}
            	LogUtil.logInfo('CustomerPortfolioService -> getAssetAllocationHistoryByAssetClass');
            	LogUtil.logDebug('CustomerPortfolioService -> getAssetAllocationHistoryByAssetClass : '+assetAllocationHistoryByAssetClass);
            	return assetAllocationHistoryByAssetClass;
            };
            
            /*
             * 
             */
            customerPortfolioService.getNetAssetValueHistory = function(data) {
                var navHistory = data.netAssetValueHistoryList;
                LogUtil.logInfo('CustomerPortfolioService -> getNetAssetValueHistory');
                LogUtil.logDebug('CustomerPortfolioService -> getNetAssetValueHistory : '+ navHistory);
                return navHistory;
            };
            /*
             * 
             */
            customerPortfolioService.getNetAssetValueHistoryByCategory = function(data, category, upToMonth) {
            	var navHistoryByAssetClass = [];
            	if (data && data.netAssetValueHistoryList && data.netAssetValueHistoryList.length > 0) {
            		var historyList = data.netAssetValueHistoryList;
            		for (var i = 0; i < historyList.length && i < upToMonth; i++) {
            			var detailsList = historyList[i].detailsList;
            			for (var j = 0; detailsList && j < detailsList.length; j++) {
            				if (detailsList[j].category === category) { 
            					navHistoryByAssetClass.push({
            						month: historyList[i].month,
            						year: historyList[i].year,
            						amount: detailsList[j].amount
            					});
                			}
            			}
            		}
            	}
            	LogUtil.logInfo('CustomerPortfolioService -> getNetAssetValueHistoryByCategory');
            	LogUtil.logDebug('CustomerPortfolioService -> getNetAssetValueHistoryByCategory : '+navHistoryByAssetClass);
            	return navHistoryByAssetClass;
            };
            /*
             * 
             */
            customerPortfolioService.getCurrencyDistribution = function(data) {
                var currencyDistributionList = data.currencyDistributionList;
                LogUtil.logInfo('CustomerPortfolioService -> getCurrencyDistribution');
                LogUtil.logDebug('CustomerPortfolioService -> getCurrencyDistribution : '+currencyDistributionList);
                return currencyDistributionList;
            };

            /*
             * 
             */
            customerPortfolioService.getPortfolioHoldings = function(data) {
                var portfolioHoldingsList = data.portfolioHoldingsList;
                LogUtil.logInfo('CustomerPortfolioService -> getPortfolioHoldings');
                LogUtil.logDebug('CustomerPortfolioService -> getPortfolioHoldings : '+portfolioHoldingsList);
                return portfolioHoldingsList;
            };

            /*
             * 
             */
            customerPortfolioService.getPortfolioHoldingsBySectionID = function(data, sectionID) {
                var portfolioHoldingsBySectionID = null;
                for (var i = 0; i < data.portfolioHoldingsList.length; i++) {
                    if (data.portfolioHoldingsList[i].sectionID === sectionID) {
                        portfolioHoldingsBySectionID = data.portfolioHoldingsList[i];
                        break;
                    }
                }
                if (portfolioHoldingsBySectionID === null) {
                	return -1;
                } 
                if (portfolioHoldingsBySectionID && portfolioHoldingsBySectionID.contentList) {
                	portfolioHoldingsBySectionID.totalRecords = portfolioHoldingsBySectionID.contentList.length;
                } else {
                 	portfolioHoldingsBySectionID.totalRecords = 0;
                }
                var latestAssetAllocationByAssetClass = this.getLatestAssetAllocationByAssetClass(data, sectionID);
                if (latestAssetAllocationByAssetClass && portfolioHoldingsBySectionID) {
                    portfolioHoldingsBySectionID.amount = latestAssetAllocationByAssetClass.amount;
                    portfolioHoldingsBySectionID.percentage = latestAssetAllocationByAssetClass.percentage;
                }
                LogUtil.logInfo('CustomerPortfolioService -> getPortfolioHoldingsBySectionID');
                LogUtil.logDebug('CustomerPortfolioService -> getPortfolioHoldingsBySectionID : '+portfolioHoldingsBySectionID);
                return portfolioHoldingsBySectionID;
            };
            customerPortfolioService.getFormattedLastUpdate = function(data) {
            	LogUtil.logInfo('CustomerPortfolioService -> getFormattedLastUpdate');
            	LogUtil.logDebug('CustomerPortfolioService -> getFormattedLastUpdate : '+data.lastUpdateDate);
            	return (data && data.lastUpdateDate) ? CommonUtil.getDateTimeString($filter('date')(new Date(data.lastUpdateDate),'dd MMM yyyy'), false) : '';
            };
            customerPortfolioService.hasNegativePercentageAssetAllocationHistory = function(data) {
            	var arr = data.assetAllocationHistoryList[0].detailsList;
            	var hasNegativeValue = false;
            	for (var i in arr) {
            		var item = arr[i];
            		if (Number(item.percentage) < 0) {
            			hasNegativeValue = true;
            			break;
            		}
            	}
            	return hasNegativeValue;
            };
            customerPortfolioService.findIndexByDate = function(data, allocation, date) {
            	LogUtil.logInfo('CustomerPortfolioService -> findIndexByDate - allocation: '+ allocation);
            	LogUtil.logInfo('CustomerPortfolioService -> findIndexByDate - date: '+ date);

            	var dataAllocation, dateIndex = -1;
            	if ('asset' === allocation) {
            		dataAllocation = customerPortfolioService.getAssetAllocationHistory(data);
            	} else if ('nav' === allocation) {
            		dataAllocation = customerPortfolioService.getNetAssetValueHistory(data);
            	}
            	
            	dataAllocation.forEach(function(item, index) {
            		if (item.year+'-'+item.month === date) {
            			dateIndex = index;
            		}
            	});
            	LogUtil.logInfo('CustomerPortfolioService -> findIndexByDate - index: '+ dateIndex);
        	
            	return dateIndex;
            };
            return customerPortfolioService;
        }
    ]);
});