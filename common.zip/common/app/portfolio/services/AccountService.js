define([
  'app/app',
  'js/Util/LogUtil',
  'js/Util/CommonUtil',
  'js/Util/DataMaskingUtil',
  'app/portfolio/data/AccountDAO'
], function (app,LogUtil,CommonUtil,DataMaskingUtil,AccountDAO) {
  'use strict';
  /**
   * @memberof app
   * @ngdoc service
   * @name AccountService
   * @param {dao} AccountDAO data access class for accounts
   * @description 
   *   Business logic for accounts
   */
  app.service('AccountService', ['AccountDAO',function (AccountDAO) {
	  var accountService ={};
	  accountService.accountSearchResult = [];
	  accountService.selectedAccounts = [];
	  	/**
	     * Search user's entitled accounts
	     * @memberof AccountService
	     * @function searchEntitleAccount
	     * @param {object} search criteria
	     * @param {function} successCallback function defined by the caller
	     * @param {function} failureCallback function defined by the caller
	     * @description return search result grouped and sorted by account number
	     */
	  accountService.searchEntitleAccount = function (searchCriteria,successCallback,failureCallback) {
			var daoSuccessCallback = function(result) {
				if (result && result.responseJSON && result.responseJSON.resultList && result.responseJSON.resultList.length > 0) {
					var groupedResult = accountService.groupSearchResultByAccountNumber(result.responseJSON.resultList);
					accountService.sortSearchResultByKey(groupedResult,'accountNumber','ascn',successCallback);
					LogUtil.logTrace('AccountService : searchEntitleAccount : daoSuccessCallback ' + accountService.accountSearchResult);
					successCallback();
				} else {
					LogUtil.logError('AccountService : searchEntitleAccount : daoSuccessCallback : resultList is empty');
					failureCallback(result);
				}
			};
			var daoFailureCallback = function(data) {
				LogUtil.logError('AccountService : searchEntitleAccount : daoFailureCallback');
				failureCallback(data);
			};
			AccountDAO.getAccountsBySearchCriteria(searchCriteria,daoSuccessCallback,daoFailureCallback);
		};
		
		/**
	     * Group search result by account number
	     * @memberof AccountService
	     * @function groupSearchResultByAccountNumber
	     * @param {array} account search result
	     * @return {array} grouped account search result list
	     * @description 
	     * 1.group account search result by account number. <br/>
	     * 2.customer names are with same account number are grouped in one list  <br/>
	     * 3.apply data masking rules to account name, account number and customer name  <br/>
	     */
		accountService.groupSearchResultByAccountNumber = function (result){
			var accountNumberList = new Map();
			angular.forEach(result, function(value, key){
				var customerNameList = [];
			if(typeof (accountNumberList.get(value.accountNumber))=== 'undefined'){
					
					customerNameList.push(DataMaskingUtil.maskCustomerName(value.customerName));
					
				}else {
					
					customerNameList = accountNumberList.get(value.accountNumber).customerName;
					customerNameList.push(DataMaskingUtil.maskCustomerName(value.customerName));
				}
			var groupedResult = {
				    accountNumber : value.accountNumber,
				    accountName : DataMaskingUtil.maskAccountName(value.accountName),
				    customerName : customerNameList,
				    displayAccountNumber : DataMaskingUtil.maskAccountNumber(value.accountNumber)
				};
					accountNumberList.set(value.accountNumber,groupedResult);
			    
			 });
			LogUtil.logTrace('search result length '+result.length);
			LogUtil.logTrace('grouped result length '+accountNumberList.size);
			var accountResultList =  Array.from(accountNumberList.values());
			angular.forEach(accountResultList, function(value, key){
				if(value.customerName.length>1){
					value.customerName = CommonUtil.sortArrayByKey(value.customerName,'customerName');
				}
				
			});
			return accountResultList;
		};
		
		/**
	     * Sort account search result by key
	     * @memberof AccountService
	     * @function sortSearchResultByKey
	     * @param {array} account search result
	     * @param {string} field name of the sorting key
	     * @param {string} sorting order : ascn or dscn
	     * @return {array} sorted account search result list
	     * @description sort account search result by sorting key and sorting order
	     */

		accountService.sortSearchResultByKey = function (searchResult,sortKey,_orderRule){
			var orderRule = _orderRule || 'ascn';
			accountService.accountSearchResult=CommonUtil.sortArrayByKey(searchResult,sortKey,orderRule);
			return accountService.accountSearchResult;
		};
		return accountService;
      
    }
  ]);
});
