define([
	'js/constants'
        ], function(Constants) {
	var version = {

		buildVersion : '1.0.45',
		appVersion : '1.0',
		lastModifyTime : '2016-05-27 11:15',
		
		// JSONStore
		JSONStoreUser : 'BEAiPortfolio',
		JSONStoreKey : 'Abcd1234!',
		
		isDevMode : 'Y',
		isEnableAnalytics : 'Y',
		
		loggerPackageName : 'com.bea.local.iPortfolio',
		remoteLogging : true,
        logLevel : Constants.DEBUG,
        logFilterLevel : Constants.FILTER_DEBUG,
        logSize : 30,
		
		//MQA
		isEnableMQA: 'N',
		MQAMode : '',
		MQAHost : '',
		MQAIOSAppKey : '',
		MQAProtocol : ''
	};
	return version;
});
