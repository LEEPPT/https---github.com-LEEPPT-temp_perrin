define([
  'app/app',
  'js/appState',
  'environment'
], function (app,AppState,Environment) {
  'use strict';
  /**
   * @memberof app
   * @ngdoc controller
   * @name BaseCtrl
   * @param $scope {service} controller scope
   * @description 
   *   Base controller for common handling logic
   */
  app.controller('BaseCtrl', [
    '$scope',
    function ($scope) {
    	$scope.userID = AppState.userID;
    	if(AppState.userInfo!==null){
    		$scope.userFullName = AppState.userInfo.userFullName;
    	}else {
    		$scope.userFullName = AppState.userID;
    	}
    	$scope.appVersion = Environment.buildVersion;
    	var currentTime = new Date();
    	$scope.currentYear = currentTime.getFullYear();
    }
  ]);
});
