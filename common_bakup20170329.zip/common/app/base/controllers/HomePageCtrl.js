define([
    'app/app',
    'js/Util/DataPersister',
    'js/appState',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'app/raq/services/RAQService',
    'js/Util/PdfPluginUtil',
	'js/constants',
    'js/appConfig',
    'js/Util/FunctionActivator',
], function(app, DataPersister, AppState, LogUtil, CommonUtil, RAQService, PdfPluginUtil, Constants, AppConfig, FunctionActivator) {
    'use strict';
    app.controller('HomePageCtrl', [
        '$scope',
        '$translate',
        '$state',
        '$filter',
        '$ionicModal',
        'RAQService',
        '$stateParams',
        function($scope,$translate,$state, $filter,$ionicModal,RAQService,$stateParams) {        	
        	$scope.loadStoredPortfolio = function(){
	            LogUtil.logDebug('HomePageCtrl -> loadStoredPortfolio');
	            //LogUtil.logDebug(AppState.storedPortfolio);
	            var storedPortfolios = AppState.storedPortfolio;
	            for (var i = 0; storedPortfolios && i < storedPortfolios.length; i++) {
	            	if (storedPortfolios[i].lastModifiedDate) {
	            		storedPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedPortfolios[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredPortfolio: Portfolio ID ' + storedPortfolios[i].id + ', displayDate: ' + storedPortfolios[i].displayDate);
	            	}else {
	            		storedPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedPortfolios[i].id),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredPortfolio: Portfolio ID ' + storedPortfolios[i].id + ', displayDate: ' + storedPortfolios[i].displayDate);
	            	}
	            }
            	$scope.storedPortfolios = storedPortfolios;
        	};
        	$scope.loadStoredTargetPortfolio = function(){
	            LogUtil.logDebug('HomePageCtrl -> loadStoredTargetPortfolio');
	            var storedTargetPortfolios = AppState.storedTargetPortfolio;
	            for (var i = 0; storedTargetPortfolios && i < storedTargetPortfolios.length; i++) {
	            	if (storedTargetPortfolios[i].lastModifiedDate) {
	            		storedTargetPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedTargetPortfolios[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredTargetPortfolio: Portfolio ID ' + storedTargetPortfolios[i].id + ', displayDate: ' + storedTargetPortfolios[i].displayDate);
	            	}else {
	            		storedTargetPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedTargetPortfolios[i].id),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredTargetPortfolio: Portfolio ID ' + storedTargetPortfolios[i].id + ', displayDate: ' + storedTargetPortfolios[i].displayDate);
	            	}
	            }
            	$scope.storedTargetPortfolios = storedTargetPortfolios;
        	};     
         	$scope.loadStoredRAQ = function(){
	            var storedRAQResult = AppState.storedRAQResult;
	            for (var i = 0; storedRAQResult && i < storedRAQResult.length; i++) {
	            	if (storedRAQResult[i].lastModifiedDate) {
	            		storedRAQResult[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedRAQResult[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredRAQ: storedRAQResult  ' + storedRAQResult[i].id + ', displayDate: ' + storedRAQResult[i].displayDate);
	            	}else {
	            		storedRAQResult[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedRAQResult[i].id),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredRAQ: storedRAQResult  ' + storedRAQResult[i].id + ', displayDate: ' + storedRAQResult[i].displayDate);
	            	}
	            }
            	$scope.storedRAQResult = storedRAQResult;
	            
	            if (storedRAQResult.length > 0 && AppState.appMode == Constants.APP_MODE_ONLINE && !AppState.isRAQReminderShown) {
	            	LogUtil.logDebug('HomePageCtrl -> loadStoredRAQ: Show RAQ reminder');
	                CommonUtil.displayConfirmBox($translate.instant('RAQ_PENDING_RAQ_MESSAGE_TITLE'), $translate.instant('RAQ_PENDING_RAQ_MESSAGE') + '\n\n' + storedRAQResult[0].customerName, $translate.instant('BTN_OK'), function() {
	                	$scope.uploadRAQ(0);
		            }, $translate.instant('BTN_CANCEL'), function() {
			            AppState.isRAQReminderShown = true;
		            });
            	} else {
		            AppState.isRAQReminderShown = true;
            	}

        	};
        	$scope.loadStoredCallReport = function(){
	            var storedCallReport = AppState.storedCallReport;
	            for (var i = 0; storedCallReport && i < storedCallReport.length; i++) {
	            	if (storedCallReport[i].lastModifiedDate) {
	            		storedCallReport[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedCallReport[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredCallReport: storedCallReport  ' + storedCallReport[i].id + ', displayDate: ' + storedCallReport[i].displayDate);
	            	}else {
	            		storedCallReport[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedCallReport[i].id),'dd MMM yyyy, HH:mm'), true);
	                    LogUtil.logDebug('HomePageCtrl -> loadStoredCallReport: storedCallReport  ' + storedCallReport[i].id + ', displayDate: ' + storedCallReport[i].displayDate);
	            	}
	            }
            	$scope.storedCallReport = storedCallReport;
        	};
            $scope.goToPortfolio = function(id) {
                if (!id || id === '') {
                	LogUtil.logError('HomePageCtrl -> goToPortfolio: ID is empty');
                    return;
                }
                $state.go('base.portfolio_cover', {
                    id: id
                }, {
                    reload: true
                });
            };
            $scope.goToTargetPortfolio = function(index){
            	var param = {
    			    	data: null,
    			    	source : 'homepage',
    			    	targetPortfolio : angular.toJson(this.storedTargetPortfolios[index])
    			    };
    			$state.go('base.target_portfolio', param, {reload: true});
            };
        	$scope.goToCallReport = function(index) {
                var param = {
    			    	data: null,
    			    	source : 'homepage',
    			    	callReport : angular.toJson(this.storedCallReport[index])
    			    };    				
    			$state.go('base.call_report_creation', param, {reload: true});
        	};
          
        	//delete with no confirmation
        	$scope.deleteRAQOnly = function(id) {         		
        			RAQService.deleteStoredRAQResult(id,this.deleteRAQSuccessCallback,this.deleteRAQFailureCallback); 							
        	}; 
        	
        	$scope.deleteRAQSuccessCallback = function() {
        		LogUtil.logDebug('HomePageCtrl -> deleteRAQSuccessCallback' );
        	};  
        	$scope.deleteRAQFailureCallback = function(errObj) {        		
        		LogUtil.logError('HomePageCtrl -> deleteRAQFailureCallback');
        		WL.SimpleDialog.show($translate.instant('ERR_DELETE_RAQ'),$translate.instant('ERR_DELETE_RAQ_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
    			busyIndicator.hide();
        	};
        	
        	$ionicModal.fromTemplateUrl('./app/raq/templates/raq_submit_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
        	$scope.hideOverlay = function() { 
        		$scope.submitModal.hide();        		 
        		$state.go('base.homepage', {  	    			
                }, {
                    reload: true
                });
        	};
        	
        	$scope.clickToUploadRAQ = function(id) {
            	CommonUtil.displayConfirmBox($translate.instant('CONF_UPLOAD_RAQ_TITLE'), $translate.instant('CONF_UPLOAD_RAQ'), $translate.instant('BTN_OK'), function() {
            		$scope.uploadRAQ(id);
            	}, $translate.instant('BTN_CANCEL'), function() {
            		// Dismiss confirm box
            	});
        	};

            $scope.uploadRAQ = function(id) { 
           		var pdfdata = $scope.storedRAQResult[id].generatedPdf;
   	            var accountName=$scope.storedRAQResult[id].accountName;
   				var accountNumber=$scope.storedRAQResult[id].accountNumber;
   				var customerName =$scope.storedRAQResult[id].customerName;
   				$scope.deleteId=$scope.storedRAQResult[id].id;
   				LogUtil.logInfo('HomePageCtrl -> uploadRAQ : attempt to uploadRAQPDFFiles again');
   				var uploadRAQPDFSuccessCallback = function(data) { 
   	            	LogUtil.logInfo('HomePageCtrl -> uploadRAQ -> uploadRAQPDFSuccessCallback' );	            	
   	            	$scope.deleteRAQOnly($scope.deleteId);
   	            	$scope.submitModal.show();
   	            };
   	            var uploadRAQPDFFailureCallback = function(data) {
   	  		    	LogUtil.logInfo('HomePageCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : do nothing ' );	
		            AppState.isRAQReminderShown = true;
   	  		    	if (data && data.responseJSON && data.responseJSON.errorCode) {
                        var errorCode = data.responseJSON.errorCode;
                        LogUtil.logError('HomePageCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - Error returned from ZPB - ' + errorCode);
                        var errorMsg = $translate.instant('ERR_SUBMIT_RAQ_ZPB_FAILURE')+'-'+errorCode;
                        WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'), errorMsg, [{text: $translate.instant('BTN_OK'), handler: function() {
        	            	//Dismiss alert box
        	            }}]);
                    }else{
                    	WL.Device.getNetworkInfo(function(networkInfo) {
                     		var errorMsg = '';
        					AppState.isNetworkConnected = networkInfo.isNetworkConnected;
        					LogUtil.logDebug('HomePageCtrl -> Network Info : '+networkInfo.isNetworkConnected);
        			  		if (networkInfo.isNetworkConnected === 'false') {
        			  			LogUtil.logError('HomePageCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - No internet connection');
        			  			errorMsg = $translate.instant('ERR_SUBMIT_RAQ_INTERNET_CONNECTION');
        			  		}else{
        			  			LogUtil.logError('HomePageCtrl -> uploadRAQ -> uploadRAQPDFFailureCallback : Submit RAQ failure - MobileFirst server connection failure');
        			  			errorMsg = $translate.instant('ERR_SUBMIT_RAQ_MFP_CONNECTION_FAILURE');
        			  		}
        			  		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'), errorMsg, [{text: $translate.instant('BTN_OK'), handler: function() {
            	               	//Dismiss alert box
            	            }}]);
           			  	});
                    }    
    	        };
            	RAQService.uploadRAQPDFFiles(pdfdata,customerName, accountName, accountNumber,uploadRAQPDFSuccessCallback,uploadRAQPDFFailureCallback);
        	};
        	 $scope.createNewRAQ = function() { 
        		var tmp=AppState.tmpRAQResult.rmRINumber;
        		AppState.tmpRAQResult={};
 	            AppState.tmpRAQResult.rmRINumber=tmp;
 	            RAQService.getRAQConfig(this.getRAQConfigSuccessCallback,this.getRAQConfigFailureCallback);
 	            busyIndicator.show();
         	};
         	
         	$scope.getRAQConfigSuccessCallback = function(data) {
        		LogUtil.logDebug('HomePageCtrl -> getRAQConfigSuccessCallback ');
        		$scope.getRAQPDFTemplates();
    		}; 
    		$scope.getRAQConfigFailureCallback = function(data) {
    			LogUtil.logError('HomePageCtrl -> getRAQConfigFailureCallback ');
    			busyIndicator.hide();
    			var errorCode = '';
                var errorMsg = '';
                var errorTitle = '';
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE');
                    errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE') + errorCode;
                    LogUtil.logError('HomePageCtrl -> getRAQConfigFailureCallback : errorCode - ' + errorCode);
                    CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure  - Error returned from ZPB',errorTitle,errorMsg,false);
                    busyIndicator.hide();
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('HomePageCtrl -> getRAQConfigFailureCallback : Network Info - '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION');
			  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - No internet connection',errorTitle,errorMsg,false);
			  			}else{
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE');
			  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
			  			}
		                busyIndicator.hide();
			  		});
                }
    			
            };
            $scope.getRAQPDFTemplates = function (){
            	RAQService.getRAQPDFTemplates(this.getRAQPDFTemplatesSuccessCallback,this.getRAQPDFTemplatesFailureCallback);
            };
            $scope.getRAQPDFTemplatesSuccessCallback = function(data) {
            	busyIndicator.hide();
            	$state.go('base.raq_select_customer_type', {    	    			
                 }, {
                     reload: true
                 });
            	LogUtil.logDebug('HomePageCtrl -> getRAQPDFTemplatesSuccessCallback ');
    		}; 
    		$scope.getRAQPDFTemplatesFailureCallback = function(data) {
    			busyIndicator.hide();
    			LogUtil.logError('HomePageCtrl -> getRAQPDFTemplatesFailureCallback ');
    			var errorCode = '';
                var errorMsg = '';
                var errorTitle = '';
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE');
                    errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE') + errorCode;
                    LogUtil.logError('HomePageCtrl -> getRAQPDFTemplatesFailureCallback : errorCode - ' + errorCode);
                    CommonUtil.handleAppError('Retrieve RAQ PDF Templates failure  - Error returned from ZPB',errorTitle,errorMsg,false);
                    busyIndicator.hide();
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('HomePageCtrl -> getRAQPDFTemplatesFailureCallback : Network Info - '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION');
			  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates and scoring matrix failure - No internet connection',errorTitle,errorMsg,false);
			  			}else{
			  				errorTitle = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE');
			  				errorMsg = $translate.instant('ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE');
			  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates and scoring matrix failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
			  			}
		                busyIndicator.hide();
			  		});
                }
            };
            
         	$scope.numberOfAccessibleModules = function() {
         		var number = FunctionActivator.numberOfAccessibleModules();
         		LogUtil.logInfo('HomePageCtrl -> numberOfAccessibleModules: ' + number);
         		return number;
         	};
         	$scope.moduleActivation = function() {
         		LogUtil.logInfo('HomePageCtrl -> moduleActivation');
         		
         		$scope.numberOfModules = $scope.numberOfAccessibleModules();
         		
         		$scope.isAccessibleToRAQ = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_RAQ);
         		$scope.isAccessibleToCallReport = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CALL_REPT);
             	$scope.isAccessibleToTargetPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_TARGET_PROF);
    			$scope.isAccessibleToReviewPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CUST_PROF);
    			$scope.isAccessibleToFNPortfolioCreation = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORFOLIO_CREATION);
         	};
         	$scope.getColumnClassForModule = function() {
         		var number = $scope.numberOfModules;
         		var className = "col";
         		if (number === 4) {
         			className += " col-25";
         		} else if (number === 3) {
         			className += " col-33";
         		} else if (number === 2) {
         			className += " col-50";
         		} 
         		return className;
         	};
         	$scope.isPortfolioCreationAllowed = function() {
         		return ($scope.storedPortfolios.length < AppConfig.systemParam.configMap.get('i_pfDlLimit') && $scope.isAccessibleToFNPortfolioCreation);
         	};
         	
         	$scope.init = function() {
         		$scope.loadStoredRAQ();
                $scope.loadStoredPortfolio();
                $scope.loadStoredTargetPortfolio();
                $scope.loadStoredCallReport();
                $scope.moduleActivation(); 
                AppConfig.enableLogSender = true;
         	};
         	
         	$scope.init();          
            
        }
    ]);
});