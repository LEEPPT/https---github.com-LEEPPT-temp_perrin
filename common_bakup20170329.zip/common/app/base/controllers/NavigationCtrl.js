define([
  'app/app',
  'js/appState',
  'js/Util/DataPersister',
  'js/appConfig',
  'js/Util/LogUtil',
  'js/Util/CommonUtil',
  'js/Util/Validation',
  'js/constants',
  'js/Util/FunctionActivator'
], function (app, AppState, DataPersister, AppConfig, LogUtil, CommonUtil, Validation, Constants, FunctionActivator) {
  'use strict';

  app.controller('NavigationCtrl', [
    '$scope',
    '$rootScope',
    '$ionicHistory',
    '$ionicSideMenuDelegate',
    '$translate',
    '$state',
    function ($scope, $rootScope, $ionicHistory,$ionicSideMenuDelegate,$translate,$state) {
    	$scope.currentLangCode = AppState.currentLangCode||"en";

    	$scope.isAccessibleToRAQ = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_RAQ);
    	$scope.isAccessibleToCallReport = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CALL_REPT);
    	$scope.isAccessibleToTargetPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_TARGET_PROF);
    	$scope.isAccessibleToReviewPortfolio = FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CUST_PROF);
   	 
    	$scope.languageSwitchOpened = false;
    	$scope.navGoBack = function() {
    		var currentState = $state.current.name;
    		var targetBackState = AppConfig.backFlowConfig[currentState];
    		var goBack = true;
    		if (currentState=="base.raq_result"){
    			goBack = false;
    			CommonUtil.displayConfirmBox($translate.instant("CONF_RESTART_RAQ_TITLE"), $translate.instant("CONF_RESTART_RAQ"), $translate.instant("BTN_OK"), function() {
    				AppState.tmpRAQResult={};
    				$state.go('base.raq_select_customer_type', {  	    			
                    }, {
                        reload: true
                    });
    			}, $translate.instant("BTN_CANCEL"), function(){
    				// dismiss the alert box
    			});
    		} else if (currentState=="base.raq_customer_signature"||currentState=="base.raq_rm_signature"||currentState=="base.raq_customerwitness_signature"||currentState=="base.raq_rmwitness_signature"){
        		goBack = false;
        		CommonUtil.displayConfirmBox($translate.instant("CONF_SIGNATURE_BACK_TITLE"), $translate.instant("CONF_SIGNATURE_BACK"), $translate.instant("BTN_OK"), function() {
        			if(!Validation.isEmpty(targetBackState)){
        				var param = {
        	                    generalInfo: angular.toJson(AppState.tmpRAQResult.generalInfo),
        	                    customerInfo: angular.toJson(AppState.tmpRAQResult.customerInfo)
        	              };
    	    			$state.go(targetBackState, param, {reload: true});
    	    		} else{
    	    			$ionicHistory.goBack();
    	    		}
    			}, $translate.instant("BTN_CANCEL"), function(){
    				// dismiss the alert box
    			});
    		} else if (targetBackState=="base.raq_select_customer_type"){
    			AppState.tmpRAQResult = {};   			
    		} else if (currentState == "base.portfolio_overview"){
    			goBack = false;
    			CommonUtil.displayConfirmBox($translate.instant("CONF_NAVIGATE_OUT_PORTFOLIO_TITLE"), $translate.instant("CONF_NAVIGATE_OUT_PORTFOLIO"), $translate.instant("BTN_OK"), function() {
    				AppState.tmpRAQResult={};
    				$state.go('base.homepage', {  	    			
                    }, {
                        reload: true
                    });
    			}, $translate.instant("BTN_CANCEL"), function(){
    				// dismiss the alert box
    			});
    		} else if (currentState == "base.call_report_creation"){
    			goBack = false;
    			CommonUtil.displayConfirmBox($translate.instant("CONF_NAVIGATE_OUT_CALL_REPORT_TITLE"), $translate.instant("CONF_NAVIGATE_OUT_CALL_REPORT"), $translate.instant("BTN_OK"), function() {
    				$state.go('base.homepage', {  	    			
                    }, {
                        reload: true
                    });
    			}, $translate.instant("BTN_CANCEL"), function(){
    				// dismiss the alert box
    			});
    			
    		}
    		
            LogUtil.logDebug("NavigationCtrl -> navGoBack : goBack: " + goBack + ", targetBackState: " + targetBackState);

    		if (goBack) {
	    		if(!Validation.isEmpty(targetBackState)){
	    			$state.go(targetBackState, {}, {reload: true});
	    		} else{
	    			$ionicHistory.goBack();
	    		}
    		}
    	};
    	$scope.toggleLeft = function() {
    	    $ionicSideMenuDelegate.toggleLeft();
    	  };
    	$scope.toggleRight = function() {
      	    $ionicSideMenuDelegate.toggleRight();
      	  };
      	$scope.OpenLanguageSwitch = function (evt){
      		if ($scope.languageSwitchOpened) $scope.languageSwitchOpened = false;
      		else $scope.languageSwitchOpened = true;
      	};
      	$scope.SwitchLanguage = function(lang,evt){
      		var clickTriggerElement = $(evt.target);
      		if (clickTriggerElement.hasClass('lang-selected')) return;
      		
      		$translate.use(lang);
    		$state.go($state.current, {}, {reload: true});
    		$ionicSideMenuDelegate.toggleRight();
    		AppState.currentLangCode = lang;
    		$scope.currentLangCode = lang;
    		DataPersister.setAppDataByNameValue('userPreferredLanguage',lang);
    		$scope.languageSwitchOpened = false;
            busyIndicator = new WL.BusyIndicator(null, {text : $translate.instant("BUSY_INDICATOR")});    		
    	};
    	$scope.isShowBackButton = function() {
    		var currentState = $state.current.name;
    		if(AppConfig.disableBackButtonConfig.indexOf(currentState)>=0){
    			return false;
    		}else{
    			return true;
    		}
    	};    	 
    	$scope.pageFunctionality = function() {
    		var state = $state.current.name;
    		 
    		if (state === 'base.target_portfolio') {
    			//targetPortfolio Controller will change this value
    			return $rootScope.pageFunctionality;
    		} else if (state.substr(5,4) === "raq_") {
    			$rootScope.pageFunctionality = "raq";
    			return $rootScope.pageFunctionality;
    		} else if (state.substr(5,11) === "call_report"){
    			$rootScope.pageFunctionality = "callReport";
    			return $rootScope.pageFunctionality;
    		} else {
    			$rootScope.pageFunctionality = AppConfig.stateFunctionality[state];
    		}
    		
    		return $rootScope.pageFunctionality;
    	};
    }
  ]);
});