define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService'
], function(LogUtil, app, AppState, Constants, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQDeclarationCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $ionicScrollDelegate {service} for control scroll views
     * @param $state {service} for store data in appState
     * @param $translate {service} i18n handling
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ declaration display and confirmation Page
     */
    app.controller('RAQDeclarationCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$ionicScrollDelegate',
        '$state',
        '$translate',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $ionicScrollDelegate, $state,$translate,RAQService) {
        	/**
    	     * Initialization function of RAQDeclarationCtrl
    	     * @memberof RAQDeclarationCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from AppState,
    		 * get parameters from source page: RAQResultCtrl or RAQResultOverrideCtrl,
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQDeclarationCtrl -> init");

        		$scope.isbottom = 0;
        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                $scope.isResultOverridden = $scope.customerInfo.isResultOverridden;
                $scope.customerInput = angular.fromJson($scope.customerInfo.customerInput);
                $scope.customerName = $scope.customerInput.customerName;
                $scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);
                $scope.riskToleranceLevel = Number($scope.customerInfo.riskToleranceLevel);
                if($scope.isResultOverridden==1){
               	 	$scope.newRiskToleranceLevel = Number($scope.customerInfo.newRiskToleranceLevel);
                    $scope.newLevel = $scope.levelList[$scope.newRiskToleranceLevel-1].level;
                	$scope.newType = $scope.levelList[$scope.newRiskToleranceLevel-1].type;
                }
                $scope.getOptions();
        	};
            
            /**
    	     * get customer choices of options in declaration page
    	     * @memberof RAQDeclarationCtrl
    	     * @function getOptions
    		 * @description check if there has temporary data of theses options first,
    		 *  if yes, get customer options from temporary storage
    		 *  if not, initialize the variables, 
    	     */
        	$scope.getOptions=function(){
        		 if (AppState.tmpRAQResult.isPhotoCopyRecieved) {
                     $scope.notcareSelected = AppState.tmpRAQResult.isPhotoCopyRecieved;
                 } else {
                     $scope.notcareSelected = 0;
                 }
                 if (AppState.tmpRAQResult.declineSelected) {
                     $scope.declineSelected = AppState.tmpRAQResult.declineSelected;
                 } else {
                     $scope.declineSelected = 0;
                 }

                 if (AppState.tmpRAQResult.agreeSelected) {
                     $scope.agreeSelected = AppState.tmpRAQResult.agreeSelected;
                 } else {
                     $scope.agreeSelected = 0;
                 }
        	};

            /**
    	     * get levelList content according to language change
    	     * @memberof RAQDeclarationCtrl
    	     * @function watch currentLangCode
    		 * @description check if language changes, then get levelList content according to language 
    	     */
            $scope.$watch('AppState.currentLangCode', function() {
                if ($scope.customerInfo.newRiskToleranceLevel) {
                	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);               	
                	$scope.newLevel = $scope.levelList[$scope.newRiskToleranceLevel-1].level;
                	$scope.newType = $scope.levelList[$scope.newRiskToleranceLevel-1].type;
                }
            }, true);
            
            /**
    	     * store the results if customer click select box of decline declaration content
    	     * @memberof RAQDeclarationCtrl
    	     * @function declinestatus
    		 * @description once select box is selected, the value reverses, store the result
    	     */
            $scope.declinestatus = function() {
                if ($scope.declineSelected === 0){
                    $scope.declineSelected = 1;
                }else{ 
                	$scope.declineSelected = 0;
                }
            };
            
            /**
    	     * store the results if customer click select box of agree declaration content
    	     * @memberof RAQDeclarationCtrl
    	     * @function agreestatus
    		 * @description once select box is selected, the value reverses, store the results 
    	     */
            $scope.agreestatus = function() {
                if ($scope.agreeSelected === 0){
                    $scope.agreeSelected = 1;
                }else {
                	$scope.agreeSelected = 0;
                }
            };
            
            /**
    	     * store the results if customer click select box of second option which acknowledge receipt of a photocopy 
    	     * @memberof RAQDeclarationCtrl
    	     * @function notcarestatus
    		 * @description once select box is selected, the value reverses 
    	     */
            $scope.notcarestatus = function() {
                if ($scope.notcareSelected === 0){
                    $scope.notcareSelected = 1;
                }else {
                	$scope.notcareSelected = 0;
                }
            };
            
            /**
    	     * Event trigger by scroll down the page
    	     * @memberof RAQDeclarationCtrl
    	     * @function checkScroll
    		 * @description calculate the distance to top, then justify whether scroll down to the bottom 
    	     */
            $scope.checkScroll = function() {
                var distance_top = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollPosition().top;
                var max_Scrollheight = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollView().__maxScrollTop;
                if (distance_top >= max_Scrollheight) {
                    $scope.isbottom = 1;
                }
                $scope.$apply();
            };
            
            /**
    	     * Event trigger by click confirm button
    	     * @memberof RAQDeclarationCtrl
    	     * @function goDisclaimer
    		 * @description passing parameters and direct to Disclaimer page 
    	     */
            $scope.goDisclaimer = function() {
            	if($scope.declineSelected === 0 && $scope.agreeSelected === 0){
            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_ACKNOWLEDGEMENT_NOT_CHECKED'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
            	}else {
	                var data = AppState.tmpRAQResult;
	                data.isPhotoCopyRecieved = $scope.notcareSelected;
	                data.declineSelected = $scope.declineSelected;
	                data.agreeSelected = $scope.agreeSelected;
	                AppState.tmpRAQResult = data;
	                LogUtil.logDebug($scope.notcareSelected);
	                $scope.customerInfo.isPhotoCopyRecieved = $scope.notcareSelected;
	                var param = {
	                    generalInfo: angular.toJson($scope.generalInfo),
	                    customerInfo: angular.toJson($scope.customerInfo)
	                };
	                $state.go('base.raq_disclaimer', param, {
	                    reload: true
	                });
            	}
            };
            $scope.init();
        }
    ]);
});