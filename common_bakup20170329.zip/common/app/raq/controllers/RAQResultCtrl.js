define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService'
], function(LogUtil, app, AppState, Constants, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQResultCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param $translate {service} i18n handling
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ result display Page
     */
    app.controller('RAQResultCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $state, $translate, RAQService) {
        	/**
    	     * Initialization function of RAQResultCtrl
    	     * @memberof RAQResultCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQReviewCtrl
    	     */
        	$scope.init= function(){
    			LogUtil.logInfo("RAQResultCtrl -> init");
        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                $scope.cumulativeScore = $scope.customerInfo.cumulativeScore;
                $scope.riskToleranceLevel = Number($scope.customerInfo.riskToleranceLevel);
                $scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);   
                if ($scope.customerInfo.flagLevelChg == true) {
                	LogUtil.logDebug("RAQReviewCtrl -> init: show risk tolerance level changed by system message");                   
                	var causeChgQuestions=$scope.customerInfo.causeChgQuestions;
                	var causeChgChoice=$scope.customerInfo.causeChgChoice;
                	var invalidRiskToleranceLevel= $scope.customerInfo.invalidRiskToleranceLevel;
                	var invalidRiskToleranceType=$scope.levelList[invalidRiskToleranceLevel-1]?$scope.levelList[invalidRiskToleranceLevel-1].type:"";
                	var riskToleranceLevel= $scope.riskToleranceLevel;
                	var riskToleranceType= $scope.levelList[riskToleranceLevel-1]?$scope.levelList[riskToleranceLevel-1].type:"";
                	var causeChgQuestionId = '';
                	for (var i = 0; i < causeChgQuestions.length; i++){
                		if(i == 0) {
                			causeChgQuestionId = causeChgQuestions[0];
                		}else{
                			causeChgQuestionId = causeChgQuestionId + ' ' + $translate.instant('OR') + ' '+causeChgQuestions[i];
                		}
                	}
                	var chgMeg = $translate.instant('RAQ_RESULT_LEVEL_CHG');
                	var chgMeg = chgMeg.replace("@cumulativeScore@",$scope.cumulativeScore);
                	var chgMeg = chgMeg.replace("@invalidRiskToleranceLevel@",invalidRiskToleranceLevel);
                	var chgMeg = chgMeg.replace("@invalidRiskToleranceType@",invalidRiskToleranceType);
                	var chgMeg = chgMeg.replace("@causeChgQuestion@",causeChgQuestionId);
                	var chgMeg = chgMeg.replace("@causeChgChoice@",causeChgChoice);
                	var chgMeg = chgMeg.replace("@riskToleranceLevel@",riskToleranceLevel);
                	var chgMeg = chgMeg.replace("@riskToleranceType@",riskToleranceType);
                	$scope.levelChgMeg=chgMeg;
                	//show level message
                	WL.SimpleDialog.show($translate.instant('RAQ_RESULT_LEVEL_CHG_TITLE'), $scope.levelChgMeg, [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
                }
        	};
                    
        	 /**
    	     * get levelList content according to language change
    	     * @memberof RAQResultCtrl
    	     * @function watch currentLangCode
    		 * @description check if language changes, then get levelList content according to language 
    	     */
            $scope.$watch('AppState.currentLangCode', function() {
            	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);
            	var riskToleranceLevel = $scope.riskToleranceLevel;
            	$scope.level = $scope.levelList[riskToleranceLevel-1]?$scope.levelList[riskToleranceLevel-1].level:"";
            	$scope.type = $scope.levelList[riskToleranceLevel-1]?$scope.levelList[riskToleranceLevel-1].type:"";
                $scope.disc = $scope.levelList[riskToleranceLevel-1]?$scope.levelList[riskToleranceLevel-1].description:"";
                $scope.profile = $scope.levelList[riskToleranceLevel-1]?$scope.levelList[riskToleranceLevel-1].riskProfile:"";
            }, true);

            /**
    	     * Event trigger by click deline button
    	     * @memberof RAQResultCtrl
    	     * @function goOverride 
    		 * @description passing parameters and direct to result override page
    	     */
            $scope.goOverride = function() {
                if (AppState.tmpRAQResult.isPhotoCopyRecieved) {
                    AppState.tmpRAQResult.isPhotoCopyRecieved = 0;
                }

                if (AppState.tmpRAQResult.declineSelected) {
                    AppState.tmpRAQResult.declineSelected = 0;
                }

                if (AppState.tmpRAQResult.agreeSelected) {
                    AppState.tmpRAQResult.agreeSelected = 0;
                }

                var data = AppState.tmpRAQResult;
                data.isResultOverridden = 1;
                data.cumulativeScore = $scope.customerInfo.cumulativeScore;
                AppState.tmpRAQResult = data;
                $scope.customerInfo.isResultOverridden = 1;
                var param = {
                    generalInfo: angular.toJson($scope.generalInfo),
                    customerInfo: angular.toJson($scope.customerInfo)
                };
                $state.go('base.raq_result_override', param, {
                    reload: true
                });
            };
            
            /**
    	     * Event trigger by click agree button
    	     * @memberof RAQResultCtrl
    	     * @function goDeclaration 
    		 * @description passing parameters and direct to Declaration page
    	     */
            $scope.goDeclaration = function() {
                if (AppState.tmpRAQResult.isPhotoCopyRecieved) {
                    AppState.tmpRAQResult.isPhotoCopyRecieved = 0;
                }

                if (AppState.tmpRAQResult.declineSelected) {
                    AppState.tmpRAQResult.declineSelected = 0;
                }

                if (AppState.tmpRAQResult.agreeSelected) {
                    AppState.tmpRAQResult.agreeSelected = 0;
                }
                var data = AppState.tmpRAQResult;
                data.isResultOverridden = 0;
                data.cumulativeScore = $scope.customerInfo.cumulativeScore;
                AppState.tmpRAQResult = data;

                $scope.customerInfo.isResultOverridden = 0;
                var param = {
                    generalInfo: angular.toJson($scope.generalInfo),
                    customerInfo: angular.toJson($scope.customerInfo)
                };
                $state.go('base.raq_declaration', param, {
                    reload: true
                });
            };
            $scope.init();
        }
    ]);
});