define(['js/Util/LogUtil',
    'app/app',
    'js/Util/Validation',
    'js/appState',
    'app/raq/services/RAQService'
], function(LogUtil, app, Validation, AppState, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQCustomerInputCtrl
     * @param $scope {service} controller scope
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @param $translate {service} i18n handling
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @description 
     *   Controller for RAQ CustomerInput  Page
     */
    app.controller('RAQCustomerInputCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $state, $translate, RAQService) {
        	/**
    	     * Initialization function of RAQCustomerInputCtrl
    	     * @memberof RAQCustomerInputCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQSelectTypeCtrl
    	     */
        	$scope.init = function() {
    			LogUtil.logInfo("RAQCustomerInputCtrl -> init");

        		$scope.customerType = $stateParams.customer_type;
                $scope.selectedCustomerType = $translate.instant("RAQ_CT_" + $scope.customerType);
                $scope.miscList=AppState.raqConfig.miscList;  
                $scope.raqVersion = $scope.miscList.get($scope.customerType).version;
                $scope.hasError = true;
                $scope.hasEmpty = true;    
                // Pre-fill customer name, account name and account number when it is back
                if (AppState.tmpRAQResult.customerName) {
                    $scope.customerInput = {
                        customerName: AppState.tmpRAQResult.customerName,
                        accountName: AppState.tmpRAQResult.accountName,
                        accountNumber: AppState.tmpRAQResult.accountNumber,
                    };
                } else {
                    $scope.customerInput = angular.fromJson($stateParams.customerInput);
                }                
                // Prepare the data brought to Question Page - Set the initial question ID and selected answers to Question Page
                $scope.modifyID = 0;
                $scope.userChoices = [];
        	};
            
        	/**
    	     * get customerInput whenever its content changes
    	     * @memberof RAQCustomerInputCtrl
    	     * @function watch customerInput changes
    		 * @description check if customerInput changes, validation on input box to see if they are all empty, 
    		 * if not, submit button will be able to click 
    	     */
            // Validation on input box            
            $scope.$watch('customerInput', function() {
                if (Validation.isEmpty($scope.customerInput.customerName) && Validation.isEmpty($scope.customerInput.accountName)) {
                    $scope.hasEmpty = true;
                } else {
                    $scope.hasEmpty = false;                                     
                }
                var data = AppState.tmpRAQResult;
                data.customerName = $scope.customerInput.customerName;
                data.accountName = $scope.customerInput.accountName;
                data.accountNumber = $scope.customerInput.accountNumber;
                AppState.tmpRAQResult=data;                     
            }, true);
            
       	 	/**
    	     * Event trigger  When "Submit" button is clicked
    	     * @memberof RAQCustomerInputCtrl
    	     * @function goQuestionnaire
    		 * @description passing parameters and direct to Questionnaire Page
    	     */           
            $scope.goQuestionnaire = function() {      	
            	if (Validation.isEmpty($scope.customerInput.customerName)){
                	$scope.hasError = true;
                	$scope.errorMsg = $translate.instant('ERR_CUSTOMER_NAME_EMPTY');
                }else if(Validation.isEmpty($scope.customerInput.accountName)){
                	$scope.hasError = true; 
                	$scope.errorMsg = $translate.instant('ERR_ACCOUNT_NAME_EMPTY');
                }else if($scope.customerInput.accountNumber !== '' && isNaN($scope.customerInput.accountNumber)){
                	$scope.hasError = true; 
                	$scope.errorMsg = $translate.instant('ERR_ACCOUNT_NUMBER_INVALID_FORMAT');
                }else if($scope.customerInput.accountNumber !== '' && $scope.customerInput.accountNumber.length != 8){
                	$scope.hasError = true; 
                	$scope.errorMsg = $translate.instant('ERR_ACCOUNT_NUMBER_INVALID_LENGTH');
            	}else {
                    $scope.hasError = false; 
                    $scope.errorMsg = '';                    
                }

                var data = AppState.tmpRAQResult;
                data.customerName = $scope.customerInput.customerName;
                data.accountName = $scope.customerInput.accountName;
                data.accountNumber = $scope.customerInput.accountNumber;                
                AppState.tmpRAQResult = data;                
                if ($scope.hasError === false) {
                    var param = {
                        customerType: $scope.customerType,
                        customerInput: angular.toJson($scope.customerInput),
                        initialID: $scope.modifyID,
                        userChoices: $scope.userChoices
                    };
                    $state.go('base.raq_questions', param, {
                        reload: true
                    });
                }
            };
            $scope.init();
        }
    ]);
});