define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService'
], function(LogUtil, app, AppState,Constants, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQResultOverrideCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param $ionicScrollDelegate {service} for control scroll views 
     * @param $translate {service} i18n handling
     * @param RAQService {service} Service Class for handling business logic of RAQ  
     * @description 
     *   Controller for RAQ result override Page when the result is declined
     */
    app.controller('RAQResultOverrideCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$ionicScrollDelegate',
        '$translate',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $state, $ionicScrollDelegate, $translate, RAQService) {
        	/**
    	     * Initialization function of RAQResultOverrideCtrl
    	     * @memberof RAQResultOverrideCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQResultCtrl
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQResultOverrideCtrl -> init");

        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                $scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);
                $scope.riskToleranceLevel = Number($scope.customerInfo.riskToleranceLevel);
                $scope.isbottom = 0;
                if (AppState.tmpRAQResult.levelChoice || AppState.tmpRAQResult.levelChoice === 0) {
                    $scope.levelChoice = {
                        data: null
                    };
                    $scope.levelChoice.data = AppState.tmpRAQResult.levelChoice;
                } else {
                    $scope.levelChoice = {
                        data: null
                    };
                }
        	};
            
            /**
    	     * get levelList content according to language change
    	     * @memberof RAQResultOverrideCtrl
    	     * @function watch currentLangCode
    		 * @description check if language changes, then get levelList content according to language 
    	     */
            $scope.$watch('AppState.currentLangCode', function() {
            	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);
            }, true);
            
            
            /**
    	     * Event trigger by scroll down the page
    	     * @memberof RAQResultOverrideCtrl
    	     * @function checkScroll
    		 * @description calculate the distance to top, then justify whether scroll down to the bottom 
    	     */
            $scope.checkScroll = function() {
                var distance_top = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollPosition().top;
                var max_Scrollheight = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollView().__maxScrollTop;
                if (distance_top >= max_Scrollheight) {
                    $scope.isbottom = 1;
                }
                $scope.$apply();
            };
            
            /**
    	     * Event trigger by clicking submit button
    	     * @memberof RAQResultOverrideCtrl
    	     * @function goDeclaration
    		 * @description passing parameters and direct to Declaration page 
    	     */
            $scope.goDeclaration = function() {
            	if($scope.levelChoice.data ===null){
            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_NO_RISK_TOLERANCE_LEVEL_SELECTED'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
            	}else {
            		
	                var data = AppState.tmpRAQResult;
	                data.levelChoice = $scope.levelChoice.data;
	                $scope.newRiskToleranceLevel = $scope.levelList[parseInt($scope.levelChoice.data)].level;	 
	                data.newRiskToleranceLevel=$scope.newRiskToleranceLevel;
	                AppState.tmpRAQResult = data;
	                $scope.customerInfo.newRiskToleranceLevel =  $scope.newRiskToleranceLevel;
	                
	                var param = {
	                    generalInfo: angular.toJson($scope.generalInfo),
	                    customerInfo: angular.toJson($scope.customerInfo)
	                };
	                $state.go('base.raq_declaration', param, {
	                    reload: true
	                });
            	}
            };
            $scope.init();

        }
    ]);
});