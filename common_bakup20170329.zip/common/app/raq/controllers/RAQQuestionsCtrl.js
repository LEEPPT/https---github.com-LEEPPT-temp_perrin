define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService'
], function(LogUtil, app, AppState, Constants, RAQService) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQQuestionsCtrl
     * @param $scope {service} controller scope
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @param $translate {service} i18n handling
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @description 
     *   Controller for RAQ conducting Questions  Page
     */
    app.controller('RAQQuestionsCtrl', [
        '$scope',
        '$translate',
        '$stateParams',
        '$state',
        '$ionicModal',
        'RAQService',
        function($scope, $translate, $stateParams, $state, $ionicModal, RAQService) {
        	/**
    	     * Initialization function of RAQQuestionsCtrl
    	     * @memberof RAQQuestionsCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQCustomerInputCtrl
    	     */
        	$scope.init = function(){
    			LogUtil.logInfo("RAQQuestionsCtrl -> init");
        		$scope.customerType = $stateParams.customerType;
                $scope.miscList=AppState.raqConfig.miscList;  
                $scope.customerInput = angular.fromJson($stateParams.customerInput);
                $scope.currentQuestion = Number(angular.fromJson($stateParams.initialID));
                $scope.questionnameList = [];
                $scope.isRemarksShown = [];
                if ($scope.userChoices != null) {
                    $scope.userChoices = angular.fromJson($stateParams.userChoices.split(','));
                } else if (AppState.tmpRAQResult.userChoices) {
                    $scope.userChoices = AppState.tmpRAQResult.userChoices;
                    $scope.customerType = AppState.tmpRAQResult.customerType;
                } else {
                    $scope.customerType = $stateParams.customerType;
                    $scope.userChoices = [];
                    for (var i = 0; i < $scope.question_length; i++) {
                        $scope.userChoices[i] = -1;
                    }
                }
                $scope.getQuestionData();                
        	};
        	
            /**
    	     * get questionData according to raqVersion 
    	     * @memberof RAQQuestionsCtrl
    	     * @function getQuestionData
    		 * @description check if raqVersion is the same as in system parameter, then get questionData from AppState 
    	     */
        	$scope.getQuestionData = function(){
    			LogUtil.logInfo("RAQQuestionsCtrl -> getQuestionData");
        		$scope.raqVersion = $scope.miscList.get($scope.customerType).version;               
                $scope.questionData = AppState.raqConfig.contentList.get(AppState.currentLangCode+'_'+$scope.customerType.toUpperCase()).questionList;                
                $scope.question_length = $scope.questionData.length;
                for (var i = 0; i < $scope.questionData.length; i++) {
                    if ($scope.questionData[i].subQuestionID === null) {
                        $scope.questionnameList[i] = $scope.questionData[i].questionID;
                    } else {
                        $scope.questionnameList[i] = $scope.questionData[i].questionID + $scope.questionData[i].subQuestionID;
                    }
                    if ($scope.questionData[i].remarks && $scope.questionData[i].remarks !== null && $scope.questionData[i].remarks !== "") {
                        $scope.isRemarksShown[i] = true;
                        continue;
                    }
                    if ($scope.questionData[i].optionList) {
                        for (var j = 0; j < $scope.questionData[i].optionList.length; j++) {
                            if ($scope.questionData[i].optionList[j].remarks) {
                                $scope.isRemarksShown[i] = true;
                                break;
                            }
                        }
                    }
                }
        	};
        	
        	/**
    	     * watch changes of userChoices
    	     * @memberof RAQQuestionsCtrl
    	     * @function watch userChoices 
    		 * @description check if choices changes, if has new answer or answers change, update the stored data and 
    		 * calculate the quantity of questions that not answered
    	     */
            $scope.$watch('userChoices', function() {
                $scope.questionLeft = $scope.question_length;
                for (var i = 0; i < $scope.question_length; i++) {
                    if ($scope.userChoices[i] >= 0) $scope.questionLeft--;
                }
                var data = AppState.tmpRAQResult;
                data.userChoices = $scope.userChoices;
                AppState.tmpRAQResult=data;
            }, true);
            
            /**
    	     * get questionData content according to currentLangCode
    	     * @memberof RAQQuestionsCtrl
    	     * @function watch currentLangCode
    		 * @description check if language changes, then get questionData content according to language 
    	     */
            $scope.$watch('AppState.currentLangCode', function() {                
            	$scope.questionData = AppState.raqConfig.contentList.get(AppState.currentLangCode+'_'+$scope.customerType.toUpperCase()).questionList;                
            }, true);

            $scope.changeQuestion = function(id) {
                $scope.currentQuestion = id;
            };
            $scope.slideHasChanged = function(id) {
                $scope.currentQuestion = id;
            };
            
            /**
    	     * Event trigger when click question ID list or add an answer
    	     * @memberof RAQQuestionsCtrl
    	     * @function btnClassName
    		 * @description justify if the question has been chosen or answered, 
    		 * then modify color style change of question ID in question list  
    	     */
            $scope.btnClassName = function(id) {
                var className = 'no-answer';
                if ($scope.currentQuestion == id) {
                    if ($scope.userChoices[id] >= 0) className = 'active-has-answer';
                    else className = 'active-no-answer';
                } else {
                    if ($scope.userChoices[id] >= 0) className = 'has-answer';
                    else className = 'no-answer';
                }
                return className;
            };
            
            /**
    	     * get question remarks template 
    	     * @memberof RAQQuestionsCtrl
    	     * @function fromTemplateUrl
    		 * @description read template file for remarks information display according to url of Template
    	     */
            $ionicModal.fromTemplateUrl('./app/raq/templates/raq_questions_remarks.html', {
                scope: $scope
            }).then(function(modal) {
                $scope.remarksModal = modal;
            });
            
            /**
    	     * Event trigger when click remarks button of questions
    	     * @memberof RAQQuestionsCtrl
    	     * @function showRemarks
    		 * @description show remark modal and display remark data on it
    	     */
            $scope.showRemarks = function(id) {
    			LogUtil.logInfo("RAQQuestionsCtrl -> showRemarks - id: "+id);
                var remarks = "";
                if ($scope.questionData[id].remarks) {
                    remarks = $scope.questionData[id].remarks;
                }
                if ($scope.questionData[id].optionList) {
                    for (var i = 0; i < $scope.questionData[id].optionList.length; i++) {
                        var option_remarks = $scope.questionData[id].optionList[i].remarks;
                        if (option_remarks) {
                            remarks = remarks + "<br><br>" + option_remarks;
                        }
                    }
                }
                $scope.remarkdata = remarks;
                $scope.remarksModal.show($scope.remarkdata);
            };
            
            /**
    	     * Event trigger when click close button of the remarks page
    	     * @memberof RAQQuestionsCtrl
    	     * @function hideRemarks 
    		 * @description close remarks page 
    	     */
            $scope.hideRemarks = function() {
                $scope.remarksModal.hide();
            };
            
            /**
    	     * Event trigger when click submit button
    	     * @memberof RAQQuestionsCtrl
    	     * @function goResultsreview
    		 * @description passing parameters and direct to result review page
    	     */
            $scope.goResultsreview = function() {
    			LogUtil.logInfo("RAQQuestionsCtrl -> goResultreview");

                var data = AppState.tmpRAQResult;
                data.userChoices = $scope.userChoices;
                AppState.tmpRAQResult = data;
                LogUtil.logDebug(AppState.tmpRAQResult);
                if($scope.questionLeft>0){
                	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_NOT_ALL_QUESTIONS_ANSWERED'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
                }else {
	                var generalInfo = {
	                    questionnameList: $scope.questionnameList,
	                };
	                var param = {
	                    generalInfo: angular.toJson(generalInfo),
	                    userChoices: $scope.userChoices,
	                    customerType: $scope.customerType,
	                    customerInput: angular.toJson($scope.customerInput)
	                };
	
	                $state.go('base.raq_review', param, {
	                    reload: true
	                });
                }
            };
            $scope.init();
        }
    ]);
});