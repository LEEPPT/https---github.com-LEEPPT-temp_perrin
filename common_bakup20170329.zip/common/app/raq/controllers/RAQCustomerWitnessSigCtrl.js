define(['js/Util/LogUtil',
    'app/app',
    'js/Util/PdfPluginUtil',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService',
    'js/Util/Validation'
], function(LogUtil, app, PdfPluginUtil, AppState,Constants, RAQService,Validation) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQCustomerWitnessSigCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param $translate {service} i18n handling
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ Customer Witness Signature Page
     */
    app.controller('RAQCustomerWitnessSigCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        'RAQService',
        
        function($scope, $stateParams, $ionicModal, $state, $translate, RAQService) {
        	/**
    	     * Initialization function of RAQQuestionsCtrl
    	     * @memberof RAQCustomerWitnessSigCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQRMSigCtrl,
    		 * Dismiss RM witness signature view (Back flow)
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQCustomerWitnessSigCtrl -> init");
        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                busyIndicator.show();
                
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> dismissWitnessBEASignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                
                // Pre-fill customer witness name (Back flow)
                if (AppState.tmpRAQResult.customerWitnessName) {
                    $scope.customerWitnessName = {};
                    $scope.customerWitnessName.name = AppState.tmpRAQResult.customerWitnessName;
                } else {
                    $scope.customerWitnessName = {};
                    $scope.customerWitnessName.name = '';
                }
                
                // Create customer witness signature view
                // Top-left corner of screen is origin of {x=0, y=0}
                var signPadX = 134;
                var signPadY = 303;
                if (AppState.currentLangCode == Constants.LANG_EN){
                    signPadY = 346;  	
                }
                var signPadW = 754;
                var signPadH = 250;

                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> createSignView success');
                    busyIndicator.hide();
                }, function() {
                	 LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> createSignView failure');
                	busyIndicator.hide();
                }, 'SignPlugin', 'createSignView', ['witnessCustomer', signPadX, signPadY, signPadW, signPadH ]);               	
        	};
        	
        	/**
    	     * Event trigger by click clear button
    	     * @memberof RAQCustomerWitnessSigCtrl
    	     * @function clearSig
    		 * @description invoke clearSignView function, reset customer witness signature view
    	     */          
            $scope.clearSig = function() {
    			LogUtil.logInfo("RAQCustomerWitnessSigCtrl -> clearSig");
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> clearSignView');
                }, function() {}, 'SignPlugin', 'clearSignView', ['witnessCustomer']);
            };
            
            /**
    	     * Event trigger by click next button
    	     * @memberof RAQCustomerWitnessSigCtrl
    	     * @function goRmWitnessSig
    		 * @description validate customerWitnessName, try to Capture signature 		 
    	     */   
            $scope.goRmWitnessSig = function() {           	
            	if(Validation.isEmpty(this.customerWitnessName.name)){
                	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_CUSTOMER_WITNESS_NAME_EMPTY'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
                }else {
                	busyIndicator.show();
                	// Capture signature
                	cordova.exec(this.captureSignSuccessCallback, this.captureSignFailureCallback, 'signPlugin', 'captureSignature', ['witnessCustomer']);
                }
            };
            
            /**
    	     * Success Callback of captureSignature
    	     * @memberof RAQCustomerWitnessSigCtrl
    	     * @function captureSignSuccessCallback
    		 * @description  get and store Signature png data,
    		 * Dismiss customer signature view
    		 * passing parameters and direct to RM witness signature page  		 
    	     */ 
            $scope.captureSignSuccessCallback = function(signaturePngData) {
            	// Get the customer witness name and customer witness signature, pass to next page
                LogUtil.logInfo('RAQCustomerWitnessSigCtrl -> captureSignSuccessCallback');
                LogUtil.logInfo(signaturePngData);
                $scope.customerWitnessSignature = signaturePngData;
                $scope.customerInfo.customerWitnessName = $scope.customerWitnessName.name;
                $scope.customerInfo.customerWitnessSignature = $scope.customerWitnessSignature;
                
                // Save data to memory for back flow control
                var data = AppState.tmpRAQResult;
                data.customerWitnessName = $scope.customerWitnessName.name;
                data.customerWitnessSignature = $scope.customerWitnessSignature;
                AppState.tmpRAQResult = data;
                
                // Dismiss customer witness signature view
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> dismissWitnessCustomerSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessCustomer']);
                
                // Get the customerWitnessName,customerWitnessSignature and pass to next page
                $scope.customerInfo.customerWitnessName = $scope.customerWitnessName.name;
                $scope.customerInfo.customerWitnessSignature = $scope.customerWitnessSignature;
                
                var param = {
                    generalInfo: angular.toJson($scope.generalInfo),
                    customerInfo: angular.toJson($scope.customerInfo)
                };
                $state.go('base.raq_rmwitness_signature', param, {
                    reload: true
                });              
                busyIndicator.hide();
            };
            
            /**
    	     * Failure Callback of captureSignature
    	     * @memberof RAQCustomerWitnessSigCtrl
    	     * @function captureSignFailureCallback
    		 * @description  try to find cause of error,log error info, dismiss WitnessCustomer signature view  		 	 
    	     */ 
            $scope.captureSignFailureCallback = function(err) {
                LogUtil.logError('RAQCustomerWitnessSigCtrl -> captureSignFailureCallback');
                LogUtil.logError(err);
                // Dismiss customer witness signature view
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerWitnessSigCtrl -> dismissWitnessCustomerSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessCustomer']);
                busyIndicator.hide();
                WL.SimpleDialog.show($translate.instant('RAQ_SIG_CAPTURE_FAIL_TITLE'),$translate.instant('RAQ_SIG_CAPTURE_FAIL'),[{text:$translate.instant('BTN_OK'), handler: function() {                    	                       
                	var param = {
                            generalInfo: angular.toJson($scope.generalInfo),
                            customerInfo: angular.toJson($scope.customerInfo)
                     };
                	$state.go($state.current, param, {reload: true});
                }}]); 
            };           
            $scope.init();
        }
    ]);
});