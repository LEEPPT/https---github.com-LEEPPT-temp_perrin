define([
	'js/Util/LogUtil',
    'app/app',
    'app/raq/services/RAQService',
    'js/Util/DataPersister',
    'js/appState'
], function(LogUtil, app, RAQService, DataPersister, AppState) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQCustomerSigCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ Customer Signature Page
     */
    app.controller('RAQCustomerSigCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        'RAQService',
        function($scope, $stateParams, $ionicModal, $state, $translate, RAQService) {
        	/**
    	     * Initialization function of RAQQuestionsCtrl
    	     * @memberof RAQCustomerSigCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQDisclaimerCtrl,
    		 * Dismiss RM signature view (Back flow)
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQCustomerSigCtrl -> init");

        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                busyIndicator.show();
               
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerSigCtrl -> dismissRMSignView');
                }, function() {}, "SignPlugin", "dismissSignView", ["rm"]);
        		
                // Create customer signature view
                var signPadX = 135;
                var signPadY = 220;
                var signPadW = 754;
                var signPadH = 250;

                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerSigCtrl -> createSignView success');
                    busyIndicator.hide();
                }, function() {                	
                	LogUtil.logDebug('RAQCustomerSigCtrl -> createSignView failure');
                	busyIndicator.hide();
                }, "SignPlugin", "createSignView", ["customer", signPadX, signPadY, signPadW, signPadH]);
        	};
        	
        	/**
    	     * Event trigger when click clear button
    	     * @memberof RAQCustomerSigCtrl
    	     * @function clearSig
    		 * @description invoke clearSignView function, reset customer signature view
    	     */
            $scope.clearSig = function() {
                cordova.exec(function() {
                    LogUtil.logDebug('RAQCustomerSigCtrl -> clearSignView');
                }, function() {}, "SignPlugin", "clearSignView", ["customer"]);
            };

            /**
    	     * Event trigger by click submit button
    	     * @memberof RAQCustomerSigCtrl
    	     * @function goRmSig
    		 * @description Capture signature, 
    		 * if Capture signature success, store Signature png data,
    		 * Dismiss customer signature view
    		 * passing parameters and direct to RM signature page
    	     */           
            $scope.goRmSig = function() {
            	busyIndicator.show();
            	// Capture signature success callback
                var captureSignSuccessCallback = function(signaturePngData) {
                	// Get the customer signature, pass to next page
                    LogUtil.logInfo('RAQCustomerSigCtrl -> captureSignSuccessCallback');               
                    $scope.customerInfo.customerSignature = signaturePngData;                   
                    // Dismiss customer signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('RAQCustomerSigCtrl -> dismissSignView');
                    }, function() {}, "SignPlugin", "dismissSignView", ["customer"]);
                                    
                    var param = {
                        generalInfo: angular.toJson($scope.generalInfo),
                        customerInfo: angular.toJson($scope.customerInfo)
                    };
                    $state.go('base.raq_rm_signature', param, {
                        reload: true
                    });                    
                    busyIndicator.hide();
                };
                
                // Capture signature failure callback
                var captureSignFailureCallback = function(err) {                	
                	LogUtil.logError('captureSignFailureCallback');
                	LogUtil.logError(err);
                	busyIndicator.hide();
                    WL.SimpleDialog.show($translate.instant('RAQ_SIG_CAPTURE_FAIL_TITLE'),$translate.instant('RAQ_SIG_CAPTURE_FAIL'),[{text:$translate.instant('BTN_OK'), handler: function() {                    	                      
                    	var param = {
                                generalInfo: angular.toJson($scope.generalInfo),
                                customerInfo: angular.toJson($scope.customerInfo)
                         };
                    	$state.go($state.current, param, {reload: true});
                    }}]);
                	
                	// Dismiss customer signature view
                    cordova.exec(function() {
                        LogUtil.logDebug('RAQCustomerSigCtrl -> dismissSignView');
                    }, function() {}, "SignPlugin", "dismissSignView", ["customer"]);
                };
                
                // Capture signature
                cordova.exec(captureSignSuccessCallback, captureSignFailureCallback, "signPlugin", "captureSignature", ["customer"]);
            };
            $scope.init();
        }
    ]);
});