define(['js/Util/LogUtil',
    'app/app',
    'js/appState',
], function(LogUtil, app, AppState) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQDisclaimerCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $ionicScrollDelegate {service} for control scroll views 
     * @param $state {service} for store data in appState
     * @description 
     *   Controller for RAQ disclaimer display and confirm Page
     */
    app.controller('RAQDisclaimerCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$ionicScrollDelegate',
        '$state',
        function($scope, $stateParams, $ionicModal, $ionicScrollDelegate, $state) {
        	/**
    	     * Initialization function of RAQDisclaimerCtrl
    	     * @memberof RAQDisclaimerCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQDeclarationCtrl page,
    		 * Dismiss Customer signature view (Back flow)
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQDisclaimerCtrl -> init");

        		$scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                AppState.tmpRAQResult.generalInfo=$scope.generalInfo;
                AppState.tmpRAQResult.customerInfo=$scope.customerInfo;
                cordova.exec(function() {
                    LogUtil.logDebug('dismissCustomerSignView');
                }, function() {}, "SignPlugin", "dismissSignView", ["customer"]);
                $scope.isbottom = 0;
        	};
        	
    		/**
    	     * Event trigger by scroll down the page
    	     * @memberof RAQDisclaimerCtrl
    	     * @function checkScroll
    		 * @description calculate the distance to top, then justify whether scroll down to the bottom 
    	     */
            $scope.checkScroll = function() {
                var distance_top = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollPosition().top;
                var max_Scrollheight = $ionicScrollDelegate.$getByHandle('scroll-resultsreview').getScrollView().__maxScrollTop;
                if (distance_top >= max_Scrollheight) {
                    $scope.isbottom = 1;
                }
                $scope.$apply();
            };
            
            /**
    	     * Event trigger by click confirm button
    	     * @memberof RAQDisclaimerCtrl
    	     * @function goCustomerSig 
    		 * @description passing parameters and direct to customer signature page 
    	     */
            $scope.goCustomerSig = function() {
                var param = {
                    generalInfo: angular.toJson($scope.generalInfo),
                    customerInfo: angular.toJson($scope.customerInfo)
                };
                
                $state.go('base.raq_customer_signature', param, {
                    reload: true
                });
            };
            $scope.init();
        }
    ]);
});