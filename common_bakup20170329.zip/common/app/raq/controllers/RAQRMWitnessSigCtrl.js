define([
    'app/app',
    'js/Util/DataPersister',
    'js/Util/PdfPluginUtil',
    'js/appState',
    'js/constants',
    'app/raq/services/RAQService',
    'js/Util/LogUtil',
    'js/Util/AuditLoggingUtil',
    'js/Util/Validation'
], function(app, DataPersister, PdfPluginUtil, AppState, Constants, RAQService, LogUtil, AuditLoggingUtil, Validation) {
    'use strict';
    /**
     * @memberof app
     * @ngdoc controller
     * @name RAQRMWitnessSigCtrl
     * @param $scope {service} controller scope
     * @param $stateParams{service} for passing parameters between controllers
     * @param $ionicModal {service} for display temporary view  
     * @param $state {service} for store data in appState
     * @param $translate {service} i18n handling
     * @param $filter {service} for data formating
     * @param RAQService {service} Service Class for handling business logic of RAQ
     * @description 
     *   Controller for RAQ RM Witness Signature Page
     */
    app.controller('RAQRMWitnessSigCtrl', [
        '$scope',
        '$stateParams',
        '$ionicModal',
        '$state',
        '$translate',
        '$filter',
        'RAQService',
        
        function($scope, $stateParams, $ionicModal, $state, $translate, $filter, RAQService) {
        	/**
    	     * Initialization function of RAQQuestionsCtrl
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function init
    		 * @description retrieve temporary RAQ data from app storage and read parameters from RAQCustomerWitnessSigCtrl,
    		 * Create RMWitness signature view
    	     */
        	$scope.init=function(){
    			LogUtil.logInfo("RAQRMWitnessSigCtrl -> init");
        		 busyIndicator.show();
        		 $scope.generalInfo = angular.fromJson($stateParams.generalInfo);
                 $scope.customerInfo = angular.fromJson($stateParams.customerInfo);
                 $scope.customerType = $scope.customerInfo.customerType;
                 $scope.customerInput = angular.fromJson($scope.customerInfo.customerInput);
                 $scope.rmName = AppState.userInfo.userFullName;
                 $scope.rmRINumber = $scope.customerInfo.rmRINumber;
                 $scope.isResultOverridden = $scope.customerInfo.isResultOverridden;
                 $scope.newRiskToleranceLevelTypeEn='';
                 $scope.newRiskToleranceLevelTypeTc='';
                 $scope.newRiskToleranceLevelTypeSc='';
                 $scope.newRiskToleranceLevelType='';
                 $scope.riskToleranceLevel = Number($scope.customerInfo.riskToleranceLevel);
                 if($scope.isResultOverridden==1){
                	 	$scope.newRiskToleranceLevel = Number($scope.customerInfo.newRiskToleranceLevel);                    
                 }
                 $scope.questionnameList = $scope.generalInfo.questionnameList;
                 $scope.optionID = $scope.customerInfo.optionID;
                 $scope.isSubmitted = false;
                 
                 var signPadX = 134;
                 var signPadY = 303;
                 var signPadW = 754;
                 var signPadH = 250;
                 cordova.exec(function() {
                     LogUtil.logDebug('RAQRMWitnessSigCtrl -> createSignView success');
                     busyIndicator.hide();
                 }, function() {
                	 LogUtil.logDebug('RAQRMWitnessSigCtrl -> createSignView failure');
                	 busyIndicator.hide();
                 }, 'SignPlugin', 'createSignView', ['witnessBEA', signPadX, signPadY, signPadW, signPadH]);                 
                 $scope.getPDFTemplate();
                 $scope.getrmWitnessRINumber();
                 $scope.getRiskToleranceLevelType();
                 $scope.preparePDF();
                
        	};
        	
        	/**
    	     * Event trigger when click clear button
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function clearSig
    		 * @description invoke clearSignView function, reset RM witness signature view
    	     */ 
            $scope.clearSig = function() {
    			LogUtil.logInfo("RAQRMWitnessSigCtrl -> clearSig");

                cordova.exec(function() {
                    LogUtil.logDebug('clearSignView');
                }, function() {}, 'SignPlugin', 'clearSignView', ['witnessBEA']);
            };

       		/**
    	     * get Templates for generating RAQ PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function getRAQPDFTemplates
    		 * @description select Templates for generating RAQ PDF according to customerType and current language
    	     */
            $scope.getPDFTemplate=function(){
            	LogUtil.logDebug('get templates: AppState.raqPDFTemplate ');
                var pdfLangCode = AppState.currentLangCode;
            	if(AppState.currentLangCode == Constants.LANG_EN){
            		pdfLangCode = Constants.LANG_TC;
            	}
            	var pdfTemplateId = 'raq_'+$scope.customerType+'_'+pdfLangCode;
                for (var i = 0; i < AppState.raqPDFTemplate.length; i++) {
                     if (AppState.raqPDFTemplate[i].id.toUpperCase() == pdfTemplateId.toUpperCase()) {
                            $scope.raqPDFTemplate = AppState.raqPDFTemplate[i].fileContent;
                     }
                }	
            };

            /**
    	     * get rmWitnessName & Number for generating RAQ PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function get rmWitnessName & Number
    		 * @description check if there exists rmWitnessName in AppState or has new input, 
    		 * if not, just initialize it 
    	     */
            $scope.getrmWitnessRINumber=function(){
            	if (AppState.tmpRAQResult.rmWitnessName) {
                    $scope.rmWitnessName = {};
                    $scope.rmWitnessName.name = AppState.tmpRAQResult.rmWitnessName;          
                } else {
                    $scope.rmWitnessName = {};
                    $scope.rmWitnessName.name = '';                   
                }
            	if (AppState.tmpRAQResult.rmWitnessRINumber) {
                    $scope.rmWitnessRINumber = {};
                    $scope.rmWitnessRINumber.num = AppState.tmpRAQResult.rmWitnessRINumber;
                } else {
                    $scope.rmWitnessRINumber = {};
                    $scope.rmWitnessRINumber.num = '';
                }           	  
            };
            
            /**
    	     * get RiskTolerance Level and Type
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function getRiskToleranceLevelType
    		 * @description get level list first,
    		 * then get riskTolerance Level and Type of different languages
    		 * get new riskTolerance Level and Type of different languages if exists
    	     */ 
            $scope.getRiskToleranceLevelType=function(){            	 
                 $scope.levelListEn = AppState.raqConfig.levelList.get(Constants.LANG_EN);
            	 $scope.levelListTc = AppState.raqConfig.levelList.get(Constants.LANG_TC);
            	 $scope.levelListSc = AppState.raqConfig.levelList.get(Constants.LANG_SC);
            	 $scope.riskToleranceLevelTypeEn = $scope.levelListEn[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListEn[$scope.riskToleranceLevel-1].type;
              	 $scope.riskToleranceLevelTypeTc = $scope.levelListTc[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListTc[$scope.riskToleranceLevel-1].type;        	  
            	 $scope.riskToleranceLevelTypeSc = $scope.levelListSc[$scope.riskToleranceLevel-1].level +' - '+$scope.levelListSc[$scope.riskToleranceLevel-1].type;               
            	 if ($scope.newRiskToleranceLevel) {
                    $scope.newRiskToleranceLevelTypeEn = $scope.levelListEn[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListEn[$scope.newRiskToleranceLevel-1].type;
                    $scope.newRiskToleranceLevelTypeTc = $scope.levelListTc[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListTc[$scope.newRiskToleranceLevel-1].type;
                    $scope.newRiskToleranceLevelTypeSc = $scope.levelListSc[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelListSc[$scope.newRiskToleranceLevel-1].type;
               } 
            };
            
            /**
    	     * Prepare for PDF generation
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function preparePDF
    		 * @description format data of those parameters in generate pdf function   
    	     */ 
            $scope.preparePDF=function(){
            	if ($scope.customerInfo.isResultOverridden === 0) {
                    $scope.isResultMatch = 'Y';
                    $scope.isResultNotMatch = 'N';
                    $scope.customerName1 = $scope.customerInput.customerName;
                    $scope.customerName2 = '';
                } else {
                    $scope.isResultMatch = 'N';
                    $scope.isResultNotMatch = 'Y';
                    $scope.customerName1 = '';
                    $scope.customerName2 = $scope.customerInput.customerName;
                }

                if ($scope.customerInfo.isPhotoCopyRecieved == 1) {
                    $scope.isPhotoCopyReceived = 'Y';
                } else {
                    $scope.isPhotoCopyReceived = 'N';
                }

                $scope.answersList = [];
                for (var i = 0; i < $scope.questionnameList.length; i++) {
                    $scope.answersList.push({
                        'questionID': $scope.questionnameList[i],
                        'optionID': $scope.optionID[i]
                    });
                }

            };
            
            /**
    	     * get Template to display upload pdf success information
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function ionicModal fromTemplateUrl 
    		 * @description read the modal file according to url 
    	     */ 
            $ionicModal.fromTemplateUrl('./app/raq/templates/raq_submit_success.html', {
                scope: $scope,
        		backdropClickToClose : false
            }).then(function(modal) {
                $scope.submitModal = modal;
            });

            /**
    	     * Event trigger when click submit button
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function goSubmit
    		 * @description validate rmWitnessName, try to Capture signature 		
    		 * 
    	     */ 
             $scope.goSubmit = function() {
            	$scope.submitRAQStart = Date.now();
            	
            	$scope.isSubmitted = true;
                if(Validation.isEmpty(this.rmWitnessName.name)){
                	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_RI_WITNESS_NAME_EMPTY'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
                }else {
                	busyIndicator.show();
                	// Capture signature
                	cordova.exec(this.captureSignSuccessCallback, this.captureSignFailureCallback, 'signPlugin', 'captureSignature', ['witnessBEA']);
                }
            };
            
    		/**
    	     * Success callback function of capture Signature
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function captureSignSuccessCallback
    		 * @description Capture signature, store Signature png data,
    		 * dismiss RM witness signature view.
    		 * Proceed to generate PDF and submit RAQ result 
    	     */
            $scope.captureSignSuccessCallback = function(signaturePngData) {
                LogUtil.logDebug('captureSignSuccessCallback');
                $scope.rmWitnessSignature = signaturePngData;
                cordova.exec(function() {
                    LogUtil.logDebug('dismissSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                $scope.generateRAQPDF();
            };
            
    		/**
    	     * Failure callback function of capture Signature
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function captureSignFailureCallback
    		 * @description try to find cause of error,log error info, dismiss RM witness signature view
    	     */          
            $scope.captureSignFailureCallback = function(err) {                   
                    LogUtil.logError('captureSignFailureCallback');
                    LogUtil.logError(err);
                    busyIndicator.hide();
                    cordova.exec(function() {
                        LogUtil.logDebug('dismissSignView');
                    }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                    
                    WL.SimpleDialog.show($translate.instant('RAQ_SIG_CAPTURE_FAIL_TITLE'),$translate.instant('RAQ_SIG_CAPTURE_FAIL'),[{text:$translate.instant('BTN_OK'), handler: function() {                    	                       
                    	var param = {
                                generalInfo: angular.toJson($scope.generalInfo),
                                customerInfo: angular.toJson($scope.customerInfo)
                         };
                    	$state.go($state.current, param, {reload: true});
                    }}]); 
            };
            
            /**
    	     * get levelList content according to language change
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function watch currentLangCode
    		 * @description check current language, then get levelList content according to language 
    		 * get riskToleranceLevelType according to levelList
    		 * get newRiskToleranceLevelType if there exists
    	     */
            $scope.$watch('AppState.currentLangCode', function() {
            	$scope.levelList = AppState.raqConfig.levelList.get(AppState.currentLangCode);           	
            	$scope.riskToleranceLevelType = $scope.levelList[$scope.riskToleranceLevel-1].level +' - '+$scope.levelList[$scope.riskToleranceLevel-1].type;
            	if ($scope.newRiskToleranceLevel) {
                    $scope.newRiskToleranceLevelType = $scope.levelList[$scope.newRiskToleranceLevel-1].level +' - '+$scope.levelList[$scope.newRiskToleranceLevel-1].type;
                }
                
            }, true);

            /**
    	     * Invoke from "captureSignSuccessCallback" 
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function generateRAQPDF
    		 * @description pass parameters for generating pdf  
    	     */           
            $scope.generateRAQPDF = function() {
                var date = $filter('date')(new Date(), 'dd MMM yyyy');
                var data = AppState.tmpRAQResult;
                data.rmWitnessName = $scope.rmWitnessName.name;
                data.rmWitnessRINumber = $scope.rmWitnessRINumber.num;
                AppState.tmpRAQResult = data;
                var reqData = {
                    accountName: $scope.customerInput.accountName,
                    accountNumber: $scope.customerInput.accountNumbe != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '',
                    customerName: $scope.customerInput.customerName,
                    rmName: $scope.rmName,
                    rmRINumber: $scope.customerInfo.rmRINumber,
                    customerWitnessName: $scope.customerInfo.customerWitnessName,
                    rmWitnessName: $scope.rmWitnessName.name,
                    rmWitnessRINumber: $scope.rmWitnessRINumber.num,
                    cumulativeScore: $scope.customerInfo.cumulativeScore + '',
                    riskToleranceLevelEn:$scope.riskToleranceLevelTypeEn,
                    riskToleranceLevelTc:$scope.riskToleranceLevelTypeTc,
                    riskToleranceLevelSc: $scope.riskToleranceLevelTypeSc,  
                    isResultMatch: $scope.isResultMatch,
                    isResultNotMatch: $scope.isResultNotMatch,
                    isPhotoCopyReceived: $scope.isPhotoCopyReceived,
                    customerName1: $scope.customerName1,
                    customerName2: $scope.customerName2,
                    newRiskToleranceLevelEn: $scope.newRiskToleranceLevelTypeEn,
                    newRiskToleranceLevelTc: $scope.newRiskToleranceLevelTypeTc,
                    newRiskToleranceLevelSc: $scope.newRiskToleranceLevelTypeSc,
                    customerSignature: $scope.customerInfo.customerSignature,
                    rmSignature: $scope.customerInfo.rmSignature,
                    customerWitnessSignature: $scope.customerInfo.customerWitnessSignature,
                    rmWitnessSignature: $scope.rmWitnessSignature,
                    date: date,
                    answersList: $scope.answersList,
                    inputFileContent: $scope.raqPDFTemplate
                };
                // Generate PDF
                PdfPluginUtil.generateRaqPDF(reqData, this.successCallback, this.failureCallback);
            };

     	 	/**
    	     * Event trigger by click close button of submit success page
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function hide Overlay 
    		 * @description close submit success info page 
    	     */
            $scope.hideOverlay = function() {
                $scope.submitModal.hide();
                $state.go('base.raq_select_customer_type', {}, {
                    reload: true
                });
            };
            
            /**
    	     * event trigger when uploadRAQPDF Failure
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function saveRAQResultToLocal
    		 * @description  invoke saveRAQResult function in  RAQService, 
    		 * if success, invoke saveRAQResultSuccessCallback
    	     */ 
            $scope.saveRAQResultToLocal = function (){
            	RAQService.saveRAQResult($scope.raqResultData, $scope.saveRAQResultSuccessCallback, $scope.saveRAQResultFailureCallback);
            };
            
    		/**
    	     * Success callback function of Generating PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function Generate PDF successCallback
    		 * @description invoke uploadRAQPDFFiles function in RAQService,
    		 * if success, invoke uploadRAQPDFSuccessCallback   		
    	     */
            // Generate PDF success callback	        	
            $scope.successCallback = function(data) {
                LogUtil.logDebug('RAQRMWitnessSigCtrl: generate PDF sucess: data :');
                $scope.pdfdata = data;
                //upload file
                var accountName = $scope.customerInput.accountName;
                var accountNumber = $scope.customerInput.accountNumbe != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '';
                var customerName = $scope.customerInput.customerName;
                LogUtil.logDebug('RAQRMWitnessSigCtrl:attempt to uploadRAQPDFFiles');
 
                // File upload : data : generatedPdf
                RAQService.uploadRAQPDFFiles(data, customerName, accountName, accountNumber, $scope.uploadRAQPDFSuccessCallback, $scope.uploadRAQPDFFailureCallback);
                var auditLogInfo = {
                    userID: AppState.userID,
                    activity: 'submit_raq',
                    customerName: customerName,
                    accountName: accountName,
                    accountNumber: accountNumber
                };
                AuditLoggingUtil.insertAuditLogging(auditLogInfo);
            };                  
            
    		/**
    	     * Success callback function of uploading PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function uploadRAQPDFSuccessCallback
    		 * @description Clear the RAQ data in memory, Show the success overlay,
    		 * Dismiss RM Witness signature view		
    	     */
            $scope.uploadRAQPDFSuccessCallback = function(data) {
                LogUtil.logDebug('RAQRMWitnessSigCtrl : uploadRAQPDF  SuccessCallback');
                busyIndicator.hide();
                // Clear the RAQ data in memory
                AppState.tmpRAQResult = {};
                // Dismiss RM witness signature view
                cordova.exec(function() {
                    LogUtil.logDebug('dismissSignView');
                }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                // Show the success overlay
                $scope.submitModal.show();
                $scope.submitRAQEnd = Date.now();
            	var responseTime = ($scope.submitRAQEnd - $scope.submitRAQStart)/1000;
	            LogUtil.logInfo('Performance Test : Submit RAQ userID=' + AppState.userID +' r='+responseTime);
            };
            
            /**
    	     * Failure Callback of uploading RAQ PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function  uploadRAQPDFFailureCallback
    		 * @description  try to Save RAQ data to local storage
    		 * log error message		 	 
    	     */ 
            $scope.uploadRAQPDFFailureCallback = function(data) {
                LogUtil.logDebug('RAQRMSigCtrl : uploadRAQPDF  FailureCallback: store generatedPDF in local storage ');
                var datatmp = AppState.tmpRAQResult;
                datatmp.rmWitnessName = $scope.rmWitnessName.name;
                datatmp.accountNumber = $scope.customerInput.accountNumbe != '' ? Constants.ACCOUNT_PREFIX + $scope.customerInput.accountNumber : '';
                datatmp.rmWitnessRINumber = $scope.rmWitnessRINumber.num;
                datatmp.generatedPdf = $scope.pdfdata;
                datatmp.riskToleranceLevel = $scope.riskToleranceLevel;
                datatmp.newRiskToleranceLevel = $scope.newRiskToleranceLevel;
                $scope.raqResultData = datatmp;
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - Error returned from ZPB - ' + errorCode);
                    $scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_ZPB_FAILURE')+'-'+errorCode;
                    $scope.saveRAQResultToLocal();
                }else{
                	WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('Network Info : '+networkInfo.isNetworkConnected);
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - No internet connection');
			  				$scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_INTERNET_CONNECTION');
			  			}else{
			  				LogUtil.logError('RAQRMSigCtrl -> uploadRAQPDFFiles -> uploadRAQPDFFailureCallback : Submit RAQ failure - MobileFirst server connection failure');
			  				$scope.errorMsg = $translate.instant('ERR_SUBMIT_RAQ_MFP_CONNECTION_FAILURE');
			  			}		  			
			  			$scope.saveRAQResultToLocal();
   			  		});
                }
            };
            
            /**
    	     * Failure Callback of Generate RAQ PDF
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function  Generate PDF failureCallback
    		 * @description  log error message, go back to selecting type page,
    		 * Dismiss RM Witness signature view 	 
    	     */
            $scope.failureCallback = function(data) {
                busyIndicator.hide();
    			LogUtil.logInfo("RAQRMWitnessSigCtrl -> failureCallback");
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'), $translate.instant('ERR_SUBMIT_N_SAVE_RAQ_FAILURE'), [{
                    text: $translate.instant('BTN_OK'),
                    handler: function() {
                        // Clear RAQ data in memory
                        AppState.tmpRAQResult = {};
                        // back to select type page
                        $state.go('base.raq_select_customer_type', {}, {
                            reload: true
                        });
                        // Dismiss RM witness signature view
                        cordova.exec(function() {
                            LogUtil.logDebug('dismissRMSignView');
                        }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                    }
                }]);
            };
            
    		/**
    	     * Success Callback of saveRAQResultToLocal function
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function saveRAQResultSuccessCallback
    		 * @description Save RAQ to local, Clear RAQ data in memory,
    		 * display  upload Error message
    		 * dismiss RM Witness signature view.
    		 * go back to select type page  		
    	     */
            $scope.saveRAQResultSuccessCallback = function() {
            	busyIndicator.hide();
                LogUtil.logDebug('RAQRMWitnessSigCtrl -> saveRAQResultSuccessCallback ');
                // Clear RAQ data in memory
                AppState.tmpRAQResult = {};
                
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$scope.errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {                    
                        $state.go('base.raq_select_customer_type', {}, {
                            reload: true
                        });
                        // Dismiss RM witness signature view
                        cordova.exec(function() {
                            LogUtil.logDebug('dismissSignView');
                        }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                    }
                }]);
            };
            
            /**
    	     * Failure Callback of saveRAQResultToLocal
    	     * @memberof RAQRMWitnessSigCtrl
    	     * @function saveRAQResultFailureCallback
    		 * @description  try to find cause of error,log error info,
    		 * Clear temporary RAQ data in memory 
    		 * Go back to select type page
    		 * dismiss RM Witness signature view  		 	 
    	     */ 
            $scope.saveRAQResultFailureCallback = function() {
            	busyIndicator.hide();
                LogUtil.logDebug('RAQRMWitnessSigCtrl : saveRAQResultFailureCallback ');
             // Clear RAQ data in memory
                AppState.tmpRAQResult = {};               
                WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_RAQ_TITLE'),$translate.instant('ERR_SUBMIT_N_SAVE_RAQ_FAILURE'),[{text:$translate.instant('BTN_OK'), 
                	handler: function() {               
                        $state.go('base.raq_select_customer_type', {}, {
                            reload: true
                        });
                        // Dismiss RM witness signature view
                        cordova.exec(function() {
                            LogUtil.logDebug('dismissSignView');
                        }, function() {}, 'SignPlugin', 'dismissSignView', ['witnessBEA']);
                    }
                }]);
            };
            $scope.init();           
        }
    ]);
});