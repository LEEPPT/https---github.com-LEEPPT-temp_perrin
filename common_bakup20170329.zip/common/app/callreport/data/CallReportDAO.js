define([
  'app/app',
  'js/Util/DataPersister',
  'js/Util/LogUtil',
  'js/appState',
  'js/Adapters/CallReportAdapter'
], function (app,DataPersister,LogUtil,AppState,CallReportAdapter) {
  'use strict';

  app.factory('CallReportDAO', function(){
	  var dao = {};
	  var _data =[];
	  
	  /*
	   * The following 3 functions are only called internally
	   */
	  var getJSONStoreData = function(successCallback, failureCallback) {
	      DataPersister.getAppDataByNameValue('storedCallReport',successCallback,failureCallback);
	  };
	  var setJSONStoreData = function(data, successCB, failureCB) {
		  DataPersister.setAppDataByNameValue('storedCallReport', data, successCB, failureCB);
	  };
	  var initJSONStore = function (successCallback, failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list for all call reports');
		  
		  getJSONStoreData(function(data){
	    	  if (typeof data === 'undefined' || data === null || data === "null") {
	    		data = [];  
	    		setJSONStoreData(data);
	    	  }
	    	  AppState.storedCallReport = data;
	    	  successCallback(data);
	      }, function(errObj) {
	    	  failureCallback(errObj);
	      });
	  };  
	  
	  /*
	   * Construct dao
	   */
	  dao.listAll = function(successCallback,failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list of call reports');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Successfully retrieved list of call reports');
			  AppState.storedCallReport = result;
			  if (typeof successCallback === 'function') {
				  successCallback(result);
			  }
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed initialising JSONStore for call report: ['+errObj.err+']'+errObj.msg);
    		  if (typeof failureCallback === 'function') {
    			  failureCallback(result);
			  }
		  };
		  initJSONStore(invocationSuccessCallback, invocationFailureCallback);
	  };
	  dao.retrieveCallReportByID = function(id, successCallback, failureCallback) {
		  var callReport = null;
		  
		  for (var i = 0 ; i < AppState.storedCallReport.length ; i++) {
			  if (String(AppState.storedCallReport[i].id) === id) {
				  callReport = AppState.storedCallReport[i];
			  }
		  }
		  
		  if (callReport) {
			  LogUtil.logDebug('Found call report for id: ' + id);
			  successCallback(callReport);
		  } else {
			  LogUtil.logDebug('No cal report in memory matched id: ' + id);
			  failureCallback({msg: 'Cannot find call report'});
		  }
	  };
	  
	  dao.addCallReport = function(data, successCallback, failureCallback) {
		  var now = Date.now();
		  var callReport;
		  if (typeof data === 'object' && !Array.isArray(data)) {
			  callReport = data;
			  callReport.id = now;
			  callReport.lastModifiedDate = now;
		  } else {
			  callReport = {
				id : now,
				callReport : data,
				lastModifiedDate : now
			  }; 
		  }
		  
		  LogUtil.logDebug('Number of call report in memory BEFORE insert: ' + AppState.storedCallReport.length);
		  AppState.storedCallReport.unshift(callReport);
		  LogUtil.logDebug('Number of call report in memory AFTER insert: '+AppState.storedCallReport.length);
		  LogUtil.logDebug('ID of inserted call report is '+callReport.id);

		  LogUtil.logDebug('Attempt to insert call report to JSONStore');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of call report in JSONStore AFTER insert: '+result.length);
			  AppState.storedCallReport = result;
			  successCallback(callReport.id);
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed inserting call report to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  setJSONStoreData(AppState.storedCallReport, invocationSuccessCallback, invocationFailureCallback);
	  };
	  
	  dao.updateCallReport = function(data, successCallback, failureCallback) {
		  var id = data.id;
		  LogUtil.logDebug('CallReportDAO : updateCallReport id: ' + id);
		  for (var i = 0 ; i < AppState.storedCallReport.length ; i++) {
			  if (AppState.storedCallReport[i].id === id) {
				  AppState.storedCallReport[i] = data;
			  }
		  }
		  LogUtil.logDebug(AppState.storedCallReport);
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of call report in JSONStore AFTER insert: ' + result.length);
			  successCallback();
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed updating call report to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  
		  setJSONStoreData(AppState.storedCallReport, invocationSuccessCallback, invocationFailureCallback);
	  };
	  
	  dao.submitCallReport = function(reportData, successCallback, failureCallback){
		  var adapterSuccessCallback = function(data) {
			  if (data && data.responseJSON) {	            	
				  LogUtil.logInfo('CallReportDAO : adapterSuccessCallback : submitCallReport success');
				  successCallback(reportData);
			  } else {
				  LogUtil.logError('CallReportDAO : adapterSuccessCallback  : submitCallReport error');
				  failureCallback(data);
			  }
		  };	 	       
		  var adapterFailureCallback = function(data) {
			  LogUtil.logError('CallReportDAO : adapterFailureCallback : submitCallReport : Fail to invoke CallReportAdapter');
			  if (data && data.responseJSON && data.responseJSON.errorCode) {
				  data.errorCode = data.responseJSON.errorCode;
			  }
			  failureCallback(data);
		  };
		  CallReportAdapter.submitCallReport(AppState.userID, reportData, adapterSuccessCallback, adapterFailureCallback);
	  };
	  
	  dao.deleteCallReportByID = function(id, successCallback, failureCallback) {
		  var index = -1;
		  for (var i = 0 ; i < AppState.storedCallReport.length ; i++) {
			  if (AppState.storedCallReport[i].id == id) {
				  index = i;
			  }
		  }
		  if (index > -1) {
    		  LogUtil.logDebug('Number of call report in memory BEFORE deletion: ' + AppState.storedCallReport.length);
			  AppState.storedCallReport.splice(index, 1);
    		  LogUtil.logDebug('Number of call report in memory AFTER deletion: '+ AppState.storedCallReport.length);
			  var invocationSuccessCallback = function(result) {
				  LogUtil.logDebug('Number of call report in JSONStore AFTER deletion: '+result.length);
				  AppState.storedCallReport = result;
				  successCallback(result);
			  };
			  var invocationFailureCallback = function(errObj) {
	    		  LogUtil.logError('Failed deleting call report in JSONStore: ['+errObj.err+']'+errObj.msg);
	    		  failureCallback(errObj);
			  };
			  setJSONStoreData(AppState.storedCallReport, invocationSuccessCallback, invocationFailureCallback);

		  } else {
    		  LogUtil.logDebug('No call report is deleted because if no call report matching id: '+id);
			  failureCallback({msg : 'Cannot find call report'});
		  }
	  };
	  
	  return dao;
  });
});
