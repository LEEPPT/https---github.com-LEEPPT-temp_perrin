define([
    'app/app',
    'js/appState',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/AuditLoggingUtil',
    'app/callreport/services/CallReportService',
	'js/constants',
    'js/appConfig',
    'js/Util/FunctionActivator',
], function(app, AppState, LogUtil, CommonUtil, AuditLoggingUtil, CallReportService, Constants, AppConfig, FunctionActivator) {
    'use strict';

    app.controller('CallReportMainCtrl',[
        '$scope',
        '$translate',
        '$filter',
        '$state',
        'CallReportService',
        '$ionicModal',
        function($scope, $translate, $filter, $state, CallReportService, $ionicModal) {
        	$scope.init = function() {           	
                LogUtil.logDebug('CallReportCtrl -> init');
                
                $scope.isSidePanelActivated = false;
            	$scope.callReportsLength = 0;
            	if (FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_CALL_REPT) === false) {
                	FunctionActivator.showAccessDeniedMessage($ionicHistory);
                	return;
        		}
                $scope.activatedCallReportIndex = -1;
        		$scope.callReportsListContainer = $(".panning-container > .panning-column");
        		$scope.sidePanelContainer = $(".side-panel");
        		$scope.transitionTypes = {
    					'transition':'transitionend',
    					'OTransition':'oTransitionEnd',
    					'MozTransition':'transitionend',
    					'WebkitTransition':'webkitTransitionEnd'
    			};
        		$scope.transitionKey = '';
        		for (var t in $scope.transitionTypes){
        			if ($scope.sidePanelContainer[0].style[t] !== undefined) {
        				$scope.transitionKey = t;
        				break;
        			}
        		}
        		var storedCallReport = AppState.storedCallReport;
                for (var i = 0; storedCallReport && i < storedCallReport.length; i++) {
                	if (storedCallReport[i].lastModifiedDate) {
                		storedCallReport[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedCallReport[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
                	} else {
                		storedCallReport[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedCallReport[i].id),'dd MMM yyyy, HH:mm'), true);
                	}
                	if (storedCallReport[i].meetingDate) {
                		storedCallReport[i].displayMeetingDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedCallReport[i].meetingDate),'dd MMM yyyy'));
                	}
                }
                $scope.storedCallReport = AppState.storedCallReport;
        	};
        	$scope.showHideCallReport = function(_evt){       	
        		var clickTriggerElement = $(_evt.target),
        			classCheckingString = 'call-report',
        			isCallReportClicked = clickTriggerElement.hasClass('button-'+classCheckingString);
        		if (!isCallReportClicked) {
        			if (this.isSidePanelActivated) {
        				$scope.modifySidePanel('hide');
        				this.callReportButtons.removeClass('selected');
        			}
        			return;
        		}
        		var clickCallReportId = clickTriggerElement.attr('id'),
        			clickCallReportIndex = parseInt(clickCallReportId.replace(classCheckingString+'-',''));

        		if (this.isSidePanelActivated && $scope.activatedCallReportIndex == clickCallReportIndex) {
        			clickTriggerElement.removeClass('selected');
        			$scope.modifySidePanel('hide');
        		} else if (this.isSidePanelActivated && $scope.activatedCallReportIndex != clickCallReportIndex) {
        			this.callReportButtons.removeClass('selected');
        			clickTriggerElement.addClass('selected');
        			$scope.activatedCallReportIndex = clickCallReportIndex;
        		} else if (!this.isSidePanelActivated) {
        			clickTriggerElement.addClass('selected');
        			$scope.modifySidePanel('show',clickCallReportIndex);
        		}
        		$scope.selectedCallReport = this.storedCallReport[this.activatedCallReportIndex];
        	};
        	
        	$scope.modifySidePanel = function(_action,_index){
        		switch(_action) {
        			case 'hide':
        				//Change value of activated call report AFTER side-panel is hided
        				$scope.sidePanelContainer.on($scope.transitionTypes[$scope.transitionKey], function(_e){
        					$scope.activatedCallReportIndex = -1;
        					$(this).off(_e); //So that this event is only fired once
        				});
        				$scope.callReportsListContainer.removeClass('pan-left-25');
        				$scope.sidePanelContainer.addClass('panel-hide');
        				this.isSidePanelActivated = false;
        			break;
        			case 'show':
        				LogUtil.logDebug('CallReportMainCtrl -> show side panel');
            			$scope.activatedCallReportIndex = _index;
            			$scope.callReportsListContainer.addClass('pan-left-25');
            			$scope.sidePanelContainer.removeClass('panel-hide');
        				this.isSidePanelActivated = true;
            		break;
        		}
        	};
        	
        	// Prepare submit overlay     	
            $ionicModal.fromTemplateUrl('./app/callreport/templates/call_report_save_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
            
            // Hide submit overlay
            $scope.hideSubmitOverlay = function() {
            	console.log('hideSubmitOverlay');
                $scope.submitModal.hide();
                $state.go($state.current, {}, {reload: true});
            };
        	
        	$scope.submitCallReport = function(selectedCallReport) { 
        		LogUtil.logDebug('CallReportMainCtrl -> submitCallReport');        		
 				var submitCallReportSuccessCallback = function(data) { 	
 					LogUtil.logDebug('CallReportMainCtrl -> submitCallReport -> submitCallReportSuccessCallback');
 					$scope.deleteCallReportOnly(selectedCallReport.id);
 					busyIndicator.hide();
 		            $scope.submitModal.show();  
 				};	                         
 	            var submitCallReportFailureCallback = function(data) { 
 	            	busyIndicator.hide();
 	            	LogUtil.logDebug('CallReportMainCtrl -> submitCallReport -> submitCallReportFailureCallback');
	            	var errorMsg = '';
	            	if (data.errorCode){
	            		errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_ZPB_FAILURE')+data.errorCode;
	            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
	            	} else {
	            		WL.Device.getNetworkInfo(function(networkInfo) {
				  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
				  			LogUtil.logDebug('CallReportMainCtrl -> Network Info : '+networkInfo.isNetworkConnected);
				  			if (networkInfo.isNetworkConnected === 'false') {
				  				errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_NO_INTERNET_CONNECTION');
			            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
				  			}else{
				  				errorMsg = $translate.instant('ERR_SUBMIT_CALL_REPORT_MFP_CONNECTION_FAILURE');
				  				WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_CALL_REPORT_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
				  			}
	            		});	            		
	            	}	            	
 	            };       
 	            CallReportService.submitCallReport(selectedCallReport, submitCallReportSuccessCallback, submitCallReportFailureCallback);
 	            
 	            var auditLogInfo = {
               		userID : AppState.userID,
               		activity:'submit_call_report',
               		customerName : null,
               		accountName : null,
               		accountNumber : null
               };
               AuditLoggingUtil.insertAuditLogging(auditLogInfo);
        		
        	};
        	
        	$scope.goToCallReport = function() {
                LogUtil.logDebug('CallReportMainCtrl -> goToCallReport : id: '+this.selectedCallReport.id);
                var param = {
    			    	data: null,
    			    	source : 'call_report_creation',
    			    	callReport : angular.toJson(this.selectedCallReport)
    			    };    				
    			$state.go('base.call_report_creation', param, {reload: true});
        	};
        	
        	$scope.deleteCallReport = function(id){
        		LogUtil.logDebug('CallReportMainCtrl -> deleteCallReport - id: "' + id);
        		var _this = this;
        		CommonUtil.displayConfirmBox($translate.instant('CONF_DELETE_CALL_REPORT_TITLE'), 
        			$translate.instant('CONF_DELETE_CALL_REPORT'), 
        			$translate.instant('BTN_OK'), function() {
        				busyIndicator.show();
        				CallReportService.deleteCallReportByID(id,_this.deleteCallReportSuccessCallback,_this.deleteCallReportFailureCallback);
        				$scope.modifySidePanel('hide');
        			},
        			$translate.instant('BTN_CANCEL'), function() {
        				// do nothing. just dismiss the confirmation box
        			}
        		);
        	};
        	
        	$scope.deleteCallReportOnly = function(id){
        		var _this = this;
        		CallReportService.deleteCallReportByID(id,_this.deleteCallReportSuccessCallback,_this.deleteCallReportFailureCallback);
				$scope.modifySidePanel('hide');
        	};
        	
        	$scope.deleteCallReportSuccessCallback = function(result) {
            	LogUtil.logInfo('CallReportMainCtrl -> deleteCallReportSuccessCallback');
            	$scope.$apply(function() {
            		$scope.storedCallReport = result; 
            		busyIndicator.hide();
            	});            	
            };
            
            $scope.deleteCallReportFailureCallback = function(errObj) {
            	LogUtil.logInfo('CallReportMainCtrl -> deleteCallReportFailureCallback');
            	WL.SimpleDialog.show($translate.instant('ERR_DELETE_CALL_REPORT_FAILURE_TITLE'),$translate.instant('ERR_DELETE_CALL_REPORT_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
            	busyIndicator.hide();           	
            };
            
        	$scope.init();
        }]);
    
		app.directive('onCallReportsListed',['$timeout',function($timeout) {
	        return function($scope,element,attrs) {
	      	  $timeout(function(){
	      		$scope.callReportButtons = $(".button-call-report");
	      		$scope.callReportsLength = $scope.callReportButtons.length;
	      	  },0,false);
	        };
	    }]);
}) 
   