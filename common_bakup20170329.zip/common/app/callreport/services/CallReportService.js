define([
    'app/app',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/DataMaskingUtil',
    'app/callreport/data/CallReportDAO'
], function(app, LogUtil, CommonUtil, DataMaskingUtil, CallReportDAO) {
    'use strict';

    app.service('CallReportService', ['CallReportDAO', '$filter',
        function(CallReportDAO, $filter) {
            var callReportService = {};
            
            callReportService.addCallReport = function(reportData, successCallback, failureCallback) {
                LogUtil.logInfo('CallReportService: addCallReport');
                var daoSuccessCallback = function(id) {
                    LogUtil.logInfo('CallReportService : Add call report successfully with id = ' + id);
       			 	if (typeof successCallback === 'function') {
       			 		successCallback(id);
       			 	}
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('CallReportService : Call Report data cannot be save to local storage');
       			 	if (typeof failureCallback === 'function') {
       			 		failureCallback();
       			 	}
                };
                CallReportDAO.addCallReport(reportData, daoSuccessCallback, daoFailureCallback);
            };
            
            callReportService.updateCallReport = function(reportData, successCallback, failureCallback) {
            	LogUtil.logInfo('CallReportService : updateCallReport : update call report ID: ' + reportData.id);
                var daoSuccessCallback = function(data) {
                    LogUtil.logInfo('Save call report successfully');
       			 	if (typeof successCallback === 'function') {
       			 		successCallback(data);
       			 	}
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('Call report cannot be updated from local storage');
                    if (typeof failureCallback === 'function') {
                    	failureCallback(data);
                    }
                };
                CallReportDAO.updateCallReport(reportData, daoSuccessCallback, daoFailureCallback);
            };
            
            callReportService.submitCallReport = function(reportData, successCallback, failureCallback) {
            	 var daoSuccessCallback = function(data) {
            		 if (data) {
            			 LogUtil.logInfo('CallReportService : submitCallReport : daoSuccessCallback : JSON response is true');
            			 if (typeof successCallback === 'function') {
            				 successCallback(data);
            			 }
            		 } else {
            			 LogUtil.logError('CallReportService : submitCallReport : daoSuccessCallback : JSON response failed');
            			 if (typeof failureCallback === 'function') {
            				 failureCallback(data);
            			 }
            		 }
                 };               
                 var daoFailureCallback = function(data) {
                 	LogUtil.logError('CallReportService : submitCallReport : daoFailureCallback');
                 	if (typeof failureCallback === 'function') {
                 		failureCallback(data);   
                 	}
                 };
                 CallReportDAO.submitCallReport(reportData, daoSuccessCallback, daoFailureCallback);
            };
            
            callReportService.deleteCallReportByID = function(id, successCallback, failureCallback) {
                LogUtil.logInfo('CallReportService : Attempt to delete call report by ID: ' + id);
                var daoSuccessCallback = function(result) {
            		LogUtil.logInfo('CallReportService : Deleted call report successfully');           		
                	if (typeof successCallback === 'function') {
                		successCallback(result);
                	}
                };
                var daoFailureCallback = function(errObj) {
            		LogUtil.logInfo('CallReportService : Error while deleting call report');
                	if (typeof failureCallback === 'function') {
                		failureCallback(errObj);
                	}
                };
            	CallReportDAO.deleteCallReportByID(id, daoSuccessCallback, daoFailureCallback);
            };
            
            return callReportService;
        }
    ]);
});