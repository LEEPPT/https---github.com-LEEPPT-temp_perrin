define([
    'app/app',
    'js/Util/LogUtil',
    'app/portfolio/data/TargetPortfolioDAO'
], function(app, LogUtil, TargetPortfolioDAO) {
    'use strict';

    app.service('TargetPortfolioService', ['TargetPortfolioDAO',
        function(TargetPortfolioDAO) {
            var targetPortfolioService = {};
            
            targetPortfolioService.addTargetPortfolio = function(portfolioData, addPortfolioSuccessCallback,addPortfolioFailureCallback) {
                LogUtil.logInfo('addTargetPortfolio: ' + portfolioData);
                var daoSuccessCallback = function(id) {
                    LogUtil.logInfo('addTargetPortfolio target portfolio id = ' + id);
                    addPortfolioSuccessCallback(id);
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('Target portfolio data cannot be save to local storage');
                    addPortfolioFailureCallback();
                };

                TargetPortfolioDAO.addTargetPortfolio(portfolioData, daoSuccessCallback, daoFailureCallback);
            };
            targetPortfolioService.getTargetPortfolioByID = function(portfolioID, successCallback, failureCallback) {
                LogUtil.logInfo('get target portfolio by ID: ' + portfolioID);
                var daoSuccessCallback = function(data) {
                    LogUtil.logInfo('get target portfolio ID = ' + portfolioID);
                    successCallback(data);
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('Target portfolio data cannot be get from local storage');
                    failureCallback();
                };

                TargetPortfolioDAO.retrieveTargetPortfolioByID(portfolioID, daoSuccessCallback, daoFailureCallback);
            };
            targetPortfolioService.updateTargetPortfolio = function(data, successCallback, failureCallback) {
                LogUtil.logInfo('Updating target portfolio by ID: ' + data.id);
                var daoSuccessCallback = function() {
                    LogUtil.logInfo('Updated target portfolio successfully');
                    successCallback();
                };
                var daoFailureCallback = function() {
                    LogUtil.logError('Target portfolio data cannot be updated from local storage');
                    failureCallback();
                };
                TargetPortfolioDAO.updateTargetPortfolio(data, daoSuccessCallback, daoFailureCallback);
            };
            targetPortfolioService.deleteTargetPortfolioByID = function(id, successCallback, failureCallback) {
                LogUtil.logInfo('targetPortfolioService : Attempt to delete target portfolio by ID: ' + id);
                var daoSuccessCallback = function(result) {
            		LogUtil.logInfo('targetPortfolioService : Deleted target portfolio successfully');           		
                	if (typeof successCallback === 'function') {
                		successCallback(result);
                	}
                };
                var daoFailureCallback = function(errObj) {
            		LogUtil.logInfo('targetPortfolioService : Error while deleting target portfolio');

                	if (typeof failureCallback === 'function') {
                		failureCallback(errObj);
                	}
                };
            	TargetPortfolioDAO.deleteTargetPortfolioByID(id, daoSuccessCallback, daoFailureCallback);
            };
            targetPortfolioService.uploadTargetPortfolioPDF=function(targetPortfolioToSubmit,successCallback,failureCallback) {          	
                var daoSuccessCallback = function(data) {
                    if (data) {
                        LogUtil.logInfo('targetPortfolioService : uploadTargetPortfolioPDF : daoSuccessCallback : JSON response is true');
                        
                        successCallback(data); 
                    } else {
                    	LogUtil.logError('targetPortfolioService : uploadTargetPortfolioPDF : daoSuccessCallback : JSON response failed');
                    	failureCallback(data);  					
                    }
                };               
                var daoFailureCallback = function(data) {
                	LogUtil.logError('targetPortfolioService : uploadTargetPortfolioPDF : daoFailureCallback');
                	failureCallback(data);    
                };
                TargetPortfolioDAO.uploadTargetPortfolioPDF(targetPortfolioToSubmit,daoSuccessCallback, daoFailureCallback);
            };    
            return targetPortfolioService;
        }
    ]);
});