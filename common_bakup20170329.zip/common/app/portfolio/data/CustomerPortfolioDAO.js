define([
  'app/app',
  'js/Util/DataPersister',
  'js/Util/LogUtil',
  'js/appState',
  'js/Adapters/PortfolioAdapter'
], function (app,DataPersister,LogUtil,AppState,PortfolioAdapter) {
  'use strict';

  app.factory('CustomerPortfolioDAO', function(){
	  var dao = {};
	  var _data =[];
	  /*
	   * The following 3 functions are only called internally
	   */
	  var getJSONStoreData = function(successCallback, failureCallback) {
	      DataPersister.getAppDataByNameValue('storedPortfolio',successCallback,failureCallback);
	  };
	  var setJSONStoreData = function(data, successCB, failureCB) {
		  DataPersister.setAppDataByNameValue('storedPortfolio', data, successCB, failureCB);
	  };
	  var initJSONStore = function (successCallback, failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list for all portfolios');		  
		  getJSONStoreData(function(data){
	    	  if (typeof data === 'undefined' || data === null || data === "null") {
	    		data = [];  
	    		setJSONStoreData(data);
	    	  }
	    	  AppState.storedPortfolio = data;
	    	  successCallback(data);
	      }, function(errObj) {
	    	  failureCallback(errObj);
	      });
	  };  
	  /*
	   * Construct dao
	   */
	  dao.listAll = function(successCallback,failureCallback) {
		  LogUtil.logDebug('Attempt to retrieve list of all portfolios');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Successfully retrieved list of all portfolios');
			  AppState.storedPortfolio = result;
			  if (typeof successCallback === 'function') {
				  successCallback(result);
			  }
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed initialising JSONStore for portfolio: ['+errObj.err+']'+errObj.msg);

    		  if (typeof failureCallback === 'function') {
    			  failureCallback(result);
			  }
		  };
		  initJSONStore(invocationSuccessCallback, invocationFailureCallback);
	  };
	  dao.retrievePortfolio = function(id, successCallback, failureCallback) {
		  var portfolio = null;
		  
		  for (var i = 0 ; i < AppState.storedPortfolio.length ; i++) {
			  if (String(AppState.storedPortfolio[i].id) === id) {
				  portfolio = AppState.storedPortfolio[i];
			  }
		  }
		  
		  if (portfolio) {
			  LogUtil.logDebug('Found portfolio for id: '+id);
			  successCallback(portfolio);
		  } else {
			  LogUtil.logDebug('No stored portfolio in memory matched id: '+id);
			  failureCallback({msg: 'Cannot find target portfolio'});
		  }
	  };
	  dao.addPortfolio = function(data, successCallback, failureCallback) {
		  var now = Date.now();
		  var portfolio;
		  if (typeof data === 'object' && !Array.isArray(data)) {
			  portfolio = data;
			  portfolio.id = now;
			  portfolio.lastModifiedDate = now;
		  } else {
			  portfolio = {
				id : now,
				data : data,
				lastModifiedDate : now
			  }; 
		  }
		  
		  LogUtil.logDebug('Number of portfolio in memory BEFORE insert: '+AppState.storedPortfolio.length);
		  AppState.storedPortfolio.unshift(portfolio);
		  LogUtil.logDebug('Number of portfolio in memory AFTER insert: '+AppState.storedPortfolio.length);
		  LogUtil.logDebug('ID of inserted portfolio is '+portfolio.id);

		  LogUtil.logDebug('Attempt to insert portfolio to JSONStore');
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of portfolio in JSONStore AFTER insert: '+result.length);
			  AppState.storedPortfolio = result;
			  successCallback(portfolio.id);
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed inserting portfolio to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  setJSONStoreData(AppState.storedPortfolio,invocationSuccessCallback,invocationFailureCallback);
		  
		 
	  };
	  dao.deletePortfolio = function(id, successCallback, failureCallback) {
		  var index = -1;
		  for (var i = 0 ; i < AppState.storedPortfolio.length ; i++) {
			  if (Number(AppState.storedPortfolio[i].id) === Number(id)) {
				  index = i;
			  }
		  }
		  if (index > -1) {
    		  LogUtil.logDebug('Number of stored portfolio in memory BEFORE deletion: '+AppState.storedPortfolio.length);
			  AppState.storedPortfolio.splice(index,1);			  
    		  LogUtil.logDebug('Number of stored portfolio in memory AFTER deletion: '+AppState.storedPortfolio.length);
    		  
			  var invocationSuccessCallback = function(result) {
				  LogUtil.logDebug('Number of portfolio in JSONStore AFTER deletion: '+result.length);
				  AppState.storedPortfolio = result;
				  successCallback(result);
			  };
			  var invocationFailureCallback = function(errObj) {
	    		  LogUtil.logError('Failed deleting portfolio in JSONStore: ['+errObj.err+']'+errObj.msg);
	    		  failureCallback(errObj);
			  };
			  setJSONStoreData(AppState.storedPortfolio, invocationSuccessCallback,invocationFailureCallback);
		  } else {
    		  LogUtil.logDebug('No portfolio is deleted because if no stored portfolio matching id: '+id);
			  failureCallback({msg : 'Cannot find target portfolio'});
		  }
	  };
	  
	  dao.updatePortfolio = function(data, successCallback, failureCallback) {
		  var id = data.id;
		  data.lastModifiedDate = Date.now();
		  LogUtil.logDebug('updatePortfolio id: '+id);
		  for (var i = 0 ; i < AppState.storedPortfolio.length ; i++) {
			  if (AppState.storedPortfolio[i].id === id) {
				  AppState.storedPortfolio[i] = data;
			  }
		  }
		  LogUtil.logDebug(AppState.storedPortfolio);
		  var invocationSuccessCallback = function(result) {
			  LogUtil.logDebug('Number of portfolio in JSONStore AFTER insert: '+result.length);
			  successCallback(data);
		  };
		  var invocationFailureCallback = function(errObj) {
    		  LogUtil.logError('Failed updating portfolio to JSONStore: ['+errObj+']');
    		  failureCallback(errObj);
		  };
		  
		  setJSONStoreData(AppState.storedPortfolio, invocationSuccessCallback, invocationFailureCallback);
	  };
	  dao.getCustomerPortfolio = function(customerInfo,successCallback,failureCallback) {
		  	var adapterSuccessCallback = function(result) {
                if (result && result.responseJSON && result.responseJSON.isSuccessful) {
                    LogUtil.logInfo('CustomerPortfolioDAO : getCustomerPortfolio : adapterSuccessCallback : isSuccessful in JSON response is true');
					successCallback(result);
				} else {
                    LogUtil.logError('CustomerPortfolioDAO : getCustomerPortfolio : adapterSuccessCallback : isSuccessful in JSON response is false');
					failureCallback(result);
				}
			};
			var adapterFailureCallback = function(data) {
                LogUtil.logError('CustomerPortfolioDAO : getCustomerPortfolio : adapterFailureCallback : Fail to invoke PortfolioAdapter');
				failureCallback(data);
			};
			PortfolioAdapter.getCustomerPortfolio(customerInfo,adapterSuccessCallback, adapterFailureCallback);
	  };
	  return dao;
  });
});
