define([
    'app/app',
    'js/appState',
    'app/portfolio/services/CustomerPortfolioService',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
	'js/constants',
    'js/appConfig',
    'js/Util/FunctionActivator'
], function(app, AppState, CustomerPortfolioService, LogUtil, CommonUtil,Constants, AppConfig, FunctionActivator) {
    'use strict';

    app.controller('CustomerPortfoliosCtrl', [
        '$scope',
        '$translate',
        '$filter',
        '$state',
        'CustomerPortfolioService',
        '$ionicModal',
        function($scope, $translate, $filter, $state, CustomerPortfolioService, $ionicModal) {
        	$scope.init = function() {           	
        		$scope.activatedPortfolioIndex = -1;
        		$scope.isSidePanelActivated = false;
            	$scope.portfoliosLength = 0;
            	$scope.selectedBenchmark = {};
                LogUtil.logDebug('CustomerPortfoliosCtrl -> init: storedPortfolios');
                var storedPortfolios = AppState.storedPortfolio;
                for (var i = 0; storedPortfolios && i < storedPortfolios.length; i++) {
                	if (storedPortfolios[i].lastModifiedDate) {
                		storedPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedPortfolios[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
                        LogUtil.logDebug('CustomerPortfoliosCtrl -> init: displayDate From LastModifiedDate: ' + storedPortfolios[i].displayDate);
                	}else {
                		storedPortfolios[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedPortfolios[i].id),'dd MMM yyyy, HH:mm'), true);
                        LogUtil.logDebug('CustomerPortfoliosCtrl -> init: displayDate From id: ' + storedPortfolios[i].displayDate);
                	}
                }
                $scope.storedPortfolios = AppState.storedPortfolio;
                $scope.languageCode = AppState.currentLangCode;
    			$scope.isAccessibleToFNPortfolioCreation = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORFOLIO_CREATION);
        	};
        	$scope.getPortfolio = function() {
        		return this.storedPortfolios[this.activatedPortfolioIndex];
        	};
        	$scope.deletePortfolio = function(id,index) {
        		var _this = this;
        		LogUtil.logDebug('CustomerPortfoliosCtrl -> deletePortfolio : id:'+id);
        		LogUtil.logDebug('CustomerPortfoliosCtrl -> deletePortfolio : index:'+index);
        		CommonUtil.displayConfirmBox($translate.instant('CONF_DELETE_CUSTOMER_PORTFOLIO_TITLE'), 
                	$translate.instant('CONF_DELETE_CUSTOMER_PORTFOLIO'), 
                	$translate.instant('BTN_OK'), function() {
        				busyIndicator.show();
            			CustomerPortfolioService.deleteCustomerPortfolioByID(id, $scope.deletePortfolioSuccessCallback,$scope.deletePortfolioFailureCallback);
                	},
                	$translate.instant('BTN_CANCEL'), function() {
                		// do nothing. just dismiss the confirmation box
                	}
                );
        	};
        	$scope.deletePortfolioSuccessCallback = function(result) {
        		LogUtil.logDebug('CustomerPortfolioCtrl -> deletePortfolioSuccessCallback');
        		$scope.$apply(function() {
        			$scope.storedPortfolios =  result;
        			busyIndicator.hide();
        		});
        	};
        	$scope.deletePortfolioFailureCallback = function(errObj) {
        		LogUtil.logError('CustomerPortfolioCtrl -> deletePortfolioFailureCallback');
        		WL.SimpleDialog.show($translate.instant('ERR_DELETE_CUSTOMER_PORTFOLIO_FAILURE_TITLE'),$translate.instant('ERR_DELETE_CUSTOMER_PORTFOLIO_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
        		busyIndicator.hide();
        	};
        	$scope.updatePortfolioSuccessCallback = function(result) {
        		LogUtil.logDebug('CustomerPortfolioCtrl -> updatePortfolioSuccessCallback');
        		$scope.$apply(function() {
        			$scope.storedPortfolios[$scope.activatedPortfolioIndex] = result;
        			busyIndicator.hide();
        			$scope.settingsModal.hide();
        		});
        	};
        	$scope.updatePortfolioFailureCallback = function(errObj) {
        		LogUtil.logError('CustomerPortfolioCtrl -> updatePortfolioFailureCallback');
        		WL.SimpleDialog.show($translate.instant('ERR_UPDATE_CUSTOMER_PORTFOLIO_FAILURE_TITLE'),$translate.instant('ERR_UPDATE_CUSTOMER_PORTFOLIO_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
        		busyIndicator.hide();
        		$scope.settingsModal.hide();
        	};
        	$scope.goToPortfolio = function(id) {
        		var portfolioID;
        		if (typeof id === 'undefined' || !id) {
        			portfolioID = this.getPortfolio().id;
        		} else {
        			portfolioID = id;
        		}
                LogUtil.logDebug('CustomerPortfoliosCtrl -> goToPortfolio - id: '+portfolioID);
        		 $state.go('base.portfolio_cover', {
                     id: portfolioID
                 }, {
                     reload: true
                 });
        	};
        	$scope.isPortfolioCreationAllowed = function() {
         		return ($scope.storedPortfolios.length < AppConfig.systemParam.configMap.get('i_pfDlLimit') && $scope.isAccessibleToFNPortfolioCreation);
         	};
         	
         	// Prepare submit overlay     	
            $ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_settings.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.settingsModal = modal;
        	});
            
            $scope.showSettingsOverlay = function(id, index) {
            	$scope.activatedPortfolioIndex = index;
            	$scope.tempPortfolios = jQuery.extend(true, {}, this.storedPortfolios[this.activatedPortfolioIndex]);
            	$scope.settingsModal.show();           
            }
            
            $scope.hideSettingsOverlay = function() {
            	$scope.settingsModal.hide();
            	$state.go($state.current, {}, {reload: true});
            }
            
            $scope.saveSettings = function() {
            	CustomerPortfolioService.updateCustomerPortfolioByID($scope.tempPortfolios, $scope.updatePortfolioSuccessCallback, $scope.updatePortfolioFailureCallback);
            };
         	
        	$scope.init();
        }
    ]);
    
    app.directive('onCustPortfoliosListed',['$timeout',function($timeout) {
        return function($scope,element,attrs) {
      	  $timeout(function(){
      		$scope.portfolioButtons = $(".button-customer-portfolio");
      		$scope.portfoliosLength = $scope.portfolioButtons.length;
      	  },0,false);
        };
      }]);
});