define([
  'app/app',
  'app/portfolio/services/CustomerPortfolioService',
  'js/Util/ChartGenerator',
  'js/Util/LogUtil',
  'js/Util/CommonUtil',
  'js/appConfig',
  'js/appState',
  'js/constants',
  'js/Util/FunctionActivator'
], function (app, CustomerPortfolioService, ChartGenerator, LogUtil, CommonUtil, AppConfig, AppState, Constants, FunctionActivator) {
  'use strict';

  app.controller('PortfolioPerformanceCtrl', [
	'$scope',
    'CustomerPortfolioService',
    '$translate',
    '$stateParams',
    '$filter',
    '$ionicModal',
    '$state',
    '$ionicSideMenuDelegate',
    '$ionicScrollDelegate',
    function ($scope, CustomerPortfolioService, $translate, $stateParams, $filter, $ionicModal, $state,$ionicSideMenuDelegate, $ionicScrollDelegate) {		
		$scope.init = function() {
			$scope.data = angular.fromJson($stateParams.data);
    		$scope.portfolioName = $scope.data.portfolioName;
    		$scope.currency = $translate.instant($scope.data.portfolioCurrency);
            $scope.isAccessibleToFNPortfolioHistory = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HISTORY);
            $scope.ct = {};
    		$scope.dataDisplayViewIndex = 'FromLastSixMonth';
    		$scope.currentAUM = '0.00';
    		$scope.netCapitalInOutValue = '0.00';
    		$scope.isShowSpecialMonth = false;
    		$scope.specialNetChangeValueArrowFlag = 0;
			$scope.currentSpecialMonth = 0;
			$scope.interpolateCNT = 0;
			$scope.displayBenchmark = false;
			$scope.displayBenchmarkLine = false;
			$scope.ts = 0;
			$scope.isSwitchWithSpecialMonth = false;
    		if ($scope.data.performanceAnalysis !== null && $scope.data.performanceAnalysis.detailsList !== null && $scope.data.performanceAnalysis.detailsList.length > 0) {
    			$scope.currentYear = $scope.data.performanceAnalysis.detailsList[0].year;
    			$scope.netCapitalInOutValueFromYrBegin = $filter("number")($scope.data.performanceAnalysis.netCapitalInOutValueFromYrBegin, 2);
    			$scope.netCapitalInOutValueFromLastSixMonth = $filter("number")($scope.data.performanceAnalysis.netCapitalInOutValueFromLastSixMonth, 2);
    			$scope.currentAUM = $filter("number")($scope.data.performanceAnalysis.detailsList[0].toAUM, 2);
    			$scope.currentMonthEnd = CommonUtil.getDateTimeString($filter("date")(new Date($scope.data.performanceAnalysis.detailsList[0].toDate),'dd MMM yyyy'), false);
    			
    			$scope.yearBeginDate = CommonUtil.getDateTimeString($filter("date")(new Date($scope.data.performanceAnalysis.yearBeginDate),'dd MMM yyyy'));
    			$scope.lastSixMonthBeginDate = CommonUtil.getDateTimeString($filter("date")(new Date($scope.data.performanceAnalysis.lastSixMonthBeginDate),'dd MMM yyyy'));
    			if($scope.dataDisplayViewIndex === 'FromLastSixMonth') {
    				$scope.netCapitalInOutFromDate = $scope.lastSixMonthBeginDate;
    				$scope.netCapitalInOutValue = $scope.netCapitalInOutValueFromLastSixMonth;
    			} else {
    				$scope.netCapitalInOutFromDate = $scope.yearBeginDate;
    				$scope.netCapitalInOutValue = $scope.netCapitalInOutValueFromYrBegin;
    			}
    			$scope.netCapitalInOutToDate = $scope.currentMonthEnd;
    		}
    		$scope.displayCumulativeReturn($scope.data, false);
			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);
			$scope.languageCode = AppState.currentLangCode;
		};
		 $scope.changeBar = function(ts) {
			 $scope.ts = ts;
			 var date = $scope.formatUnixTS(ts);
			 var selectedMonth = Number((""+date).substring(4,6));
			 var i;
			 if ($scope.isInterpolatedData(selectedMonth) || ($scope.currentSpecialMonth === selectedMonth && $scope.isShowSpecialMonth === true)) {
				 for(i=0; i < $scope.cumulativeReturnChartData[1].values.length; i++) {
			 		$scope.cumulativeReturnChartData[1].values[i].color = "#AA834F";
			 	 }
				 $scope.currentSpecialMonth = 0;
				 $scope.showSpecialMonth($scope.currentSpecialMonth);
				 $scope.highlightAxis(0);
			 } else {
				for(i=0; i<$scope.cumulativeReturnChartData[1].values.length; i++) {
	 				if(ts === $scope.cumulativeReturnChartData[1].values[i].x) {
		 				$scope.cumulativeReturnChartData[1].values[i].color = "#AA834F";
		 			} else {
		 				$scope.cumulativeReturnChartData[1].values[i].color = "#919191";
		 			}
			 	}
				$scope.showSpecialMonth(selectedMonth);
				$scope.currentSpecialMonth = selectedMonth;
				$scope.highlightAxis(ChartGenerator.axisMonthYearFormatter2(date));
			 }
			 $scope.cumulativeReturnChartOption.chart.duration = 0;
			 $scope.ct.api.refresh();
			 $scope.$apply();
			 $scope.bindClickToAxis();
         };
         $scope.highlightAxis = function(xAixsName) {
         	var labelAxis = $("nvd3[options=cumulativeReturnChartOption] svg g text:not(.nv-axislabel)");
         	labelAxis.removeClass("axisStyleBold");
         	labelAxis.toArray().forEach(function(item){
 				if (item.innerHTML === xAixsName) {
 					$(item).addClass("axisStyleBold");
 				}
         	});
 		};
		
		// add by MaiJB
		$scope.displayCumulativeReturn = function(data, fromYearBegin) {
			var option = $scope.getCRChartOptions();
			var ChartColorSets = ['#AA834F', '#CEAA84'];
			var xScaleBars;
			
		 	$scope.cumulativeReturnChartData  = $scope.generateData(data, fromYearBegin);
		 	
		 	var xTicks = $scope.cumulativeReturnChartData[0].values.map(function(item){
		 		return item.x;
		 	});
		 	
		 	if ($scope.isSwitchWithSpecialMonth){
		 		$scope.isSwitchWithSpecialMonth = false;
				for(var i=0; i<$scope.cumulativeReturnChartData[1].values.length; i++) {
	 				if($scope.ts === $scope.cumulativeReturnChartData[1].values[i].x) {
		 				$scope.cumulativeReturnChartData[1].values[i].color = "#AA834F";
		 			} else {
		 				$scope.cumulativeReturnChartData[1].values[i].color = "#919191";
		 			}
			 	}
		 	}
			
		 	option.chart.xAxis.tickValues = xTicks;
            option.chart.yDomain1 = [($scope.minRange < 0 ? $scope.minRange : 0), ($scope.maxRange < 0 ? 0 : $scope.maxRange)];

            if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
            	option.chart.xAxis.tickFormat= function(ts) {
    				var date = $scope.formatUnixTS(ts);
    				return ChartGenerator.axisMonthYearFormatter2MonthOnly(date);
    			};
            } else {
            	option.chart.xAxis.tickFormat = function(ts) {
    				var date = $scope.formatUnixTS(ts);
    				return ChartGenerator.axisMonthYearFormatter2(date);
    			};
            }
            
            $scope.cumulativeReturnChartOption = option;
            $scope.hideInterpolatedDataOnChart();

            function convertData(str) {
		 		var data = str.split('-');
		 		if(data[0] === null || data[1] === null) {
		 			return str;
		 		}
		 		if(data[1].length === 1) {
		 			data[1] = '0'+data[1];
		 		}
		 		return Number(data[0] + data[1]);
		 	}
		};
		$scope.convertDateToUnixTS = function(str) {
			return Date.parse(str)/1000;
		};
        $scope.interpolateDataFromYearBegin = function(arr) {
        	var item = arr[0];
 			var month = Number(item.month);
 			var year = Number(item.year);
 			var cnt = 0;
			while (month < 12) {
				var entry = {
 		 				monthlyReturnPercent : 0,
 	                    yearReturnPercent : 0,
 	                    yearToLastSixMonthReturnPercent : 0,
 	                    benchmarkPercent: 0,
 	                    benchmarkDisplayPercent: 0
 		 			};
				if (month === 12) {
 					year += 1;
 					month = 1;
 				} else {
 					month += 1;
 				}
				entry.month = month;
				entry.year = year;
				entry.fromDate = year+"-"+(month < 10 ? "0"+month : month)+"-01";
				arr = [entry].concat(arr);
				cnt++;
			}
			$scope.interpolateCNT = cnt;
			return arr;
        };
        $scope.interpolateDataLastSixMonth = function(arr) {
        	var item = arr[arr.length-1];
 			var month = Number(item.month);
 			var year = Number(item.year);
 			var cnt = 0;
			while (arr.length < 6) {
                var entry = {
	 				monthlyReturnPercent : 0,
                    yearReturnPercent : 0,
                    yearToLastSixMonthReturnPercent : 0,
	                benchmarkPercent: 0,
	                benchmarkDisplayPercent: 0
	 			};
 				if (month === 1) {
 					year -= 1;
 					month = 12;
 				} else {
 					month -= 1;
 				}
 				entry.month = month;
 				entry.year = year;
                entry.fromDate = year+"-"+(month < 10 ? "0"+month : month)+"-01";
 				arr.push(entry);
 			}
			for (var i in arr) {
				item = arr[i];
				if (item.monthlyReturnPercent === 0 && item.yearReturnPercent === 0 && item.yearToLastSixMonthReturnPercent === 0) { cnt++; }
			}
			$scope.interpolateCNT = cnt;
			return arr;
        };
		$scope.generateData = function(data, fromYearBegin){
	 		var performanceData;

	 		if (data.performanceAnalysis !== null && data.performanceAnalysis.detailsList !== null && data.performanceAnalysis.detailsList.length > 0) {
		 		var selectedMonthData = [];
		 		if (fromYearBegin === true) {
		 			selectedMonthData = $scope.interpolateDataFromYearBegin(data.performanceAnalysis.detailsList);
		 		} else {
		 			selectedMonthData = data.performanceAnalysis.detailsList.slice(0,6);
		 		}
	            if (selectedMonthData !== null && selectedMonthData.length > 0) {
	            	performanceData = $scope.prepareLineBarChartData(selectedMonthData, fromYearBegin);
	            }
		 	}
            var chartData = [{"key":"YTM",
            				"values":performanceData.lineData,
            				"color": "#3FA9F5"
            				}, 
				            {"key":"Monthly",
				            "values":performanceData.barData,
				            "color": "#AA834F"         
				            }];

            chartData[0].type = "line";
            chartData[0].yAxis = 1;
            chartData[1].type = "bar";
            chartData[1].yAxis = 1;
            
            if ($scope.displayBenchmarkLine) {
            	chartData.push({
            		"key":"Benchmark",
				    "values":performanceData.areaData,
				    "color": "#FFA85C",
				    "area": true
            	});
                chartData[2].type = "line";
                chartData[2].yAxis = 1;            	
            }
            
            return chartData;
        };
        $scope.prepareLineBarChartData = function(selectedMonthData, fromYearBegin) {
	 		var performanceData = {
					lineData:[],
					barData:[],
					areaData:[]
				};
	 		var year, maxRange = 0 , minRange = Number.MAX_VALUE;
        	for (var i = selectedMonthData.length - 1; i >= 0; i--) {
            	var monthData = selectedMonthData[i];
            	
    			if (!$scope.benchmarkDataDisplayViewIndex && undefined !== $scope.data.benchmarkConfig && null !== $scope.data.benchmarkConfig && $scope.data.benchmarkConfig.length > 0) {
    				for (var j = 0; j < $scope.data.benchmarkConfig.length; j++) {
    					if ($scope.data.benchmarkConfig[j].display) {
    						//$scope.benchmarkDataDisplayViewIndex = $scope.data.benchmarkConfig[j].id; // use first available benchmark data
    						$scope.displayBenchmark = true;
    						break;
    					}
    				}
    			} else {
    				monthData.benchmarkPercent = 0;
    			}
            	
            	if ($scope.benchmarkDataDisplayViewIndex) {
        			var selectedBenchmarkList = $filter('filter')(monthData.benchmarkList, {id : $scope.benchmarkDataDisplayViewIndex});
        			if (undefined != selectedBenchmarkList && null != selectedBenchmarkList & selectedBenchmarkList.length > 0) {
            			monthData.benchmarkPercent = selectedBenchmarkList[0].percentage;
                    	monthData.benchmarkDisplayPercent = $filter('number')(selectedBenchmarkList[0].percentage) + '%';
        			} else {
        				monthData.benchmarkPercent = 0;
        				monthData.benchmarkDisplayPercent = 'N/A';
        			}
            	}
    			
            	if (fromYearBegin === true) {
            		if (Number(monthData.month) === 1 ) {
            			year = Number(monthData.year);
            			$scope.compareMaxMinRange(monthData, ['monthlyReturnPercent', 'yearReturnPercent', 'benchmarkPercent']);
                		performanceData.barData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.monthlyReturnPercent), index : i});
               			performanceData.lineData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.yearReturnPercent), index : i});
               			performanceData.areaData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.benchmarkPercent), index : i});
            		} else if(year === Number(monthData.year)) {
            			$scope.compareMaxMinRange(monthData, ['monthlyReturnPercent', 'yearReturnPercent', 'benchmarkPercent']);
               			performanceData.barData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.monthlyReturnPercent), index : i});
               			performanceData.lineData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.yearReturnPercent), index : i});
               			performanceData.areaData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.benchmarkPercent), index : i});
            		}
            	} else {
        			$scope.compareMaxMinRange(monthData, ['monthlyReturnPercent', 'yearToLastSixMonthReturnPercent', 'benchmarkPercent']);
           			performanceData.barData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.monthlyReturnPercent), index : i});
           			performanceData.lineData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.yearToLastSixMonthReturnPercent), index : i});
           			performanceData.areaData.push({x : $scope.convertDateToUnixTS(monthData.fromDate) , y : Number(monthData.benchmarkPercent), index : i});
            	}
            }
	 		return performanceData;
        };
		$scope.alignBarAndXAixs = function (chart) {
			var container = d3.select('#cumulativeReturnChart svg');
			var availableWidth = nv.utils.availableWidth($scope.cumulativeReturnChartOption.chart.width, container,  $scope.cumulativeReturnChartOption.chart.margin),
				availableHeight = nv.utils.availableHeight($scope.cumulativeReturnChartOption.chart.height, container, $scope.cumulativeReturnChartOption.chart.margin);

			var xScaleBars = d3.scale.ordinal()
			.domain(d3.range($scope.cumulativeReturnChartData[1].values.length))
			.rangeRoundBands([0, availableWidth], 0.35);
			
			var rbcOffset = xScaleBars.rangeBand();
			d3.select("#cumulativeReturnChart .multiChart .nv-axis")
			.attr('transform',
			'translate(' + rbcOffset + ', ' + availableHeight + ') ' +
			'scale(' + ((availableWidth - rbcOffset*2)/availableWidth) + ', 1)');		
		};
		$scope.createSecondAxis = function(base, change){
			var initialIndex = base / (1+change);
            var yAxisGroup = d3.selectAll('g.nv-y1 g.tick').each(function(){
            	var temp = d3.select(this).select('text');
            	d3.select(this).insert('text')
            	.attr("id","secondAxis")
            	.attr("x", 690)
                .attr("y", 0)
                .attr("dy", ".32em")
            	.attr("style", "text-anchor: end;")
            	.text(Math.round(initialIndex * (1 + (temp[0][0].__data__/100))));
            });
		}
		$scope.bindClickToAxis = function() {
        	//.style is required for click event to work
            d3.selectAll('g.nv-axis.nv-x g.tick')
            	.style("pointer-events", "visiblePainted") 
                .on('click',function(e) {
                	var date = e.data ? e.data.x : e;
                    var month = $scope.formatUnixTS(date).substr(4,5);
                    if (!$scope.isInterpolatedData(month)) { $scope.changeBar(date); }
            });
            $scope.hideInterpolatedDataOnChart();
        };
        $scope.getCRChartOptions = function() {
        	var option = ChartGenerator.createMutilChartOption();
			option.chart.height = 350;
			option.chart.margin = {top: 30, right: 30, bottom: 50, left: 60};

			option.chart.yAxis1.tickFormat = ChartGenerator.axisPercentFormater;
		 	option.chart.bars1.dispatch = {
		 		elementClick : function (e) {
			 		$scope.changeBar(e.data.x);
		 		},
		 		renderEnd : function () {
		 			$scope.bindClickToAxis();
		 		}
		 	};

			option.chart.bars1.groupSpacing = 0.35;
			option.chart.lines1.clipEdge = false;
			option.chart.lines1.padData = true; 
		 	option.chart.useInteractiveGuideline = false;
			option.chart.callback = $scope.alignBarAndXAixs;
			return option;
        };
		$scope.switchShowData = function(toBeShow){
			if ($scope.dataDisplayViewIndex === toBeShow) {
				return;
			}

			$scope.dataDisplayViewIndex = toBeShow;
			$scope.isShowSpecialMonth = false;
			$scope.currentSpecialMonth = 0;
			if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
				if ($scope.data.performanceAnalysis !== null && $scope.data.performanceAnalysis.detailsList !== null && $scope.data.performanceAnalysis.detailsList.length > 0) {
	    			$scope.netCapitalInOutValue = $scope.netCapitalInOutValueFromYrBegin;
	    			$scope.netCapitalInOutFromDate = $scope.yearBeginDate;
	    			
	    			$scope.displayCumulativeReturn($scope.data, true);
	    		}
			} else {
				if ($scope.data.performanceAnalysis !== null && $scope.data.performanceAnalysis.detailsList !== null && $scope.data.performanceAnalysis.detailsList.length > 0) {
	    			$scope.netCapitalInOutValue = $scope.netCapitalInOutValueFromLastSixMonth;
	    			$scope.netCapitalInOutFromDate = $scope.lastSixMonthBeginDate;
	    			
	    			$scope.displayCumulativeReturn($scope.data, false);
	    		}
			}
		};
		$scope.switchShowBenchmarkData = function(benchmarkID) {
			if ($scope.isShowSpecialMonth){
				$scope.isSwitchWithSpecialMonth = true;
			}
			
			if ($scope.benchmarkDataDisplayViewIndex === benchmarkID) {
				$scope.displayBenchmarkLine = !$scope.displayBenchmarkLine;
				$scope.benchmarkDataDisplayViewIndex = -$scope.benchmarkDataDisplayViewIndex;
				if ($scope.dataDisplayViewIndex === 'FromLastSixMonth') {
					$scope.displayCumulativeReturn($scope.data, false);
				} else {
					$scope.displayCumulativeReturn($scope.data, true);
				}
				$scope.ct.api.refresh();
				return;
			}

			$scope.displayBenchmarkLine = true;
			$scope.benchmarkDataDisplayViewIndex = benchmarkID;
			
			if ($scope.dataDisplayViewIndex === 'FromLastSixMonth') {
				$scope.displayCumulativeReturn($scope.data, false);
			} else {
				$scope.displayCumulativeReturn($scope.data, true);
			}
			$scope.ct.api.refresh();
			if ($scope.isShowSpecialMonth){
				var selectedMonthData;
				for(var i=0; i<$scope.data.performanceAnalysis.detailsList.length; i++) {
					if ($scope.data.performanceAnalysis.detailsList[i].month === $scope.currentSpecialMonth) {
						selectedMonthData = $scope.data.performanceAnalysis.detailsList[i];
					}
				}
				$scope.specialBenchmarkValue = selectedMonthData.benchmarkDisplayPercent;
			}
		};
		
		$scope.showSpecialMonth = function(selectedMonth){
			LogUtil.logInfo("selected Month " + selectedMonth);
			LogUtil.logInfo("current Month " + $scope.currentSpecialMonth);
			
			if ($scope.isInterpolatedData(selectedMonth) || ($scope.currentSpecialMonth === selectedMonth && $scope.isShowSpecialMonth === true)) {
				$scope.hiddenSpecialMonth();
				return;
			}
			
			$scope.isShowSpecialMonth = true;
			if ($scope.data.performanceAnalysis !== null && $scope.data.performanceAnalysis.detailsList !== null && $scope.data.performanceAnalysis.detailsList.length > 0) {
				var selectedMonthData = null;
				for(var i=0; i<$scope.data.performanceAnalysis.detailsList.length; i++) {
					if ($scope.data.performanceAnalysis.detailsList[i].month === selectedMonth) {
						selectedMonthData = $scope.data.performanceAnalysis.detailsList[i];
					}
				}
				if (selectedMonthData !== null) {
					$scope.formatForSpecial(selectedMonthData);
				}
			}
		};
		$scope.formatForSpecial = function (selectedMonthData) {
			$scope.specialAUM = $filter("number")(selectedMonthData.toAUM, 2);
			$scope.specialMonthEnd = CommonUtil.getDateTimeString($filter("date")(new Date(selectedMonthData.toDate),'dd MMM yyyy'), false);
			$scope.specialNetCapitalInOutFromDate = CommonUtil.getDateTimeString($filter("date")(new Date(selectedMonthData.fromDate),'dd MMM yyyy'), false);
			$scope.specialNetCapitalInOutToDate = CommonUtil.getDateTimeString($filter("date")(new Date(selectedMonthData.toDate),'dd MMM yyyy'), false);
			$scope.specialNetCapitalInOutValue = $filter("number")(selectedMonthData.netCapitalInOutValue, 2);
			$scope.specialNetChangeValue = $filter("number")(selectedMonthData.netChangeInPortfolioValue, 2);
			if (selectedMonthData.netChangeInPortfolioValue > 0) {
				$scope.specialNetChangeValueArrowFlag = 1;
			} else if (selectedMonthData.netChangeInPortfolioValue < 0) {
				$scope.specialNetChangeValueArrowFlag = -1;
			} else {
				$scope.specialNetChangeValueArrowFlag = 0;
			}
			$scope.specialMonthEnd_Return = CommonUtil.translateMonthYearString($filter("date")(new Date(selectedMonthData.toDate),'MMM yyyy'));
			$scope.specialMonthlyReturnValue = selectedMonthData.monthlyReturnPercent === null ? 'N/A' : $filter('number')(selectedMonthData.monthlyReturnPercent, 2) + '%';
			if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
				$scope.specialYTMReturnValue = selectedMonthData.yearReturnPercent === null ? 'N/A' : $filter('number')(selectedMonthData.yearReturnPercent, 2) + '%';
			} else {
				$scope.specialYTMReturnValue = selectedMonthData.yearToLastSixMonthReturnPercent === null ? 'N/A' : $filter('number')(selectedMonthData.yearToLastSixMonthReturnPercent, 2) + '%';
			}
			$scope.specialBenchmarkValue = selectedMonthData.benchmarkDisplayPercent;
		};
		$scope.hiddenSpecialMonth = function() {
			$scope.isShowSpecialMonth = false;
		};
		
		$scope.goAssetHistory = function(){
			var param = {
	    			data: angular.toJson($scope.data)
	    		};
			$state.go('base.portfolio_history', param, {reload: true});
		};
		$scope.formatUnixTS = function(ts) {
			var date = new Date(ts*1000);
			var year = date.getFullYear().toString();
			var month = Number(date.getMonth())+1;
			month = (Number(month) < 10 ? "0" : "") + month.toString();
			
			return year+month;
		};
		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
    		scope : $scope
    	}).then(function(modal){
    		$scope.disclaimerModal = modal;
    	});
		$scope.showDisclaimer = function() {
    		$scope.disclaimerModal.show();
    	};
    	$scope.hideDisclaimer = function() {
    		$scope.disclaimerModal.hide();
    	};
    	$scope.onReady = function(scope, el){
    		$scope.currentChart = scope.chart;
    	};
    	$scope.hideInterpolatedDataOnChart = function() {
    		if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
    			$scope.hideInterpolatedLine();
        		$scope.hideInterpolatedPoints();
        		$scope.hideInterpolatedBars();
        		$scope.hideInterpolatedArea();
    		}
    	};
    	$scope.hideInterpolatedLine = function() {
    		var entireYearPointsX = ["30.387525620122602", "86.11584971600062", "138.24870307147512", "193.97706047365833", "247.90763100720025", "303.635940462911", "357.56650059892803", "413.2947816494617", "469.0230733622098", "522.9537152391729", "578.68197199679", "632.6125527843708"];
    		var last6MonthPointsX = ["60.77507674865564", "166.94172331995773", "276.6472889056302", "382.8138932990207", "492.51944460858317", "602.2250103891431"];
    		setTimeout(function() {
                //Set up a clip-path and make interpolated line outside the clip
                var interpolateCNT = $scope.interpolateCNT;
                var anchor , x , width;
                $('nvd3 path.nv-line').css('clip-path','url(#clippy)');
                if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
                	// entire year
                    anchor = entireYearPointsX[11-interpolateCNT];
                	x = 0;
                	width = Number(anchor);
                } else {
                	// last 6 months
                    anchor = last6MonthPointsX[interpolateCNT];
                	x = Number(anchor);
                	width = 620;
                }
                d3.select('#clippy').remove();
                d3.select(".nvd3.nv-wrap.nv-line > defs").append("clipPath")
                    .attr("id","clippy")
                    .append("rect")
                        .attr("x", x)
                        .attr("y", 0)
                        .attr("height",280)
                        .attr("width", width)
                        .attr("style","fill:#000");
                },0);
    	};
    	$scope.hideInterpolatedPoints = function() {
    		setTimeout(function(){
            	var points = $("#cumulativeReturnChart > svg .lines1Wrap .nvd3-svg g.nv-group.nv-series-0 path");
            	var cnt = 0;
            	if (points.length < $scope.interpolateCNT) {
            		return;
            	}
            	while  (cnt < $scope.interpolateCNT) {
            		var index = ($scope.dataDisplayViewIndex === 'FromYearBegin') ? 11-cnt : cnt ;
            		$(points[index]).remove();
            		cnt++;
				}
            	
            	var points1 = $("#cumulativeReturnChart > svg .lines1Wrap .nvd3-svg g.nv-group.nv-series-1 path");
            	var cnt = 0;
            	if (points1.length < $scope.interpolateCNT) {
            		return;
            	}
            	while  (cnt < $scope.interpolateCNT) {
            		var index = ($scope.dataDisplayViewIndex === 'FromYearBegin') ? 11-cnt : cnt ;
            		$(points1[index]).remove();
            		cnt++;
				}
    		}, 0);
    	};
    	$scope.hideInterpolatedBars = function() {
    		setTimeout(function() {
    			var rects = $("#cumulativeReturnChart > svg > .multiChart .bars1Wrap g.nv-group.nv-series-0 > rect");
    			var cnt = 0;
    			if (rects.length < $scope.interpolateCNT) {
            		return;
            	}
    			while  (cnt < $scope.interpolateCNT) {
            		var index = ($scope.dataDisplayViewIndex === 'FromYearBegin') ? 11-cnt : cnt ;
					$(rects[index]).remove();
            		cnt++;
				}
    		});
    	};
    	$scope.hideInterpolatedArea = function() {
    		setTimeout(function() {
                $('nvd3 path.nv-area').css('clip-path','url(#clippy)');
    		});
    	};
    	$scope.compareMaxMinRange = function(data, arrOfProperties) {
    		if (!arrOfProperties || !data || arrOfProperties.length === undefined || arrOfProperties.length === 0) { return; }
    		if (isNaN($scope.maxRange)) {
    			$scope.maxRange = 0;
    			$scope.minRange = Number.MAX_VALUE;
    		}
    		arrOfProperties.forEach(function(entry) {
    			if (data[entry] < $scope.minRange) { $scope.minRange = data[entry]; }
    			else if (data[entry] > $scope.maxRange) { $scope.maxRange = data[entry]; }
    		});
    	};
    	$scope.isInterpolatedData = function(month) {
    		var isInterpolated;
    		if ($scope.dataDisplayViewIndex === 'FromYearBegin') {
    			isInterpolated = ( month > (12 - $scope.interpolateCNT)) ? true : false;
    		} 
    		return isInterpolated;
    	};
		$scope.init();
	}]);
});