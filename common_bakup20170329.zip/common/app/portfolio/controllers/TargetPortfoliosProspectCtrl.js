define([
    'app/app',
    'js/appState',
    'js/Util/LogUtil',
    'js/Util/CommonUtil',
    'js/Util/AuditLoggingUtil',
    'js/Util/Validation',
    'js/Util/PdfPluginUtil',
    'app/portfolio/services/TargetPortfolioService',
	'js/constants',
    'js/Util/FunctionActivator'
], function(app, AppState, LogUtil, CommonUtil,AuditLoggingUtil,Validation,PdfPluginUtil,TargetPortfolioService, Constants, FunctionActivator) {
    'use strict';
    app.controller('TargetPortfoliosProspectCtrl', [
        '$scope',
        '$translate',
        '$filter',
        '$state',
        '$ionicModal',
        'TargetPortfolioService',
        '$ionicHistory',
        function($scope, $translate, $filter, $state,$ionicModal,TargetPortfolioService,$ionicHistory) {       	
        	$scope.init = function() {     
        		$scope.isSidePanelActivated = false;
            	$scope.portfoliosLength = 0;
            	if (FunctionActivator.isAccessibleToModule(Constants.ACCESS_MODULE_TARGET_PROF) === false) {
                	FunctionActivator.showAccessDeniedMessage($ionicHistory);
                	return;
        		}
            	
        		$scope.activatedPortfolioIndex = -1;
        		$scope.portfoliosListContainer = $(".panning-container > .panning-column");
        		$scope.sidePanelContainer = $(".side-panel");
        		$scope.transitionTypes = {
    					'transition':'transitionend',
    					'OTransition':'oTransitionEnd',
    					'MozTransition':'transitionend',
    					'WebkitTransition':'webkitTransitionEnd'
    			};
        		$scope.transitionKey = '';
        		for (var t in $scope.transitionTypes){
        			if ($scope.sidePanelContainer[0].style[t] !== undefined) {
        				$scope.transitionKey = t;
        				break;
        			}
        		}
        		LogUtil.logDebug('TargetPortfoliosProspectCtrl -> init');
                var storedTargetPortfolio = AppState.storedTargetPortfolio;
                for (var i = 0; storedTargetPortfolio && i < storedTargetPortfolio.length; i++) {
                	if (storedTargetPortfolio[i].lastModifiedDate) {
                		storedTargetPortfolio[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedTargetPortfolio[i].lastModifiedDate),'dd MMM yyyy, HH:mm'), true);
                		storedTargetPortfolio[i].index = i;
                        LogUtil.logDebug('TargetPortfoliosProspectCtrl -> displayDate from LastModifiedDate: ' + storedTargetPortfolio[i].displayDate);
                	}else {
                		storedTargetPortfolio[i].displayDate = CommonUtil.getDateTimeString($filter('date')(new Date(storedTargetPortfolio[i].id),'dd MMM yyyy, HH:mm'), true);
                		storedTargetPortfolio[i].index = i;
                        LogUtil.logDebug('TargetPortfoliosProspectCtrl -> displayDate from id: ' + storedTargetPortfolio[i].displayDate);
                	}
                }
                $scope.storedTargetPortfolio = AppState.storedTargetPortfolio;
        	};
        	
        	$scope.modifySidePanel = function(_action,_index){
        		switch(_action) {
        			case 'hide':
        				LogUtil.logDebug('TargetPortfoliosProspectCtrl -> hide side panel');
        				//Change value of activated portfolio AFTER side-panel is hided
        				$scope.sidePanelContainer.on($scope.transitionTypes[$scope.transitionKey], function(_e){
        					$scope.activatedPortfolioIndex = -1;
        					$(this).off(_e); //So that this event is only fired once
        				});
        				$scope.portfoliosListContainer.removeClass('pan-left-25');
        				$scope.sidePanelContainer.addClass('panel-hide');
        				this.isSidePanelActivated = false;
        			break;
        			case 'show':
        				LogUtil.logDebug('TargetPortfoliosProspectCtrl -> show side panel');
            			$scope.activatedPortfolioIndex = _index;
            			$scope.portfoliosListContainer.addClass('pan-left-25');
            			$scope.sidePanelContainer.removeClass('panel-hide');
        				this.isSidePanelActivated = true;
            		break;
        		}
        	};
        	        
        	$scope.showHideTargetPortfolio = function(_evt){       	
        		LogUtil.logDebug('TargetPortfoliosProspectCtrl -> showHideTargetPortfolio');
        		var clickTriggerElement = $(_evt.target),
        			classCheckingString = 'target-portfolio',
        			isPortfolioClicked = clickTriggerElement.hasClass('button-'+classCheckingString);
        		if (!isPortfolioClicked) {
        			if (this.isSidePanelActivated) {
        				$scope.modifySidePanel('hide');
        				this.portfolioButtons.removeClass('selected');
        			}
        			return;
        		}
        		var clickTargetId = clickTriggerElement.attr('id'),
        			clickTargetIndex = parseInt(clickTargetId.replace(classCheckingString+'-',''));
        		
        		if (this.isSidePanelActivated && $scope.activatedPortfolioIndex == clickTargetIndex) {
        			clickTriggerElement.removeClass('selected');
        			$scope.modifySidePanel('hide');
        		} else if (this.isSidePanelActivated && $scope.activatedPortfolioIndex != clickTargetIndex) {
        			this.portfolioButtons.removeClass('selected');
        			clickTriggerElement.addClass('selected');
        			$scope.activatedPortfolioIndex = clickTargetIndex;
        		} else if (!this.isSidePanelActivated) {
        			clickTriggerElement.addClass('selected');
        			$scope.modifySidePanel('show',clickTargetIndex);
        		}
        		LogUtil.logDebug('TargetPortfoliosProspectCtrl -> showHideTargetPortfolio : activatedPortfolioIndex '+ this.activatedPortfolioIndex);
        		$scope.selectedPortfolio = this.storedTargetPortfolio[this.activatedPortfolioIndex];
        		if ($scope.selectedPortfolio && $scope.selectedPortfolio.remarksData && $scope.selectedPortfolio.remarksData.length > 66) {
        			$scope.selectedPortfolio.remarksDisplay = $scope.selectedPortfolio.remarksData.substr(0,65)+'...';
        		}
        	};
        	
        	$scope.goToPortfolio = function() {
                LogUtil.logDebug('TargetPortfoliosProspectCtrl -> goToPortfolio : id: '+this.selectedPortfolio.id);
                var param = {
    			    	data: null,
    			    	source : 'target_portfolios_prospect',
    			    	targetPortfolio : angular.toJson(this.selectedPortfolio)
    			    };    				
    			$state.go('base.target_portfolio', param, {reload: true});
        	};
        	 // Prepare submit overlay     	
            $ionicModal.fromTemplateUrl('./app/portfolio/templates/targetportforlio_save_success.html',{
        		scope : $scope,
        		backdropClickToClose : false
        	}).then(function(modal){
        		$scope.submitModal = modal;
        	});
            $scope.hideSubmitOverlay = function() {
                $scope.submitModal.hide();
            };
        	$scope.uploadTargetPortfolio = function(selectedPortfolio) { 
        		LogUtil.logDebug('TargetPortfolioProspectCtrl -> uploadTargetPortfolio' );
        		var generatePDFsuccessCallback = function(data){
        			LogUtil.logDebug('TargetPortfolioProspectCtrl -> generatePDFsuccessCallback : generate PDF success');			 
    				LogUtil.logDebug('TargetPortfolioProspectCtrl -> generatePDFsuccessCallback : attempt to uploadTargetPortfolioPDF');
    				$scope.uploadTargetPortfolioPDF(data);
        		};
        		var generatePDFFailureCallback = function(data){
        			busyIndicator.hide();               
                	LogUtil.logDebug('TargetPortfolioProspectCtrl -> generatePDFFailureCallback : generate PDF failed');  
                	WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),$translate.instant('ERR_GENERATE_TARGET_PORTFOLIO_PDF_FAILURE'),[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
        		};
             	if(Validation.isEmpty(selectedPortfolio.fileContent)){
             		LogUtil.logDebug('TargetPortfolioProspectCtrl -> fileContent is empty.Re-generate PDF file.');
             		PdfPluginUtil.generateTargetPortfolioPDF(selectedPortfolio,generatePDFsuccessCallback,generatePDFFailureCallback);
             	}else {
             		LogUtil.logDebug('TargetPortfolioProspectCtrl -> upload fileContent directly.');
             		$scope.uploadTargetPortfolioPDF(selectedPortfolio);
             	}
             	
        	};
        	$scope.uploadTargetPortfolioPDF = function(selectedPortfolio){
        		LogUtil.logDebug('TargetPortfolioProspectCtrl -> uploadTargetPortfolioPDF' );
 				var uploadTargetPortfolioPDFSuccessCallback = function(data) { 	
 					LogUtil.logDebug('TargetPortfolioProspectCtrl -> uploadTargetPortfolioPDF -> uploadTargetPortfolioPDFSuccessCallback');
 					$scope.deletePortfolioOnly(selectedPortfolio.id,selectedPortfolio.portfolioName);
 					busyIndicator.hide();
 		            $scope.submitModal.show();  
 				};	                         
 	            var uploadTargetPortfolioPDFFailureCallback = function(data) { 
 	            	busyIndicator.hide();
 	            	LogUtil.logDebug('TargetPortfolioProspectCtrl -> uploadTargetPortfolioPDF -> uploadTargetPortfolioPDFFailureCallback');
	            	var errorMsg = '';
	            	if(data.errorCode){
	            		errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_ZPB_FAILURE')+data.errorCode;
	            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
	            	}else {
	            		WL.Device.getNetworkInfo(function(networkInfo) {
				  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
				  			LogUtil.logDebug('TargetPortfolioProspectCtrl -> Network Info : '+networkInfo.isNetworkConnected);
				  			if (networkInfo.isNetworkConnected === 'false') {
				  				errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_NO_INTERNET_CONNECTION');
			            		WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
				  			}else{
				  				errorMsg = $translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_MFP_CONNECTION_FAILURE');
				  				WL.SimpleDialog.show($translate.instant('ERR_SUBMIT_TARGET_PORTFOLIO_TITLE'),errorMsg,[{text:$translate.instant('BTN_OK'), handler: function() {}}]);
				  			}
	            		});	            		
	            	}	            	
 	            };       
 	            TargetPortfolioService.uploadTargetPortfolioPDF(selectedPortfolio,uploadTargetPortfolioPDFSuccessCallback,uploadTargetPortfolioPDFFailureCallback);
 	            var auditLogInfo = {
               		userID : AppState.userID,
               		activity:'submit_target_portfolio',
               		customerName : null,
               		accountName : null,
               		accountNumber : null
               };
               AuditLoggingUtil.insertAuditLogging(auditLogInfo);
             };
        	
        	$scope.deletePortfolio = function(id,portfolioName){
        		LogUtil.logDebug('TargetPortfolioProspectCtrl -> deletePortfolio - id: "'+id+'" name: "'+portfolioName+'"');
        		var _this = this;
        		CommonUtil.displayConfirmBox($translate.instant('CONF_DELETE_TARGET_PORTFOLIO_TITLE'), 
        			$translate.instant('CONF_DELETE_TARGET_PORTFOLIO'), 
        			$translate.instant('BTN_OK'), function() {
        				busyIndicator.show();
        				TargetPortfolioService.deleteTargetPortfolioByID(id,_this.deletePortfolioSuccessCallback,_this.deletePortfolioFailureCallback);
        				$scope.modifySidePanel('hide');
        			},
        			$translate.instant('BTN_CANCEL'), function() {
        				// do nothing. just dismiss the confirmation box
        			}
        		);
        	};
        	
        	$scope.deletePortfolioOnly = function(id,portfolioName){
        		var _this = this;
        		TargetPortfolioService.deleteTargetPortfolioByID(id,_this.deletePortfolioSuccessCallback,_this.deletePortfolioFailureCallback);
				$scope.modifySidePanel('hide');
        	};
        	$scope.deletePortfolioSuccessCallback = function(result) {
            	LogUtil.logInfo('TargetPortfolioProspectCtrl -> deletePortfolioSuccessCallback');
            	$scope.$apply(function() {
            		$scope.storedTargetPortfolio = result; 
            		busyIndicator.hide();
            	});            	
            };
            $scope.deletePortfolioFailureCallback = function(errObj) {
            	LogUtil.logInfo('TargetPortfolioProspectCtrl -> deletePortfolioFailureCallback');
            	WL.SimpleDialog.show($translate.instant('ERR_DELETE_TARGET_PORTFOLIO_FAILURE_TITLE'),$translate.instant('ERR_DELETE_TARGET_PORTFOLIO_FAILURE'), [{text:$translate.instant('BTN_OK'), handler: function() {}}]);
            	busyIndicator.hide();           	
            };
        	$scope.init();
        }
    ]);

    app.directive('onPortfoliosListed',['$timeout',function($timeout) {
        return function($scope,element,attrs) {
      	  $timeout(function(){
      		$scope.portfolioButtons = $(".button-target-portfolio");
      		$scope.portfoliosLength = $scope.portfolioButtons.length;
      	  },0,false);
        };
    }]);
});

   