define([
  'app/app',
  'app/portfolio/services/CustomerPortfolioService',
  'js/Util/ChartGenerator',
  'js/appConfig',
  'js/constants',
  'js/appState',
  'js/Util/FunctionActivator',
  'js/Util/LogUtil'
], function (app, CustomerPortfolioService, ChartGenerator, AppConfig, Constants, AppState, FunctionActivator,LogUtil) {
  'use strict';

  app.controller('PortfolioHistoryCtrl', [
	'$scope',
    'CustomerPortfolioService',
    '$translate',
    '$stateParams',
    '$filter',
    '$ionicModal',
    '$state',
    '$timeout',
    '$ionicSideMenuDelegate',
    '$ionicScrollDelegate',
    function ($scope, CustomerPortfolioService, $translate, $stateParams, $filter, $ionicModal, $state, $timeout,$ionicSideMenuDelegate, $ionicScrollDelegate) {
		$scope.colorMap = ChartGenerator.getCategoryColorMap();
		$scope._assetAllocationHistory = null;
		$scope._netAssetValueHistory = null;
		
		$scope.init = function() {
			$scope.initAllocationTypeAndSpecificAsset();
			
			if ('asset' === $stateParams.allocationType) {
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
			} else if ('nav' === $stateParams.allocationType) {
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.navClassList;
			}
			
			$scope.data = angular.fromJson($stateParams.data);
    		$scope.portfolioName = CustomerPortfolioService.getPortfolioName($scope.data);
    		$scope.portfolioCurrency = $translate.instant(CustomerPortfolioService.getPortfolioCurrency($scope.data));
			
			$scope.allocationType = $stateParams.allocationType;
			$scope.graphOrDetail = $stateParams.graphOrDetail;
			$scope.dataDisplayViewIndex = ($scope.graphOrDetail === 'graph') ? 0 : 1;
			$scope.dataDisplayViewLib.forEach(function(_obj,_index) {
				if (_index == $scope.dataDisplayViewIndex) { _obj.checked = true; }
				else { _obj.checked = false; }
			});
			$scope.selectedDate = $scope.getArrayData()[0].year+"-"+ $scope.getArrayData()[0].month;
			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);
			$scope.chartTitle = $scope.allocationType === 'nav' ? $translate.instant('PH_NAV_BY_MONTH') : $translate.instant('PH_ASSET_ALLOC_BY_MONTH');
			
			$scope.prepareLegend();
			$scope.isAccessibleToFNPortfolioHoldings = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HOLDINGS);

		};
		$scope.initAllocationTypeAndSpecificAsset = function() {
			if (!$stateParams.graphOrDetail || $stateParams.graphOrDetail === '') {
				$stateParams.graphOrDetail = 'graph';
			}
			if ($stateParams.specificAsset && !$stateParams.allocationType) {
				if ($scope.getCategoryIndexInJSON($stateParams.specificAsset,'asset') > -1) {
					$stateParams.allocationType = 'asset';
				} else {
					$stateParams.allocationType = 'nav';
					
					if ($scope.getNAVcategoryOfSubAssetClass()) {
						$stateParams.specificAsset = $scope.getNAVcategoryOfSubAssetClass();
					} else if ($scope.getCategoryIndexInJSON($stateParams.specificAsset,'nav') == -1) {
						$stateParams.specificAsset = "";
					}
				}
			}
			if (!$stateParams.allocationType || $stateParams.allocationType === '') {
				$stateParams.allocationType = 'nav';
			}
			$stateParams.specificAsset = $stateParams.specificAsset ? $stateParams.specificAsset : "";
			
			if ('asset' === $stateParams.allocationType) {
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
			} else if ('nav' === $stateParams.allocationType) {
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.navClassList;
			}
			
			$scope.data = angular.fromJson($stateParams.data);
    		$scope.portfolioName = CustomerPortfolioService.getPortfolioName($scope.data);
    		$scope.portfolioCurrency = $translate.instant(CustomerPortfolioService.getPortfolioCurrency($scope.data));
			
			$scope.allocationType = $stateParams.allocationType;
			$scope.graphOrDetail = $stateParams.graphOrDetail;
			$scope.dataDisplayViewIndex = ($scope.graphOrDetail === 'graph')? 0:1;
			$scope.dataDisplayViewLib.forEach(function(_obj,_index){
				if (_index == $scope.dataDisplayViewIndex) _obj.checked = true;
				else _obj.checked = false;
			});
			
			$scope.selectedDate = $scope.getArrayData()[0].year+"-"+ $scope.getArrayData()[0].month;
			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);
			$scope.chartTitle = $translate.instant('PH_NAV_BY_MONTH');
			
			$scope.prepareLegend();
			$scope.setChartLegendTitle();
			
			$scope.isAccessibleToFNPortfolioHoldings = FunctionActivator.isAccessibleToFunction(Constants.ACCESS_FN_PORTFOLIO_HOLDINGS);
		};
		/* 
		 * Cater for specific asset from portfolio holdings
		 * Has to be separate function to delay the execution out of init event loop
		*/
		$scope.initSpecificAsset = function() {
			$scope.setSpecificAsset($stateParams.specificAsset);
		};
		
		$scope.showGraph = function () {
			$scope.graphOrDetail = 'graph';
			$('.porthistory_detail').hide();
			$('.porthistory_chart').show();
			
			$scope.prepareGraph();
			if ("" !== $scope.specificAsset) {
				$scope.showLegendDetail($scope.selectedDate, $scope.specificAsset);
			}

			$scope.setChartLegendTitle($scope.selectedDate);			
		};
		$scope.prepareGraph = function() {
			var chartOptions = ChartGenerator.createBasicBarChartOption();
			chartOptions.chart.yAxis.tickFormat = ChartGenerator.axisNumberFormater;
			chartOptions.chart.yAxis.axisLabel = $translate.instant($scope.data.portfolioCurrency);
			chartOptions.chart.yAxis.rotateYLabel = false;
			chartOptions.chart.yAxis.showMaxMin = true;
			chartOptions.chart.xAxis.tickFormat = ChartGenerator.axisMonthYearFormatter;
			chartOptions.chart.height = "500";
			chartOptions.chart.forceY = [0];
			chartOptions.chart.multibar = {
					dispatch : {
						elementClick : function (evt) {
							var category = evt.data.key;
							
							if ("" !== $scope.specificAsset || "net_asset_values" === evt.data.key) {
								if ("net_asset_values" === evt.data.key) {
									$scope.selectedDate = evt.data.x;
									$scope.prepareLegend($scope.selectedDate);
								}
								$scope.specificAsset = "";
								$('.porthistory_chartLegend').hide();
							} else {
								$scope.selectedDate = evt.data.x;
								$scope.specificAsset = category;
								$scope.prepareLegend($scope.selectedDate);
								$scope.showLegendDetail($scope.selectedDate, category);
							}
							$scope.showGraph();
							$scope.$apply();
						},
                        renderEnd : function () {
                            $scope.setChartLegendTitle($scope.selectedDate);
                        }
					}
			};
			var _this = this;
			$scope.chart = {				
				data : _this.getChartData(),
				options : chartOptions
			};
		};
		$scope.showLegendDetail = function(date, category) {
			var arr = this.getArrayData();
			var year = date ? date.split("-")[0] : null;
			var month = date ? date.split("-")[1] : null;
			
			$(".porthistory_chartLegend").hide();

			if ('asset' === this.allocationType) {
				var amount = -1;
				arr.forEach(function(entry){
					if (Number(entry.month) === Number(month) && Number(entry.year) === Number(year)) {
						var catIndex = $scope.getCategoryIndexInJSON(category);
						amount = entry.detailsList[catIndex].amount;
					}
				});
				
				$scope.assetAmount = amount;
				
				setTimeout(function(){
					$(".porthistory_chartLegend_asset_"+category).show();
				}, 0);					
			} else if ('nav' === this.allocationType) {
				var index = $scope.getCategoryIndexInJSON(category);
				
				$scope.categories.forEach(function(entry){
					var subAssetClass = [];
					if (category === entry.category) {
						if (typeof $scope.categoryList[index].subAssetClass === 'undefined' || !$scope.categoryList[index].subAssetClass ) {
							subAssetClass.push({category : category, percentage : '--'});
						} else {
							/*
							 * This will retrieve percentage of Asset allocations instead of NAV
							 * and show it in legend
							 */
							var arrSubAssetClass = $scope.categoryList[index].subAssetClass;
							//Iterate each possible sub asset class
							arrSubAssetClass.forEach(function (item) {
								//Iterate asset allocation data 
								$scope.getArrayData('asset').forEach(function(itemData) {
									//Compare month and year
									if (Number(itemData.month) === Number(month) && Number(itemData.year) === Number(year)) {
										var subIndex = $scope.getCategoryIndexInJSON(item, 'asset');
										//Push percentage 
										if (!isNaN(subIndex) && subIndex > -1) {
											subAssetClass.push({
												category : item,
												percentage : itemData.detailsList[subIndex].percentage
											});
											if (Number(itemData.detailsList[subIndex].percentage) < 0) {
												$scope.hasNegativeValue = true;
											}
										}
									}
								});
							});
						}
					}
					entry.subAssetClass = subAssetClass;
				});

				setTimeout(function(){
					$(".porthistory_chartLegend_nav_"+category).show();
				}, 0);
			}
		};
		$scope.toggleHideMaster = function() {
    		$scope.hideMaster = !$scope.hideMaster;
    		var scrollLeft = $ionicScrollDelegate.$getByHandle('porthistory_table').getScrollPosition().left;
    		
    		$timeout(function() {
    			$ionicScrollDelegate.$getByHandle('porthistory_table').scrollTo(scrollLeft, 0);
    		});
    	};
		$scope.prepareLegend = function (date) {
			var chartLegend = [];
			var i;
			var _this = this;
			var year = date ? date.split("-")[0] : null;
			var month = date ? date.split("-")[1] : null;
			
			_this.categoryList.forEach(function(item){
				var obj = {
						category : item.key,
						categoryLabel : $translate.instant(item.key),
						color : _this.colorMap.get(item.key)
					};
				var categoryIndex = $scope.getCategoryIndexInJSON(item.key);
				var arr = $scope.getArrayData();
				var dateIndex = -1;
				if (typeof year === 'undefined' || !year) {
					dateIndex = 0;
				} else {
					for (i = 0 ; i < arr.length ; i++) {
						if (Number(arr[i].year) === Number(year) &&
								Number(arr[i].month) === Number(month)) {
							dateIndex = i;
							break;
						}
					}
				}
				obj.amount = arr[dateIndex].detailsList[categoryIndex].amount;
				
				if ('asset' === $scope.allocationType) {
					obj.percentage = arr[dateIndex].detailsList[categoryIndex].percentage;
				}
				chartLegend.push(obj);
			});
			$scope.categories = chartLegend;
		};
		$scope.showDetail = function () {
			function isNotNAVData(detailsListItem) {
				if (detailsListItem.assetClassID || 'net_asset_values' !== detailsListItem.category) {
					return true;
				} else {
					return false;
				}
			}
			$('.porthistory_detail').show();
			$('.porthistory_chart').hide();
			var arr = $scope.getArrayData();
			var i, n, item;
			var detailDates = [];
			var detailCategories = [];
			var detailTotalAsset = [];
			var dataLen;
			
			var dateIndex=0;
			if (arr.length >=6) {
				for (i = arr.length-1 ; i >= 0 ; i--) {
					item = arr[i];

					detailDates.push($scope.monthYearFormatter(item.year+"-"+item.month));
					if ($scope.selectedDate === item.year+"-"+item.month) {
						dateIndex = arr.length-1-i;
					}
					// -1 for NAV, because 'NAV' will be pushed to another array for "total row"
					dataLen = ( 'nav' === $scope.allocationType ? item.detailsList.length - 1 : item.detailsList.length);

					// Create structure if detailCategories isnt long enough
					if (detailCategories.length < dataLen) {
						for (n = 0 ; n < item.detailsList.length; n++) {
							if (isNotNAVData(item.detailsList[n])) {
								detailCategories.push({
									assetClass : item.detailsList[n].assetClassID || item.detailsList[n].category,
									data : []
								});
							} 	
						}
					}
						
					n=0;
					for (var tmp in item.detailsList) {
						var entry = item.detailsList[tmp];
						if (isNotNAVData(entry)) {
							var amount = $filter('currency')(entry.amount,'',2);
							detailCategories[n].data.push(amount);
							n++;
						} else {
							detailTotalAsset.push($filter('currency')(entry.amount,'',2));
						}
					}
					
					if (!isNaN(item.totalAsset) && item.totalAsset !== false) {
						detailTotalAsset.push($filter('currency')(item.totalAsset,'',2));
					}
				}

				$scope.detailDates = detailDates;
				$scope.detailCategories = detailCategories;
				$scope.detailTotalAsset = detailTotalAsset;
			}
			$ionicScrollDelegate.$getByHandle('porthistory_table').scrollTo(dateIndex*260,0,true);
		};
		$scope.toggleChartOrDetail = function (type) {
			if ("graph" === type) {
				$scope.graphOrDetail = 'graph';
				$scope.showGraph();
			} else if ("details" === type) {
				$scope.graphOrDetail = 'details';
				$scope.showDetail();
			}
		};
		$scope.toggleAllocation = function (type) {
			if ($scope.allocationType === type) {
				return;
			}
			$scope.specificAsset = "";
			$scope.allocationType = type;
			
			if ('asset' === $scope.allocationType) {
				$scope.chartTitle = $translate.instant('PH_ASSET_ALLOC_BY_MONTH');
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.assetClassList;
			} else if ('nav' === $scope.allocationType) {
				$scope.chartTitle = $translate.instant('PH_NAV_BY_MONTH');
				$scope.categoryList = AppConfig.systemParam.stdPortfolioModel.navClassList;
			}
			
			$scope.prepareLegend($scope.selectedDate);
			if ('graph' === $scope.graphOrDetail) {
				$scope.showGraph();
			} else {
				$scope.showDetail();
			}
		};
		$scope.setSpecificAsset = function(category, date) {
			if ($scope.specificAsset === category || 'net_asset_values' === category) {
				$scope.specificAsset = "";
				$('.porthistory_chartLegend').hide();
			} else {
				date = date ? date : $scope.selectedDate;
				$scope.specificAsset = category;
				$scope.setChartLegendTitle(date);
			}
			$scope.showGraph();
		};
		$scope.setChartLegendTitle = function(date) {
			//Make format YYYY-MM and pass to formatter
			if (typeof date === 'undefined' || !date || typeof date === 'object') {
				date = $scope.getArrayData()[0].year+"-"+$scope.getArrayData()[0].month;
			}
			var formatDate = $scope.monthYearFormatter(date);
			var labelAxis = $(".porthistory_chart nvd3 svg g text");
        	labelAxis.removeClass("axisStyleBold");
			labelAxis.toArray().forEach(function(item){
				if (item.innerHTML === formatDate) {
	            	$(item).addClass("axisStyleBold");
				}
			});
			$scope.chartLegendTitle = formatDate;
		};
		/*
		 *  @param date: should be in format "YYYY-MM"
		 *  
		 *  @return date string in format "mmm YYYY"
		 */
		$scope.monthYearFormatter = function(date) {
			return ChartGenerator.axisMonthYearFormatter(date);
		};
		$scope.getArrayData = function(type) {
			if ( 'asset' === type || (!type && 'asset' === this.allocationType)) {
				if (!$scope._assetAllocationHistory) {
					$scope._assetAllocationHistory = CustomerPortfolioService.getAssetAllocationHistory(this.data);
				}
				return $scope._assetAllocationHistory;
			} else if ('nav' === type || (!type &&'nav' === this.allocationType)) {
				if (!$scope._netAssetValueHistory) {
					$scope._netAssetValueHistory = CustomerPortfolioService.getNetAssetValueHistory(this.data);
				}
				return $scope._netAssetValueHistory;
			}
		};
  		$scope.getChartData = function() {
			var chartData;
			var categoryList = this.categoryList;
			
			var arrayData = this.getArrayData();
			if ('' === this.specificAsset) {
				chartData = $scope.getChartDataWithoutSpecificAsset(arrayData, categoryList,this.colorMap);
			} else {
				chartData = $scope.getChartDataWithSpecificAsset(arrayData, categoryList, $scope.specificAsset,this.colorMap);
				
			}
			return chartData;
		};
  		$scope.getChartDataWithoutSpecificAsset = function(arrayData, categoryList, colorMap) {
  			var chartData = [];
  			var i;
  			
  			if ('nav' === this.allocationType) {
				// Show NAV when there is no specific asset
				var navIndex = this.getCategoryIndexInJSON('net_asset_values');
				var navData = {
						key : 'net_asset_values',
						values : [],
						color : colorMap.get('net_asset_values')
					};

				for(i = arrayData.length-1 ; i >= 0 ; i--) {
					var entry = arrayData[i];
					var amount = Number(entry.detailsList[navIndex].amount);

					navData.values.push({x: entry.year+"-"+entry.month ,y: amount});
				}
				chartData.push(navData);
			}  else if ('asset' === this.allocationType) {
				// Show all data
				categoryList.forEach(function(category){
					var categoryData = {
						key : category.key,
						values : [],
						color : colorMap.get(category.key)
					};
					var categoryIndex = category.seq - 1;
					//To push oldest data first
					for(var i = arrayData.length-1 ; i >= 0 ; i--) {
						var entry = arrayData[i];
						var amount = Number(entry.detailsList[categoryIndex].amount);

						categoryData.values.push({x: entry.year+"-"+entry.month ,y: amount});
					}
					chartData.push(categoryData);
				});
			}
  			return chartData;
  		};
  		$scope.getChartDataWithSpecificAsset = function(arrayData, categoryList, specificAsset, colorMap) {
  			//create copy of array
			var arrCopy = JSON.parse(JSON.stringify(arrayData));
			var catIndex = $scope.getCategoryIndexInJSON(specificAsset);
			var catColor = colorMap.get(specificAsset);
			//Put data of specific asset into another array for easier construction of data for chart
			var arrSpecificAsset = [];
			var arrOtherAssets = [];
			var chartData = [];
			
			for (var i = arrCopy.length-1 ; i >= 0 ; i--) {
				var item = arrCopy[i];
				var dataSpecificAsset = item.detailsList.splice(catIndex,1);
				arrSpecificAsset.push({amount : Number(dataSpecificAsset[0].amount),
					month: item.month,
					year: item.year,
					color: catColor});

				if ('asset' === $scope.allocationType) {
					var totalAmount = 0;
					for (var tmp in item.detailsList) {
						var itemDetail = item.detailsList[tmp];
						if ((itemDetail.category && itemDetail.category !== 'net_asset_values') ||
	                            (itemDetail.assetClassID && itemDetail.assetClassID !== 'net_asset_values')) {
							totalAmount += Number(itemDetail.amount);
						}
					}

					arrOtherAssets.push({amount: totalAmount,
						month: item.month,
						year: item.year,
						color: '#BBB'});
				}
			}
			var assetData = {
					key : $scope.specificAsset,
					values : []
			};
			var otherData = {
					key : "others",
					values : []
			};

			if (arrSpecificAsset.length > 0) {
				assetData.color = arrSpecificAsset[0].color;
				arrSpecificAsset.forEach(function(item) {
					assetData.values.push({
						y : item.amount,
						x : item.year+'-'+item.month
					});
				});
				chartData.push(assetData);
			}

			if (arrOtherAssets.length > 0) {
				otherData.color = arrOtherAssets[0].color;
				arrOtherAssets.forEach(function(item){
					otherData.values.push({
						y : item.amount,
						x : item.year+'-'+item.month
					});
				});
				chartData.push(otherData);
			}
			return chartData;
  		};
  		$scope.getCategoryIndexInJSON = function (category, allocation) {
			var categoryIndex = -1;
			if ('asset' === allocation) {
				categoryIndex = $scope.getAssetClassIndexInJSON(category);
			} else if ('nav' === allocation) {
				categoryIndex = $scope.getNAVcategoryIndexInJSON(category);
			} else {
				this.categoryList.forEach(function(item){
					if (item.key === category) {
						categoryIndex = item.seq - 1;
					}
				});
			}
			return categoryIndex;
		};
		$scope.getAssetClassIndexInJSON = function (category) {
			var categoryIndex = -1;
			AppConfig.systemParam.stdPortfolioModel.assetClassList.forEach(function(item){
				if (item.key === category) {
					categoryIndex = item.seq - 1;
				}
			});
			return categoryIndex;
		};
		$scope.getNAVcategoryIndexInJSON = function(category) {
			var categoryIndex = -1;
			AppConfig.systemParam.stdPortfolioModel.navClassList.forEach(function(item){
				if (item.key === category) {
					categoryIndex = item.seq - 1;
				}
			});
			return categoryIndex;
		};
		$scope.getNAVcategoryOfSubAssetClass = function(category) {
			var assetClass = null;
			AppConfig.systemParam.stdPortfolioModel.navClassList.forEach(function(item){
				item.subAssetClass.forEach(function(subAsset) {
					if (subAsset === category) {
						assetClass = item.key;
					}
				});
			});
			return assetClass;
		};
		$scope.detailSelect = function(indexDate, indexAssetClass) {
			var dataAll = $scope.getArrayData(), data;
			var index = $scope.findIndexByDate($scope.selectedDate);
			if (indexDate && typeof indexDate === "number") {
				var len = dataAll.length - 1;
				// input index is in reverse order
				data = dataAll[len - indexDate]; 
				$scope.selectedDate = data.year + "-" + data.month;
			} else {
				
				if (index !== -1) data = dataAll[index];
			}
			
			if (indexAssetClass === null || indexAssetClass === undefined || '' === indexAssetClass || index === -1) {
				$scope.specificAsset = '';
			} else {
				// assetClassID for asset allocation, category for NAV
				var assetClass = data.detailsList[indexAssetClass].assetClassID || data.detailsList[indexAssetClass].category;
				
				$scope.specificAsset = assetClass;
			}
		};
		$scope.findIndexByDate = function(date) {
			return CustomerPortfolioService.findIndexByDate($scope.data, $scope.allocationType, date);
		};
		$scope.goToHolding = function(category) {
			if ($scope.isAccessibleToFNPortfolioHoldings) {
				var param = {
		    			data: angular.toJson(this.data),
		    			assetCategory : (category ? category : $scope.specificAsset)
		    		};
				$state.go('base.portfolio_holdings', param, {reload: true});
			}
		};
		$scope.dataDisplayViewLib = [{
			name: "graph", label: $translate.instant('PH_GRAPH'), view: "graph"
		},{
			name: "table", label: $translate.instant('PH_DETAILS'), view: "details"
		}];
		$scope.switchDataDisplayView = function(_clickIndex,_evt) {
			var switchContainer = $(_evt.currentTarget).parent();
			$scope.dataDisplayViewLib.forEach(function(_obj,_index){
				if (_index == _clickIndex) _obj.checked = true;
				else _obj.checked = false;
			});
			$scope.dataDisplayViewIndex = _clickIndex;
			$scope.toggleChartOrDetail($scope.dataDisplayViewLib[_clickIndex].view);
		};
		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
    		scope : $scope
    	}).then(function(modal){
    		$scope.disclaimerModal = modal;
    	});
    	$scope.showDisclaimer = function() {
    		$scope.disclaimerModal.show();
    	};
    	$scope.hideDisclaimer = function() {
    		$scope.disclaimerModal.hide();
    	};
		$scope.isExtraHeightCellNeeded = function(index, parentIndex) {
			var currLang = AppState.currentLangCode;
			// index == 0 : only add class to first column
			// parentIndex == 2 : index of "bond" in data
			if (index === 0 && 
					parentIndex === 2 && 
					'asset' === $scope.allocationType && currLang == Constants.LANG_EN) {
				return true;
			} else {
				return false;
			}
		};
		$scope.filterNAV = function(item) {
			return 'net_asset_values' !== item.category;
		};
		$scope.filterNotNAV = function(item) {
			return 'net_asset_values' === item.category;
		};
		$scope.disableSideMenuSwipeGesture = function() {
			$ionicSideMenuDelegate.canDragContent(false);
		};
		$scope.enableSideMenuSwipeGesture = function() {
			$ionicSideMenuDelegate.canDragContent(true);
		};
		
		$scope.init();
		$scope.initSpecificAsset();
	}]);
});