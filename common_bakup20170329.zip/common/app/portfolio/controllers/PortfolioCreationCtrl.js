define([
    'app/app',
    'app/portfolio/services/AccountService',
    'app/portfolio/services/CustomerPortfolioService',
    'js/Util/Validation',
    'js/Util/LogUtil',
    'js/appConfig',
    'js/Util/AuditLoggingUtil',
    'js/appState'
], function(app, AccountService, CustomerPortfolioService, Validation, LogUtil, AppConfig, AuditLoggingUtil, AppState) {
    'use strict';

    app.controller('PortfolioCreationCtrl', [
        '$scope',
        '$translate',
        '$state',
        '$ionicHistory',
        'AccountService',
        'CustomerPortfolioService',
        function($scope, $translate, $state, $ionicHistory, AccountService, CustomerPortfolioService) {
        	$scope.init = function() {
	        	$scope.selectedAccounts = AccountService.selectedAccounts;
	
	            $scope.portfolioName = '';
	            $scope.portfolioCurrency = 'HKD';
	            $scope.selectAccountLimit = AppConfig.systemParam.configMap.get('i_accCountLimit');
        	};
            $scope.createPortfolio = function() {
            	$scope.hasError = false;
            	$scope.errorMsg = '';
            	$scope.createStart = Date.now();
                var selectedAccountNumber = '';
                var maskedAccountNumber = '';
                var maskedAccountName = '';
                for (var i = 0; AccountService.selectedAccounts && i < AccountService.selectedAccounts.length; i++) {
            		maskedAccountNumber = (selectedAccountNumber ? maskedAccountNumber + ',': '') + AccountService.selectedAccounts[i].displayAccountNumber;
            		selectedAccountNumber = (selectedAccountNumber ? selectedAccountNumber + ',': '') + AccountService.selectedAccounts[i].accountNumber;
            		maskedAccountName = (selectedAccountNumber ? maskedAccountNumber + ',': '') + AccountService.selectedAccounts[i].accountName;
                }
                
                var customerInfo = {
                    userID: AppState.userID,
                    accountList: selectedAccountNumber,
                    maskedAccountNumbers : maskedAccountNumber,
                    maskedAccountName : maskedAccountName,
                    portfolioName: this.portfolioName,
                    portfolioCurrency: this.portfolioCurrency
                };
                $scope.validatePortfolio(customerInfo);
                
                if ( $scope.hasError === false ) {
                    busyIndicator.show();
                    CustomerPortfolioService.generateCustomerPortfolio(customerInfo, $scope.createPortfolioSuccessCallback, $scope.createPortfolioFailureCallback);
                    var auditLogInfo = {
                    		userID : customerInfo.userID,
                    		activity:'download_portfolio',
                    		customerName : null,
                    		accountName : customerInfo.maskedAccountName,
                    		accountNumber : customerInfo.maskedAccountNumbers
                    };
                    AuditLoggingUtil.insertAuditLogging(auditLogInfo);
                }
            };
            $scope.validatePortfolio = function(customerInfo) {
            	
            	if (Validation.isEmpty(customerInfo.portfolioName)) {
                    $scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_PORTFOLIO_NAME_EMPTY');
                }else if(customerInfo.portfolioName.length > 55){
                	$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_PORTFOLIO_NAME_INVALID_LENGTH');
                }else if(Validation.isEmpty(customerInfo.portfolioCurrency)){
                	$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_CURRENCY_EMPTY');
                } else if ($scope.selectedAccounts.length > AppConfig.systemParam.configMap.get('i_accCountLimit')) {
                    $scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_NUM_OF_ACCOUNT_EXCEEDED').replace('[selectAccountLimit]',AppConfig.systemParam.configMap.get('i_accCountLimit'));
                } else if ($scope.selectedAccounts.length === 0) {
                    $scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_NO_ACCOUNT_SELECTED');
                }
            };
            $scope.createPortfolioSuccessCallback = function(id) {
            	LogUtil.logInfo('PortfolioCreationCtrl -> createPortfolioSuccessCallback');
            	busyIndicator.hide();
            	$scope.createEnd = Date.now();
                var responseTime = ($scope.createEnd - $scope.createStart)/1000;
                LogUtil.logInfo('Performance Test : Download Customer Portfolio userID='+AppState.userID+' r='+responseTime);
                $state.go('base.portfolio_overview', {
                    id: id
                }, {
                    reload: true
                });
            };
            $scope.createPortfolioFailureCallback = function(data) {
                LogUtil.logInfo('PortfolioCreationCtrl -> createPortfolioFailureCallback');
                var langCode = AppState.currentLangCode;
                var errorCode = '';
                var errorMsg = '';
            	if (data && data.errorCode) {
            		errorCode = data.errorCode;
            		if(errorCode === 'ERR_CUSTOMER_PORTFOLIO_SAVE_FAIL'){
            			errorMsg = $translate.instant('ERR_DOWNLOAD_PORTFOLIO_JSONSTORE_FAILURE') + '-' + errorCode;
            		} else if (errorCode === 'ERR_INSUFFICIENT_PORTFOLIO_DATA') {
            			errorMsg = $translate.instant('ERR_INSUFFICIENT_PORTFOLIO_DATA');
            		} else {
            			errorMsg = $translate.instant('ERR_DOWNLOAD_PORTFOLIO_ZPB_FAILURE');
            		}
                	LogUtil.logDebug('PortfolioCreationCtrl -> createPortfolioFailureCallback : errorCode - ' + errorCode);
                	$scope.$apply(function() {
                        $scope.hasError = true;
                        $scope.errorMsg = errorMsg;
                    });
                	busyIndicator.hide();
            	}else {
            		$scope.getNetworkStatus();
            	}
            };
            $scope.getNetworkStatus = function() {
            	var errorMsg;
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('PortfolioCreationCtrl -> Network Info : '+networkInfo.isNetworkConnected);
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorMsg = $translate.instant('ERR_DOWNLOAD_PORTFOLIO_NO_INTERNET_CONNECTION');
		  			}else{
		  				errorMsg = $translate.instant('ERR_DOWNLOAD_PORTFOLIO_MFP_CONNECTION_FAILURE');
		  			}
		  			$scope.$apply(function() {
                        $scope.hasError = true;
                        $scope.errorMsg = errorMsg;
                    });
	                busyIndicator.hide();
		  		});
            };
            $scope.searchAgain = function() {
                $state.go('base.account_search', {
                    isExistingSearch: 'Y'
                }, {
                    reload: true
                });
            };

            $scope.removeSelectedAccount = function(index) {
            	var title = $translate.instant('CONF_REMOVE_ACCOUNT_TITLE');
            	var message = $translate.instant('CONF_REMOVE_ACCOUNT');
            	if (this.selectedAccounts.length == 1) {
            		WL.SimpleDialog.show(title, message,[{
            			text : $translate.instant('BTN_OK'),
            			handler : function() {
            				$scope.selectedAccounts.splice(index, 1);
            				$state.go('base.account_search', {  	    			
                            }, {
                                reload: true
                            });
            			}
            		}, {
            			text : $translate.instant('BTN_CANCEL'),
            			handler : null
            		}]);
            	} else {
            		this.selectedAccounts.splice(index, 1);
            	}
            };
            
            $scope.init();
        }
    ]);
});