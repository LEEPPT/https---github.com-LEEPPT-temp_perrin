define([
    'app/app',
    'js/Util/ChartGenerator',
    'js/Util/LogUtil',
    'js/appConfig',
    'js/appState',
    'app/portfolio/services/CustomerPortfolioService'
], function(app, ChartGenerator, LogUtil, AppConfig, AppState, CustomerPortfolioService) {
    'use strict';

    app.controller('CurrencyDistributionCtrl', [
        '$scope',
        'CustomerPortfolioService',
        '$translate',
        '$stateParams',
        '$filter',
        '$ionicModal',
        function($scope, CustomerPortfolioService, $translate, $stateParams, $filter, $ionicModal) {
        	$scope.init = function () {
        		
        		$scope.data = angular.fromJson($stateParams.data);
	            $scope.portfolioName = $scope.data.portfolioName;
	            $scope.portfolioCurrency = $translate.instant($scope.data.portfolioCurrency);
				$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate($scope.data);
	            
	            $scope.activeLabel=null;
	                    	
	            var currencyDistributionData = [];
	            if ($scope.data.currencyDistributionList.length === 0) {
	            	currencyDistributionData.push({
	                    "label": '',
	                    "value": 0,
	                    "formattedValue": 0
	                });
	            } else {
	            	$scope.data.currencyDistributionList.forEach(function(item) {
	                    if (Number(item.amount) !== 0) {
	                        currencyDistributionData.push({
	                            "label": item.currency,
	                            "value": Number(item.amount),
	                            "formattedValue": $filter('currency')(item.amount, "", 2)
	                        });
	                    }
	                });
	            }
	            
	            $scope.ct = {};
	            	            
	            
	            $scope.currencyDistributionBarChartOption = ChartGenerator.createBasicDiscreteBarChartOption();
	            $scope.currencyDistributionBarChartOption.chart.yAxis.axisLabel = $translate.instant($scope.data.portfolioCurrency);
	            $scope.currencyDistributionBarChartOption.chart.rectClass = function(d, i) {
	                        if (d.label === $scope.activeLabel||$scope.activeLabel===null){
	                        	return "active-bar";
	                        } else {
	                        	return "inactive-bar";
	                        }
	            };
	            
	            $scope.currencyDistributionBarChartOption.chart.discretebar = {
	            	dispatch : {
	            		elementClick : function(e) {
	                        $scope.changeCurrency(e.data.label);
	            		},
	            		renderEnd : function(){
	                    	$scope.bindClickToAxis();
	            		}
	            	}
	            };
	                
	            $scope.currencyDistributionAmount = [{
	                key: 'Currency Distribution',
	                values: currencyDistributionData
	            }];
        	};
            $ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
        		scope : $scope
        	}).then(function(modal){
        		$scope.disclaimerModal = modal;
        	});
        	$scope.showDisclaimer = function() {
        		$scope.disclaimerModal.show();
        	};
        	$scope.hideDisclaimer = function() {
        		$scope.disclaimerModal.hide();
        	};

            $scope.changeCurrency = function(currencyName) {
                $scope.currencyDistributionBarChartOption.chart.duration = 0;
                $scope.activeLabel = currencyName;
                $scope.ct.api.refresh();
                $scope.$apply();
                $scope.highlightAxis(currencyName);
                $scope.bindClickToAxis();
            };
            $scope.highlightAxis = function(currencyName) {
            	var labelAxis = $("nvd3[options=currencyDistributionBar] svg g text:not(.nv-axislabel)");
            	labelAxis.removeClass("axisStyleBold");
            	labelAxis.toArray().forEach(function(item){
    				if (item.innerHTML === currencyName) {
    					$(item).addClass("axisStyleBold");
    				}
    			});
            };
            
            $scope.bindClickToAxis = function() {
            	//.style is required for click event to work
                d3.selectAll('g.nv-axis.nv-x g.tick')
                	.style("pointer-events", "visiblePainted") 
                    .on('click',function(e) {
                    	var currency = e.data ? e.data.label : e;
                        $scope.changeCurrency(currency);
                    });
            };
            $scope.init();
            

        }
    ]);
});