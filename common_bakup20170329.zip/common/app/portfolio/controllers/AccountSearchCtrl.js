define([
    'app/app',
    'app/portfolio/services/AccountService',
    'js/Util/LogUtil',
    'js/Util/Validation',
    'js/Util/AuditLoggingUtil',
    'js/appState',
    'js/constants'
], function(app, AccountService, LogUtil, Validation, AuditLoggingUtil, AppState, Constants) {
    'use strict';

    app.controller('AccountSearchCtrl', [
        '$scope',
        'AccountService',
        '$translate',
        '$stateParams',
        '$state',
        function($scope, AccountService, $translate, $stateParams, $state) {
        	$scope.init = function() {
                LogUtil.logDebug('AccountSearchCtrl -> init : ' + $stateParams.isFromAccSearch);
                if ($stateParams.isExistingSearch !== undefined && $stateParams.isExistingSearch === 'Y') {
                    LogUtil.logInfo('AccountSearchCtrl -> init : isFromAccSearch is true, no need to empty selectedAccounts array');
                } else {
                    LogUtil.logInfo('AccountSearchCtrl -> init : empty selectedAccounts array');
                    AccountService.selectedAccounts.length = 0;
                }
                if ($stateParams.isFromAccSearch !== undefined && $stateParams.isFromAccSearch === 'Y') {
                	$scope.isFromAccSearch = 'Y';
                }
                $scope.hasEmpty = true; 
                $scope.hasError = true;
                $scope.searchCriteria = {
                    customerName: '',
                    accountName: '',
                    accountNumber: '',
                    userID: AppState.userID
                };            
                $scope.$watch('searchCriteria', function() {
                	if (Validation.isEmpty($scope.searchCriteria.customerName) && Validation.isEmpty($scope.searchCriteria.accountName) && $scope.searchCriteria.accountNumber === '') {
                        $scope.hasEmpty = true;               
                    }else{
                    	$scope.hasEmpty = false; 
                    }   
                }, true);
        	};
            $scope.search = function(form) {
                $scope.errorMsg = '';       
                $scope.searchStart = Date.now();
                var langCode = AppState.currentLangCode;
                if(!Validation.isEmpty($scope.searchCriteria.customerName) && $scope.searchCriteria.customerName.length > 55){
                	$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_CUSTOMER_NAME_INVALID_LENGTH');
                }else if(!Validation.isEmpty($scope.searchCriteria.accountName) && $scope.searchCriteria.accountName.length > 40){
                	$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_ACCOUNT_NAME_INVALID_LENGTH');
                }else if(!Validation.isEmpty($scope.searchCriteria.accountNumber) && $scope.searchCriteria.accountNumber.length > 8){
                	$scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_ACCOUNT_NUMBER_INVALID_LENGTH');
                }else if (isNaN($scope.searchCriteria.accountNumber)) {
                    $scope.hasError = true;
                    $scope.errorMsg = $translate.instant('ERR_ACCOUNT_NUMBER_INVALID_FORMAT');
                } else {
                    var accountSearchCriteria = {
                        customerName: $scope.searchCriteria.customerName,
                        accountName: $scope.searchCriteria.accountName,
                        accountNumber: $scope.searchCriteria.accountNumber.length == 8 ? (Constants.ACCOUNT_PREFIX + $scope.searchCriteria.accountNumber) : $scope.searchCriteria.accountNumber,
                        userID: AppState.userID
                    };
                    LogUtil.logDebug('AccountSearchCtrl -> search : search customer name is ' + accountSearchCriteria.customerName);
                    LogUtil.logDebug('AccountSearchCtrl -> search : search account name is ' + accountSearchCriteria.accountName);
                    LogUtil.logDebug('AccountSearchCtrl -> search : search account number is ' + accountSearchCriteria.accountNumber);

                    AccountService.searchEntitleAccount(accountSearchCriteria, $scope.searchSuccessCallback, $scope.searchFailureCallback);
                    busyIndicator.show();
                    var auditLogInfo = {
                    		userID : accountSearchCriteria.userID,
                    		activity:'search_account',
                    		customerName : accountSearchCriteria.customerName,
                    		accountName : accountSearchCriteria.accountName,
                    		accountNumber : accountSearchCriteria.accountNumber
                    };
                    AuditLoggingUtil.insertAuditLogging(auditLogInfo);
                }
            };

            $scope.searchSuccessCallback = function() {
                LogUtil.logInfo('AccountSearchCtrl -> searchSuccessCallback');
                $scope.$apply(function() {
                    $scope.hasError = false;
                });
                busyIndicator.hide();
                $scope.searchEnd = Date.now();
                var responseTime = ($scope.searchEnd - $scope.searchStart)/1000;
                LogUtil.logInfo('Performance Test : Search Entitled Account userID='+AppState.userID+' r='+responseTime);
                $state.go('base.account_select', {
                	isFromAccSearch: $scope.isFromAccSearch
                }, {
                    reload: true
                });
            };

            $scope.searchFailureCallback = function(data) {
                LogUtil.logError('AccountSearchCtrl -> searchFailureCallback');
                var langCode = AppState.currentLangCode;
                var errorCode = '';
                var errorMsg = '';
                if (data && data.responseJSON && data.responseJSON.errorCode) {
                    errorCode = data.responseJSON.errorCode;
                    LogUtil.logError('AccountSearchCtrl -> searchFailureCallback : errorCode - ' + errorCode);
                    if(errorCode==='ERR_NO_SEARCH_RESULT'){
                    	errorMsg = $translate.instant('ERR_SEARCH_ACCOUNT_NO_RESULT');
                    }else if(errorCode==='ERR_TOO_MANY_RESULTS'){
                    	errorMsg = $translate.instant('ERR_SEARCH_ACCOUNT_TOO_MANY_RESULT');
                    }else {
                    	errorMsg = $translate.instant('ERR_SEARCH_ACCOUNT_ZPB_FAILURE')+'-'+errorCode;
                    }
                    $scope.$apply(function() {
                        $scope.hasError = true;
                        $scope.errorMsg = errorMsg;
                    });
                    busyIndicator.hide();
                }else{
                	$scope.getNetworkStatus();
                }
            };
            $scope.getNetworkStatus = function() {
            	var errorMsg;
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('AccountSearchCtrl -> getNetworkStatus : Network Info '+networkInfo.isNetworkConnected);
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorMsg = $translate.instant('ERR_SEARCH_ACCOUNT_NO_INTERNET_CONNECTION');
		  			}else{
		  				errorMsg = $translate.instant('ERR_SEARCH_ACCOUNT_MFP_CONNECTION_FAILURE');
		  			}
		  			$scope.$apply(function() {
	                    $scope.hasError = true;
	                    $scope.errorMsg = errorMsg;
	                });
	                busyIndicator.hide();
		  		});
            };
            $scope.init();

        }
    ]);
});