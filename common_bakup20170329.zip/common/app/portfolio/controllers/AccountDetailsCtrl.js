define([
  'app/app',
  'app/portfolio/services/CustomerPortfolioService',
  'js/appState',
  'js/Util/LogUtil',
  'js/Util/Validation'
], function (app, CustomerPortfolioService, AppState,LogUtil, Validation) {
  'use strict';
  /**
   * @memberof app
   * @ngdoc controller
   * @name AccountDetailsCtrl
   * @param $scope {service} controller scope
   * @param CustomerPortfolioService {service} Service Class for handling business logic of Customer Portfolio
   * @param $translate {service} i18n handling
   * @param $stateParams{service} for passing parameters between controllers
   * @param $filter {service} for data formating
   * @description 
   *   Controller for Account Detail Page
   */
  app.controller('AccountDetailsCtrl', [
	'$scope',
	'CustomerPortfolioService',
	'$translate',
	'$stateParams',
	'$filter',
	'$ionicModal',
	function ($scope, CustomerPortfolioService, $translate, $stateParams, $filter, $ionicModal) {
		
		/**
	     * Initialization function of AccountDetailsCtrl
	     * @memberof AccountDetailsCtrl
	     * @function init
		 * @description retrieve portfolio data from $stateParams and display account list of customer portfolio
	     */
		$scope.init = function (){
			$scope.data = angular.fromJson($stateParams.data);
			$scope.portfolioName = this.data.portfolioName;
			$scope.portfolioCurrency = $translate.instant(this.data.portfolioCurrency);
			$scope.totalAUM = $filter('currency')(this.data.totalAUM, "", 2);
			$scope.accountList = [];
			$scope.updatedAccountName = [];
			$scope.isUpdate = false;
			$scope.lastUpdate = CustomerPortfolioService.getFormattedLastUpdate(this.data);
			
			if (this.data.accountList && this.data.accountList.length > 0) {
				for (var i = 0; i < this.data.accountList.length; i++) {
					var clientRiskProfile = '';
					var riskToleranceLevel = '';
					if (this.data.accountList[i].riskToleranceLevel) {
						clientRiskProfile = $translate.instant('client_risk_profile_lv_' + this.data.accountList[i].riskToleranceLevel);
						riskToleranceLevel = this.data.accountList[i].riskToleranceLevel + ': ' + $translate.instant('risk_tolerance_lv_' + this.data.accountList[i].riskToleranceLevel);
					} else {
						clientRiskProfile = $translate.instant('NO_RISK_TOLERANCE_LEVEL_MESSAGE');
						riskToleranceLevel = $translate.instant('NO_RISK_TOLERANCE_LEVEL_MESSAGE');
					}
					$scope.accountList.push({
						index: i,
						accountAUM: $filter('currency')(this.data.accountList[i].accountAUM, '', 2),
						accountName: this.data.accountList[i].accountName,
						accountNumber: this.data.accountList[i].accountNumber,
						clientRiskProfile: clientRiskProfile,
						riskToleranceLevel: riskToleranceLevel
					});
					$scope.updatedAccountName.push(this.data.accountList[i].accountName);
				}
			}
		};

		
		/**
	     * Event trigger by edit button
	     * @memberof AccountDetailsCtrl
	     * @function editAccountName
		 * @description isUpdate controls the ng-show attribute of account input box,save button and cancel button.
		 * When isUpdate is true account input box will show up and allow users to change account name.
	     */

		$scope.editAccountName = function() {
			$scope.isUpdate = true;
		};
		
		/**
	     * Event trigger by cancel button
	     * @memberof AccountDetailsCtrl
	     * @function cancelUpdateAccountName
		 * @description isUpdate controls the ng-show attribute of account input box,save button and cancel button.
		 * When isUpdate is false account input box,save button and cancel button will be hide.
	     */

		$scope.cancelUpdateAccountName = function() {
			$scope.isUpdate = false;
		};
		
		/**
	     * Event trigger by cancel button
	     * @memberof AccountDetailsCtrl
	     * @function saveUpdateAccountName
		 * @description Update account names of customer portfolio to local storage.
		 * validation rules : account name cannot be empty or pass the length of 40
	     */
		$scope.saveUpdateAccountName = function() {
			this.hasError = false;
			var updatedData = this.data;
			if (updatedData.accountList && updatedData.accountList.length > 0) {
				for (var i = 0; i < updatedData.accountList.length; i++) {
					if (Validation.isEmpty($scope.updatedAccountName[i])) {
						this.hasError = true;
						this.errorMsg = $translate.instant('ERR_ACCOUNT_NAME_EMPTY');
						break;
					} else if (Validation.isInvalidLength($scope.updatedAccountName[i], 1, 40)) {
						this.hasError = true;
						this.errorMsg = $translate.instant('ERR_ACCOUNT_NAME_INVALID_LENGTH');
						break;
					} else {
						updatedData.accountList[i].accountName = $scope.updatedAccountName[i];
					}
				}
				if (!this.hasError) {
					CustomerPortfolioService.updateCustomerPortfolioByID(updatedData, this.updatePortfolioSuccessCallback , this.updatePortfolioFailureCallback);
				}
			}
			
		};
		
		/**
	     * Success callback function for CustomerPortfolioService.updateCustomerPortfolioByID
	     * @memberof AccountDetailsCtrl
	     * @function updatePortfolioSuccessCallback
		 * @description Use $scope.$apply to refresh account details with updated data. 
	     */

		$scope.updatePortfolioSuccessCallback = function(data) {
			LogUtil.logDebug('AccountDetailsCtrl -> updatePortfolioSuccessCallback: Update account name successfully');
			$scope.$apply(function() {
				if (data.accountList && data.accountList.length > 0) {
					for (var i = 0; i < data.accountList.length; i++) {
						LogUtil.logDebug('AccountDetailsCtrl -> updatePortfolioSuccessCallback: Updated account name: ' + $scope.updatedAccountName[i]);
						$scope.accountList[i].accountName = $scope.updatedAccountName[i];
					}
				}
				$scope.isUpdate = false;
			});
		};
		
		/**
	     * Failure callback function for CustomerPortfolioService.updateCustomerPortfolioByID
	     * @memberof AccountDetailsCtrl
	     * @function updatePortfolioFailureCallback
		 * @description Display error message when update failure 
	     */
		$scope.updatePortfolioFailureCallback = function() {
			LogUtil.logError('AccountDetailsCtrl -> updatePortfolioFailureCallback: Fail to update account name');
			$scope.$apply(function() {
				$scope.isUpdate = false;
				this.hasError = true;
				this.errorMsg = $translate.instant('ERR_ACCOUNT_NAME_UPDATE_FAILURE');
			});
		};
		$ionicModal.fromTemplateUrl('./app/portfolio/templates/portfolio_overview_disclaimer.html',{
    		scope : $scope
    	}).then(function(modal){
    		$scope.disclaimerModal = modal;
    	});
    	$scope.showDisclaimer = function() {
    		$scope.disclaimerModal.show();
    	};
    	$scope.hideDisclaimer = function() {
    		$scope.disclaimerModal.hide();
    	};
		$scope.init();
	}]);
});