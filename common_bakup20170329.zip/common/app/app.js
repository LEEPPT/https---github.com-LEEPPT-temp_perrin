// The main app definition
// --> where you should load other module depdendencies
define([
  'ionic',
  'angularTranslate',
  'angularNVD3'
], function (ionic,angularTranslate) {
  'use strict';

  var app = angular.module('app', [
    'ionic',
    'pascalprecht.translate',
    'nvd3'
  ]);
  
  return app;
});
