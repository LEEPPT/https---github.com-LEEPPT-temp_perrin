define([
	'js/constants'
        ], function(Constants) {
	var version = {

		buildVersion : '1.15.0',
		appVersion : '1.15',
		lastModifyTime : '2017-03-03 10:03',
		
		// JSONStore
		JSONStoreUser : 'BEAiPortfolio',
		JSONStoreKey : 'Abcd1234!',
		
		isDevMode : 'N',
		isEnableAnalytics : 'N',
		
		loggerPackageName : 'com.hkbea.zpb-ipa.uat',
		remoteLogging : true,
        logLevel : Constants.INFO,
        logFilterLevel : Constants.INFO,
        logSize : 30,
		
		//MQA
		isEnableMQA: 'Y',
		MQAMode : 'QA',
		MQAHost : 'xia-mqa-uat.intranet.hkbea.com',
		MQAIOSAppKey : '0d4376a84919bbdda5f347c50e54f23a9a51c042',
		MQAProtocol : 'http'
	};
	return version;
});
