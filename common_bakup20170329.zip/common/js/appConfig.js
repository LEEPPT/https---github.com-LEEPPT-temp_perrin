define([
    'js/constants'
    ], function(Constants) {
    var AppConfig = {
        // Data Storage
        allowWebLocalStorage : true, // disable for production
        appDataCollectionName : 'appData',
        appDataInitCheckName : 'isAppDataInitialized',
        localCollectionsDefinition : {
            appData : {
                searchFields: {name: 'string'}
            }
        },
        defaultAppData : [
            {name: 'isAppDataInitialized', value: 'Y'},
            {name: 'isFirstTimeLaunch', value: 'Y'},
            {name: 'userPreferredLanguage', value: 'null'},
            {name: 'storedPortfolio', value : 'null'},
            {name: 'storedTargetPortfolio', value : 'null'},
            {name: 'storedRAQResult', value : 'null'},
            {name: 'storedCallReport', value : 'null'},
            {name: 'userID', value : 'null'},
            {name: 'userInfo', value : 'null'},
            {name: 'rmRINumber', value : 'null'},
            {name: 'systemParam', value : 'null'},
            {name: 'raqConfig', value : 'null'},
            {name: 'raqPDFTemplate', value : 'null'}
        ],
        enableLogSender : false,
        defaultLangCode: Constants.LANG_EN,
        backFlowConfig: {
            'base.portfolio_overview':'base.homepage',
            'base.raq_result':'base.raq_result',
            'base.raq_select_customer_type':'base.homepage',
            'base.raq_customer_signature':'base.raq_disclaimer',
            'base.customer_portfolios':'base.homepage',
            'base.target_portfolios_prospect':'base.homepage',
            'base.raq_main':'base.homepage',
            'base.call_report_main':'base.homepage'
        },
        disableBackButtonConfig: ['base.homepage'],
        targetPortfolioProspectRemarksCharacterLimit : 2000,
        systemParam: null,
        functionActivatorByModuleAccess : 
        [
	      	{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF },
	     	{ enabled : 'Y', module : Constants.ACCESS_MODULE_TARGET_PROF },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_RAQ },
	     	{ enabled : 'Y', module : Constants.ACCESS_MODULE_CALL_REPT }
        ],
        functionActivatorByFunctionAccess : 
        [
         	{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_PORFOLIO_CREATION  },
         	{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_ACCOUNT_DETAILS  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_PORTFOLIO_HOLDINGS  },
	 		{ enabled : 'N', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_PORTFOLIO_COMPARISON  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_TARGET_PORTFOLIO  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_TARGET_PROF, fn : Constants.ACCESS_FN_TARGET_PORTFOLIO_PROSPECT  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_RAQ, fn : Constants.ACCESS_FN_RAQ },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_CURRENCY_DISTRIBUTION  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_PORTFOLIO_HISTORY  },
	 		{ enabled : 'Y', module : Constants.ACCESS_MODULE_CUST_PROF, fn : Constants.ACCESS_FN_PERFORMANCE  }
        ],
        stateFunctionality : {
        	"base.homepage" : "home",
        	"base.customer_portfolios" : "customerPortfolios",
        	"base.account_search" : "customerPortfolios",
        	"base.portfolio_overview" : "customerPortfolios",
        	"base.account_select" : "customerPortfolios",
        	"base.portfolio_creation" : "customerPortfolios",
        	"base.portfolio_holdings" : "customerPortfolios",
        	"base.account_details" : "customerPortfolios",
        	"base.portfolio_history" : "customerPortfolios",
        	"base.portfolio_comparison" : "customerPortfolios",
        	"base.currency_distribution" : "customerPortfolios",
        	"base.target_portfolios_prospect" : "targetPortfolios",
        	"base.call_report_main" : "callReport"
        }
  
    };
    return AppConfig;
});
