define([], function() {
	var constants = {

		// Language Code
		LANG_TC : 'tc',
		LANG_SC : 'sc',
		LANG_EN : 'en',

		// Log Level Constant
		ERROR : 0,
		WARN : 20,
		INFO : 40,
		DEBUG : 60,
		TRACE : 100,
		
		// Log Level Filter Constant
		FILTER_TRACE : 'trace',
		FILTER_DEBUG : 'debug',
		FILTER_INFO : 'info', 
		FILTER_WARN : 'warn', 
		FILTER_ERROR : 'error',
		FILTER_FATAL :'fatal',
		
		// App Mode
		APP_MODE_ONLINE : 'online',
		APP_MODE_OFFLINE : 'offline',
			
	    // Server Connection State
		SERVER_CONNECTED : 'connected',
	    SERVER_DISCONNECTED : 'disconnected',
	    
	    ACCOUNT_PREFIX : '015-260-',
	    
	    // RAQ
	    RAQ_PDF_ID_IND_TC: 'raq_individual_tc',
	    RAQ_PDF_ID_IND_SC: 'raq_individual_sc',
	    RAQ_PDF_ID_COR_TC: 'raq_corporate_tc',
	    RAQ_PDF_ID_COR_SC: 'raq_corporate_sc',
	    RAQ_PDF_ID_VUL_TC: 'raq_vulnerable_tc',
	    RAQ_PDF_ID_VUL_SC: 'raq_vulnerable_sc',
	    
	    RAQ_CUST_TYPE_IND: 'INDIVIDUAL',
	    RAQ_CUST_TYPE_COR: 'CORPORATE',
	    RAQ_CUST_TYPE_VUL: 'VULNERABLE',
	    
		// Function Activator
		ACCESS_MODULE_RAQ : 'raq',
		ACCESS_MODULE_CUST_PROF : 'cust_pf',
		ACCESS_MODULE_TARGET_PROF : 'target_pf',
		ACCESS_MODULE_CALL_REPT : 'call_rept',
		
		ACCESS_FN_PORFOLIO_CREATION : 'portfolioCreation',
		ACCESS_FN_ACCOUNT_DETAILS : 'accountDetails',
 		ACCESS_FN_PORTFOLIO_HOLDINGS : 'portfolioHoldings',
 		ACCESS_FN_PORTFOLIO_COMPARISON : 'portfolioComparison',
 		ACCESS_FN_TARGET_PORTFOLIO : 'targetPortfolio',
 		ACCESS_FN_RAQ : 'raq',
 		ACCESS_FN_CURRENCY_DISTRIBUTION : 'currencyDistribution',
 		ACCESS_FN_PORTFOLIO_HISTORY : 'portfolioHistory',
 		ACCESS_FN_PERFORMANCE : 'performance',
 		ACCESS_FN_TARGET_PORTFOLIO_PROSPECT : 'targetPortfolioprospect'
	};
	return constants;
});
