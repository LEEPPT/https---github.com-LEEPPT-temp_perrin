define([
        'js/Util/LogUtil',
        'js/Util/DataMaskingUtil',
        'js/Util/DataPersister',
        'js/appState',
        'js/constants',
        'js/message',
        'environment'
	], function(LogUtil,DataMaskingUtil,DataPersister,AppState,Constants,Message,Environment){
		var CommonUtil = {
			sortArrayByKey : function (sortList,sortKey,_orderRule){
					var orderRule = _orderRule || 'ascn';
					orderRule = (typeof orderRule == 'string')? orderRule : 'ascn';
					sortList.sort(function(a, b) {
						var _this = this;
						var x,y;
						if (typeof (a) === 'object') {
								if (Array.isArray(a[sortKey])) {
									xKeyList = a[sortKey];
									yKeyList = b[sortKey];
									x = xKeyList[0];
									y = yKeyList[0];

								}else {
									x = a[sortKey];
									y = b[sortKey];
								}
						}else {
								x = a;
								y = b;
						}
						if(sortKey==='accountNumber'){
							x=Number(x.replace(/[*-]/g,''));
							y=Number(y.replace(/[*-]/g,''));
							
						}else if (sortKey === 'customerName'|| sortKey === 'accountName'){
							var xList = x.split(' ');
							if(DataMaskingUtil.titleList.indexOf(xList[0].toUpperCase())>=0){
								x=x.replace(xList[0]+' ', '');
							}
							
							var yList = y.split(' ');
							if(DataMaskingUtil.titleList.indexOf(yList[0].toUpperCase())>=0){
								y=y.replace(yList[0]+' ', '');
							}

						}
						if (typeof (x) === 'number') {
								if (orderRule == 'ascn') return x - y;
								else return y - x;
							
							} else if (typeof (x) === 'string') {
								if (x === y) {
									return 0;
								} else {
									if (orderRule == 'ascn') return (x <= y) ? -1 : 1;
									else return (x <= y) ? 1 : -1;
								}
							} 
						});
					return sortList;
				},
				numericShortenFormat : function(d) {
					var scaleDenominator = 0;
					var valueScale = [
						              { range:1000000000000, label: "tn" },
						              { range:1000000000, label: "bn" },
						              { range:1000000, label: "mn" },
						              { range:1000, label: "k" }
						              ];
				  for (var i in valueScale) {
					var scale = valueScale[i];
				    if (d >= scale.range) {
				      scaleDenominator = scale.range;
				      return (d / scaleDenominator).toFixed(1) + scale.label;
				    }
				  }
				},
				handleAppConnectError:function (source,errorCode,onConnectSuccess,onConnectFailure,onNetworkFailure){
					var langCode = AppState.currentLangCode;
					var confirm = Message[langCode].BTN_CONFIRM;
					var title = Message[langCode].ERR_USER_AUTHENTICATION_FAILURE_TITLE;
					var message = Message[langCode].ERR_USER_AUTHENTICATION_FAILURE;
					
					LogUtil.logInfo('CommonUtil -> handleAppConnectError for '+source);
					var _this = this;
					WL.SimpleDialog.show(title,message+errorCode,[{text:confirm, handler: function() {
						if(Environment.isDevMode==='Y'){
							_this.checkServerConnection(onConnectSuccess,onConnectFailure,onNetworkFailure);
						}else {
							_this.quitApp();
						}
													
					}}]);
				},
				handleAppError:function (source,title,message,isQuitApp,callback){
					var langCode = AppState.currentLangCode;
					var confirm = Message[langCode].BTN_CONFIRM;
					
					LogUtil.logInfo('CommonUtil -> handleAppError for '+source);
					var _this = this;
					WL.SimpleDialog.show(title,message,[{text:confirm, handler: function() {
						if(isQuitApp){
							_this.quitApp();
						}else if(callback && typeof callback === 'function'){
							callback();
						}
													
					}}]);
				},
				displayConfirmBox: function(title, message, btn1, btn1Callback, btn2, btn2Callback) {
					WL.SimpleDialog.show(title, message, [{text: btn1, handler: btn1Callback}, {text: btn2, handler: btn2Callback}]);
				},
				bootstrap : function(){   
					LogUtil.logInfo('CommonUtil -> bootstrap: Start app rendering!');

			    	require([
			                 'app/routes',
			                 'app/config',
			                 'app/run'
			               ], function () {
			                 	angular.bootstrap(document, ['app']);

			               });
			    },
			    loadStoredPortfolio : function(dataExpPeriod){ 
			        DataPersister.getAppDataByNameValue('storedPortfolio',
			          function (value) {
			            LogUtil.logDebug('CommonUtil -> loadStoredPortfolio: loadAppState(storedPortfolio) : onDPSuccess');
			            if (typeof value === 'undefined' || value === 'null'|| value === null || value === '' || value.length === 0) {
			                LogUtil.logInfo('CommonUtil -> loadStoredPortfolio: No local portfolio is found');
			                AppState.storedPortfolio = [];
			            } else {
			            	LogUtil.logInfo('CommonUtil -> loadStoredPortfolio: ' + value.length + ' local portfolio is found');
			            	var cleanStoredPortfolio = [];
			            	value.forEach(function(item,index) {
			            		var offset = 0;
			        	    	if(item.lastModifiedDate){
			        	    		offset = (Date.now() - item.lastModifiedDate)/86400000;
			        	    	}else {
			        	    		offset = (Date.now() - item.id)/86400000;
			        	    	}
			        	    	LogUtil.logDebug('CommonUtil -> loadStoredPortfolio: portfolio id is ' + item.id + ', portfolio name is ' + item.portfolioName +
			        	    			', offset is :' + offset + ', dataExpPeriod is :' + dataExpPeriod);
			        	    	if(offset > dataExpPeriod){
			        	    		LogUtil.logDebug('CommonUtil -> loadStoredPortfolio: delete expired customer portfolio :'+item.portfolioName);
			        	    	}else {
			        	    		cleanStoredPortfolio.push(item)
			        	    	}
			        	    });
			            	AppState.storedPortfolio = cleanStoredPortfolio;
			            }
			            if (AppState.storedPortfolio) {
			            	LogUtil.logInfo('CommonUtil -> loadStoredPortfolio: Current storedPortfolio in AppState (after load) = ' + AppState.storedPortfolio.length);
			            }
			            DataPersister.setAppDataByNameValue('storedPortfolio',AppState.storedPortfolio); 			           
			        });
			      },
			      loadStoredTargetPortfolio : function(dataExpPeriod){ 
				        DataPersister.getAppDataByNameValue('storedTargetPortfolio',
				          function (value) {
				            LogUtil.logInfo('CommonUtil -> loadStoredTargetPortfolio: loadAppState(storedTargetPortfolio) : onDPSuccess');
				            if (typeof value === 'undefined' || value === 'null'|| value === null || value === '' || value.length === 0) {				                 
				                LogUtil.logDebug('CommonUtil -> loadStoredTargetPortfolio: No local portfolio is found');
				                AppState.storedTargetPortfolio = [];
				            } else {
				            	LogUtil.logInfo('CommonUtil -> loadStoredTargetPortfolio: ' + value.length + ' local portfolio is found');
				            	var cleanStoredTargetPortfolio = [];
				            	value.forEach(function(item,index) {
				            		var offset = 0;
				        	    	if(item.lastModifiedDate){
				        	    		offset = (Date.now() - item.lastModifiedDate)/86400000;
				        	    	}else {
				        	    		offset = (Date.now() - item.id)/86400000;
				        	    	}
				        	    	LogUtil.logDebug('CommonUtil -> loadStoredTargetPortfolio: portfolio id is ' + item.id + ', portfolio name is ' + item.portfolioName +
				        	    			', offset is :' + offset + ', dataExpPeriod is :' + dataExpPeriod);
				        	    	if(offset>dataExpPeriod){
				        	    		LogUtil.logDebug('CommonUtil -> loadStoredTargetPortfolio: delete expired target portfolio :'+item.portfolioName);
				        	    	}else {
				        	    		cleanStoredTargetPortfolio.push(item);
				        	    	}
				        	    });
				            	AppState.storedTargetPortfolio = cleanStoredTargetPortfolio;
				            }
				            if (AppState.storedTargetPortfolio) {
				            	LogUtil.logInfo('CommonUtil -> loadStoredTargetPortfolio: Current storedTargetPortfolio in AppState (after load) = ' + AppState.storedTargetPortfolio.length);
				            }
				            DataPersister.setAppDataByNameValue('storedTargetPortfolio',AppState.storedTargetPortfolio); 
				        });
				  },
				  loadStoredRAQResult:function(dataExpPeriod){ 
				        DataPersister.getAppDataByNameValue('storedRAQResult',
						          function (value) {
				        			var isRAQDeleted = false;
				        			var deletedRAQCustomerName = "";
						            LogUtil.logInfo('CommonUtil -> loadStoredRAQResult: loadAppState(storedRAQResult) : onDPSuccess');
						            if (typeof value === 'undefined' || value === 'null'|| value === null || value === '' || value.length === 0) {				                 
						                LogUtil.logDebug('CommonUtil -> loadStoredRAQResult: No local RAQResult is found');
						                AppState.storedRAQResult = [];
						            } else {
						            	LogUtil.logInfo('CommonUtil -> loadStoredRAQResult: ' + value.length + ' local RAQResult is found');
						            	var cleanStoredRAQResult = [];
						            	value.forEach(function(item,index) {
						            		var offset = 0;
						        	    	if(item.lastModifiedDate){
						        	    		offset = (Date.now() - item.lastModifiedDate)/86400000;
						        	    	}else {
						        	    		offset = (Date.now() - item.id)/86400000;
						        	    	}
						        	    	LogUtil.logDebug('CommonUtil -> loadStoredRAQResult: portfolio id is ' + item.id + ', customer name is ' + item.customerName +
						        	    			', offset is :' + offset + ', dataExpPeriod is :' + dataExpPeriod);
						        	    	if(offset>dataExpPeriod){
						        	    		isRAQDeleted = true;
						        	    		if (deletedRAQCustomerName !== "") {
						        	    			deletedRAQCustomerName = deletedRAQCustomerName + "\n" + item.customerName;
						        	    		} else {
						        	    			deletedRAQCustomerName = item.customerName;
						        	    		}
						        	    		LogUtil.logDebug('CommonUtil -> loadStoredRAQResult: delete expired raq result :'+item.customerName);
						        	    	}else {
						        	    		cleanStoredRAQResult.push(item);
						        	    	}
						        	    });
						            	AppState.storedRAQResult = cleanStoredRAQResult;
						            }
						            if (AppState.storedRAQResult) {
						            	LogUtil.logInfo('CommonUtil -> loadStoredRAQResult: Current storedRAQResult in AppState (after load) = ' + AppState.storedRAQResult.length);
						            }
						            if (isRAQDeleted) {
						            	var langCode = AppState.currentLangCode;
						            	WL.SimpleDialog.show(Message[langCode].RAQ_DELETED_MESSAGE_TITLE, Message[langCode].RAQ_DELETED_MESSAGE + '\n\n' + deletedRAQCustomerName, [{text: Message[langCode].BTN_OK, handler: function() {}}]);
						            }
						            DataPersister.setAppDataByNameValue('storedRAQResult',AppState.storedRAQResult); 
						           
						        });
						  },
						  loadStoredCallReport:function(dataExpPeriod){
						        DataPersister.getAppDataByNameValue('storedCallReport',
						        		function (value) {
								            LogUtil.logInfo('CommonUtil -> loadStoredCallReport: loadAppState(storedCallReport) : onDPSuccess');
								            if (typeof value === 'undefined' || value === 'null'|| value === null || value === '' || value.length === 0) {				                 
								                LogUtil.logDebug('CommonUtil -> loadStoredCallReport: No local call report is found');
								                AppState.storedCallReport = [];
								            } else {
								            	LogUtil.logInfo('CommonUtil -> loadStoredCallReport: ' + value.length + ' local call report is found');
								            	var cleanStoredCallReport = [];
								            	value.forEach(function(item,index) {
								            		var offset = 0;
								        	    	if(item.lastModifiedDate){
								        	    		offset = (Date.now() - item.lastModifiedDate)/86400000;
								        	    	}else {
								        	    		offset = (Date.now() - item.id)/86400000;
								        	    	}
								        	    	LogUtil.logDebug('CommonUtil -> loadStoredCallReport: call report id is ' + item.id +
								        	    			', offset is :' + offset + ', dataExpPeriod is :' + dataExpPeriod);
								        	    	if(offset>dataExpPeriod){
								        	    		LogUtil.logDebug('CommonUtil -> loadStoredCallReport: delete expired call report :' + item.id);
								        	    	}else {
								        	    		cleanStoredCallReport.push(item);
								        	    	}
								        	    });
								            	AppState.storedCallReport = cleanStoredCallReport;
								            }
								            if (AppState.storedCallReport) {
								            	LogUtil.logInfo('CommonUtil -> loadStoreCallReport: Current storedCallReport in AppState (after load) = ' + AppState.storedCallReport.length);
								            }
								            DataPersister.setAppDataByNameValue('storedCallReport', AppState.storedCallReport);
								        },function(err){});
								  },
			      quitApp: function(){
						if(WL.Client.getEnvironment() === 'preview'){
							return;
						}else if (WL.Client.getEnvironment() === 'iphone' || WL.Client.getEnvironment() === 'ipad'){
			    			 cordova.exec(null, null, 'ExitPlugin', 'exitApp', []);
			    		 } else {
			    			 WL.App.close();
			    		 }
			      },
			      checkServerConnection : function(successCallback,failureCallback,onNetworkFailure){
			  		WL.Device.getNetworkInfo(function(networkInfo) {
			  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
			  			LogUtil.logDebug('CommonUtil -> checkServerConnection: Network Info : ' + JSON.stringify(networkInfo));
			  			if (networkInfo.isNetworkConnected === 'false') {
			  				onNetworkFailure();
			  			}else{
			  				LogUtil.logInfo('CommonUtil -> checkServerConnection: Trying to connect to wl server');
			  				WL.Client.connect({
			  					onSuccess : successCallback,
			  					onFailure : failureCallback,
			  					timeout : 10000
			  				});
			  			}
			  		});
			  	},
			  	/*
	             * Return date string in current language
	             * @param {Date} date: Date object
	             * @param {Boolean} withTime: Indicate if the returned string contains date string only but not with time string
	             */
			  	getDateTimeString: function(dateString, withTime) {
			  		var langCode = AppState.currentLangCode;
			  		var formattedDate = dateString;
			  		var date = new Date(dateString);
			  		if (date && langCode == Constants.LANG_TC || langCode == Constants.LANG_SC) {
				  		if (langCode == Constants.LANG_TC || langCode == Constants.LANG_SC) {
				  			var year = date.getFullYear();
				  			var month = date.getMonth() + 1;
				  			var day = date.getDate();
				  			var hours = date.getHours();
				  			var minutes = date.getMinutes();
				  			if (!withTime) {
				  				formattedDate = year + Message[langCode].YEAR + month + Message[langCode].MONTH + day + Message[langCode].DAY;
				  			} else {
				  				if (minutes < 10) {
				  					formattedDate = year + Message[langCode].YEAR + month + Message[langCode].MONTH + day + Message[langCode].DAY + ", " + hours + ":0" + minutes;
				  				} else {
				  					formattedDate = year + Message[langCode].YEAR + month + Message[langCode].MONTH + day + Message[langCode].DAY + ", " + hours + ":" + minutes;
				  				}
				  			}
				  		}
			  		}
			  		return formattedDate;
			  	},
			  	translateMonthYearString : function(dateString) {
			  		var langCode = AppState.currentLangCode;
			  		var formattedDate = dateString;
			  		var date = new Date("01 "+dateString);
			  		if (date && langCode == Constants.LANG_TC || langCode == Constants.LANG_SC) {
			  			var year = date.getFullYear();
			  			var month = date.getMonth() + 1;
			  			formattedDate = year + Message[langCode].YEAR + month + Message[langCode].MONTH;
			  		}
			  		return formattedDate;
			  	},
			  	prepareRAQConfig: function(raqConfigData) {
			  		var raqConfig = {
			  				configFileVersion : raqConfigData.configFileVersion
			  		};
			  		var contentMap = new Map();
			  		var levelMap = new Map();
			  		raqConfigData.contentList.forEach(function(contentItem) {
			  			var langCode = contentItem.language;
			  			
			  			contentItem.dataList.forEach(function(dataItem) {
			  				var content = {
			  					questionList: dataItem.questionList
			  				};
			  				dataItem.typeList.forEach(function(type) {
			  					contentMap.set(langCode+'_'+type.toUpperCase(),content);
			  				});
				  			
				  		});
			  			contentItem.levelList.sort(function(a, b) {
			  			  return a.level - b.level;
			  			});
			  			levelMap.set(langCode,contentItem.levelList);
			  		});
			  		var scoreMatrixMap = new Map();
			  		raqConfigData.scoreMatrixList.forEach(function(scoreMatrixItem) {
			  			var scoreMatrix = {
			  					rule : scoreMatrixItem.rule,
			  					scoreRuleList : scoreMatrixItem.scoreRuleList,
			  					levelRuleList : scoreMatrixItem.levelRuleList,
			  					classification : scoreMatrixItem.classification
			  			};
			  			scoreMatrixItem.typeList.forEach(function(type) {
			  				scoreMatrixMap.set(type.toUpperCase(),scoreMatrix);
			  			});
				  			
				  	});
			  		var miscMap = new Map();
	  				raqConfigData.miscList.forEach(function(miscItem) {
	  					miscMap.set(miscItem.type.toUpperCase(),miscItem);
		  			});
			  		raqConfig.contentList = contentMap;
			  		raqConfig.levelList = levelMap;
			  		raqConfig.scoreMatrixList = scoreMatrixMap;
			  		raqConfig.miscList = miscMap;
			  		return raqConfig;  		
			  	},
			  	initMQA : function (){
			  		if(Environment.isEnableMQA==='Y'){
			  			LogUtil.logInfo('MQA startNewSession');
				  		MQA.startNewSession({
				  			//Required for IBM MobileFirst Quality Assurance
				        	mode: Environment.MQAMode,
				        	serverURL: Environment.MQAProtocol + "://" + Environment.MQAHost,
				        	reportOnShakeEnabled: true,
				        	versionName: Environment.appVersion, // app release version
				        	ios: {
				        		appKey: Environment.MQAIOSAppKey,
				        		screenShotsFromGallery: true,
				        		versionNumber: Environment.appVersion // app version number
				        	}
						},
						{
						    success: function () { LogUtil.logInfo('MQA startNewSession Success'); },
						    error: function (error) { LogUtil.logError('MQA startNewSession Fail'+error); }
						});
			  		}
			  	}
		};
	return CommonUtil;
});
