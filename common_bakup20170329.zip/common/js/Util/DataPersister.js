define([
  'js/appConfig',
  'js/Util/LogUtil',
  'environment'
  ], function(AppConfig,LogUtil,Environment){

    var DataPersister = {

      init : function(successCallback,failCallback) {  
        var _this = this;
        if (this.checkWLJSONStoreSupport()){
          LogUtil.logDebug('DEBUG: Initializing WL.JSONStore...');
          WL.JSONStore.init(AppConfig.localCollectionsDefinition,{username: Environment.JSONStoreUser, password: Environment.JSONStoreKey })            
            .then(function () {
              LogUtil.logInfo('INFO: WL.JSONSTORE initialization success');
              
              LogUtil.logDebug('DEBUG: Check if JSONStore data existed');  
              
              var query = {name: AppConfig.appDataInitCheckName};
         	 
	          var options = {
	          	  exact: true
	          };
              
              WL.JSONStore.get(AppConfig.appDataCollectionName)
              .find(query, options)
              .then(function (arrayResults) {              
                LogUtil.logTrace('TRACE: arrayResults count = ' + arrayResults.length);   
                LogUtil.logInfo('INFO: Init JSONStore data if not yet existed');   
                if (arrayResults.length === 0 ){
                  LogUtil.logInfo('INFO: Initialzing JSONStore data ...');  

                  var data = AppConfig.defaultAppData;
                  var addOptions = { markDirty: false };  
                  WL.JSONStore.get(AppConfig.appDataCollectionName)
                  .add(data, addOptions)
                  .then(function (numberOfDocumentsAdded) {
                    LogUtil.logInfo('INFO: Number of documents added = ' + numberOfDocumentsAdded);
                    if (typeof successCallback === 'function') {
                        successCallback();
                    }
                  })            
                  .fail(function (errorObject) {
                    LogUtil.logError('ERROR: WL.JSONStore init data fail : ' + errorObject);
                    _this.handleJSONStoreError(errorObject);
                    if (typeof failCallback === 'function') {
                        failCallback(errorObject);
                    }               
                  });   
                } else {
                  LogUtil.logInfo('INFO: JSONStore data has been initialized');  
                  WL.JSONStore.get(AppConfig.appDataCollectionName).findAll()
                  .then(function (jsonstoreDocuments) {
                      var isSuccessful = true;
                	  if (jsonstoreDocuments && AppConfig.defaultAppData &&
                			  jsonstoreDocuments.length !== AppConfig.defaultAppData.length) {
                		  LogUtil.logInfo('INFO: jsonstoreDocuments.length : ' + jsonstoreDocuments.length);   
            			  LogUtil.logInfo('INFO: AppConfig.defaultAppData.length : ' + AppConfig.defaultAppData.length);   

            			  var updatedDoc = [];            			  
            			  // assume that AppConfig.defaultAppData could have more data than that saved in JSONStore
            			  for (var i = 0; i < AppConfig.defaultAppData.length; i++) {
            				  var found = false;
            				  for (var j = 0; j < jsonstoreDocuments.length; j++) {
                				  if (AppConfig.defaultAppData[i].name === jsonstoreDocuments[j].json.name) {
                					  found = true;
                					  break;
                				  }
                			  }
                			  if (!found) {
                    			  LogUtil.logInfo('INFO: ' + AppConfig.defaultAppData[i].name + ' not existed, will be added to JSONStore');   
                				  updatedDoc.push(AppConfig.defaultAppData[i]);
                			  }
            			  }
            			  if (updatedDoc.length > 0) {
            				  var addOptions = { markDirty: false };
            				  WL.JSONStore.get(AppConfig.appDataCollectionName)
            				  .add(updatedDoc, addOptions)
            				  .then(function (numberOfDocumentsAdded) {
            					  LogUtil.logInfo('INFO: Number of documents added = ' + numberOfDocumentsAdded);
            				  })            
            				  .fail(function (errorObject) {
            					  LogUtil.logError('ERROR: WL.JSONStore add data fail : ' + errorObject);
            					  isSuccessful = false;         
            				  });
            			  }
                	  } else {
                		  LogUtil.logInfo('INFO: jsonstoreDocuments.length and AppConfig.defaultAppData.length are the same : ' + jsonstoreDocuments.length);
                	  }
                	  if (isSuccessful) {
	                	  if (typeof successCallback === 'function') {
	                          successCallback();
	                      }
                	  } else {
                		  if (typeof failCallback === 'function') {
                              failCallback(errorObject);
                          }
                	  }
                  })
                  .fail(function (errorObject) {
                	  LogUtil.logTrace('ERROR: WL.JSONSTORE findAll() fail : ' + errorObject);
                	  _this.handleJSONStoreError(errorObject);
                	  if (typeof failCallback === 'function') {
                		  failCallback(errorObject);
                	  }
                  });
                }              
              })
              .fail(function (errorObject) {
                LogUtil.logTrace('ERROR: WL.JSONSTORE get() fail : ' + errorObject);
                _this.handleJSONStoreError(errorObject);
                if (typeof failCallback === 'function') {
                    failCallback(errorObject);
                }
              });   
            })
            .fail(function (errorObject) {
              LogUtil.logError('ERROR: WL.JSONSTORE initialization fail : ' + errorObject);
              _this.handleJSONStoreError(errorObject);
              if (typeof failCallback === 'function') {
                  failCallback(errorObject);
              }
            });                                     
        }else{
          LogUtil.logError('ERROR: WL.JSONStore is not supported!');
          if (AppConfig.allowWebLocalStorage) {
            if (this.checkWebStorageSupport()){
              LogUtil.logDebug('DEBUG: HTML5 LocalStorage is used instead in DEV mode');

              // Init Data
              
              if (localStorage.getItem('isAppDataInitialized') === undefined){
                LogUtil.logDebug('DEBUG: Init first time data in HTML5 LocalStorage ');
                localStorage.setItem('isAppDataInitialized','Y');
                localStorage.setItem('userPreferredLanguage','null');
              }else{
                LogUtil.logDebug('DEBUG: First time data has been initialized in HTML5 LocalStorage ');
              }

              if (typeof successCallback === 'function') {
                  successCallback();
              } 
            }else{
              LogUtil.logError('ERROR: DataPersister encountered errors! (2)');
              if (typeof failCallback === 'function') {
                  failCallback(null);
              }
            }
          }else{
            LogUtil.logError('ERROR: DataPersister encountered errors! (1)');
            if (typeof failCallback === 'function') {
                failCallback(null);
            }
          }       
        }        
      },     

      getAppDataByNameValue : function(itemName,successCallback,failCallback) {
        LogUtil.logDebug('DEBUG: getAppDataByNameValue() - itemName :' + itemName);    
        if (this.checkWLJSONStoreSupport()){
        	var query = {name: itemName};       	 
        	var options = {
        	  exact: true
        	 
        	};
            LogUtil.logDebug('DEBUG: preparing WL.JSONStore.get() :' + itemName);    
            WL.JSONStore.get(AppConfig.appDataCollectionName)
            .find(query, options)
            .then(function (arrayResults) {
              LogUtil.logTrace('TRACE: getAppDataByNameValue : ' + itemName);   
              LogUtil.logTrace('TRACE: arrayResults count = ' + arrayResults.length);    
              LogUtil.logTrace('TRACE: arrayResults[0] = ' + arrayResults[0]); 
              if(typeof(arrayResults[0])!=='undefined'){
	              LogUtil.logTrace('TRACE: arrayResults[0].json = ' + arrayResults[0].json);   
	              LogUtil.logTrace('TRACE: arrayResults[0].json.value = ' + arrayResults[0].json.value);   
	              successCallback(arrayResults[0].json.value);
              }else{
            	  LogUtil.logTrace('ERROR: DataPersister encountered errors! (4)');
            	  var errorObject = {
            		  err:'error type (4)',
            		  msg:'arrayResult is empty'
            	  };
            	  if (typeof failCallback === 'function') {
                	  failCallback(errorObject);
            	  }
              }
            })
            .fail(function (errorObject) {
              LogUtil.logTrace('ERROR: DataPersister encountered errors! (3)');
              if (typeof failCallback === 'function') {
            	  failCallback(errorObject);
        	  }
            });

        }else if (AppConfig.allowWebLocalStorage)        
        {          
          if (this.checkWebStorageSupport()){
        	  if (typeof successCallback === 'function') {
                  successCallback(localStorage.getItem(itemName));
        	  }
          }
        }else{
          LogUtil.logError('ERROR: DataPersister getAppDataByNameValue() encounter errors!');     
        }
      },
      setAppDataByNameValue : function(itemName, itemValue,successCallback,failureCallback) {      
        LogUtil.logDebug('DEBUG: setAppDataByNameValue() - itemName :' + itemName + ', itemValue :' +itemValue);    
        if (this.checkWLJSONStoreSupport()){
            var data = [{name : itemName, value:itemValue}]; 

            var changeOptions = {                
              replaceCriteria : ['name'],
            };

            LogUtil.logDebug('DEBUG: Replacing WL.JSONStore.set() :' + itemName);    
            WL.JSONStore.get(AppConfig.appDataCollectionName)
            .change(data, changeOptions)
            .then(function () {
              LogUtil.logTrace('TRACE: setAppDataByNameValue() data change successful : ' + itemName);
			  if (typeof successCallback === 'function') {
				  successCallback(itemValue);
			  }
            }).fail(function (errorObject) {
              LogUtil.logERROR('ERROR: setAppDataByNameValue() data change fail');  
              if (failureCallback && typeof failureCallback === 'function') {
            	  failureCallback(errorObject);
              }
            });
        }else if (AppConfig.allowWebLocalStorage){     
          if (this.checkWebStorageSupport()){
            LogUtil.logInfo('Set data to local storage');  
            return localStorage.setItem(itemName,itemValue);
          }
        }else{
          LogUtil.logError('ERROR: DataPersister setAppDataByNameValue() encounter errors!');     
        }
      },
      clearAppDataByNameValue : function(itemName,successCallback,failCallback) {
          LogUtil.logDebug('DEBUG: clear AppDataByNameValue() - itemName :' + itemName);    
          if (this.checkWLJSONStoreSupport()){
              var query = {name:itemName};

              var options = {                
            	exact: true,
                markDirty: true
              };

              LogUtil.logDebug('DEBUG: preparing WL.JSONStore.clear() :' + itemName);    
              WL.JSONStore.get(AppConfig.appDataCollectionName)
              .remove(query, options)
              .then(function (numberOfDocumentsRemoved) {
            	  if (typeof successCallback === 'function') {
                      successCallback();
            	  }
            	  LogUtil.logDebug('DEBUG: number of document removed: ' + numberOfDocumentsRemoved);    
                })
              .fail(function (errorObject) {
            	  LogUtil.logTrace('ERROR: DataPersister encountered errors! (3)');
                  if (typeof failCallback === 'function') {
                	  failCallback(errorObject);
            	  	}
              });
                          
          }else if (AppConfig.allowWebLocalStorage){          
            if (this.checkWebStorageSupport()){
          	  if (typeof successCallback === 'function') {
          		  	localStorage.removeItem(itemName);
                    successCallback();
          	  }
            }
          }else{
            LogUtil.logError('ERROR: DataPersister clearAppDataByNameValue() encounter errors!');     
          }
        },
      checkWLJSONStoreSupport : function(){
    	if(typeof(WL) != 'undefined') {     
          if (typeof(WL.JSONStore) != 'undefined'){
            LogUtil.logDebug('DEBUG: WL JSONStore is ready...');      
            return true;  
          }else{
            LogUtil.logError('ERROR: WL.JSONStore is not defined!');        
            return false;   
          }                    
        }else{
          LogUtil.logError('ERROR: WL is not defined!');        
          return false;
        }
      },   
      checkWebStorageSupport : function(){
        if(typeof(Storage) != 'undefined') {          
          LogUtil.logDebug('DEBUG: Web Storage is used instead...');  
          return true;      
        }else{          
          LogUtil.logDebug('DEBUG: Web Storage is not supported!');  
          return false;     
        }
      },
      handleJSONStoreError:function(errorObject){
    	  LogUtil.logDebug('JSONStore Error Code : ' +errorObject.err);  
    	  if (errorObject.err === -3) {
				WL.JSONStore.destroy();
				WL.Client.reloadApp();
    	  }
      }
    };

    return DataPersister;

  });
