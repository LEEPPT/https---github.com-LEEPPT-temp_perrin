define([ 'js/Util/LogUtil', 'js/Util/DataPersister', 'js/appState',
         'js/message', 'environment' ], function(LogUtil, DataPersister,
        		 AppState, Message, Environment) {

	var PdfPluginUtil = {
			generateRaqPDF : function(reqData, successCallback, failureCallback) {
				cordova.exec(function(data) {
					LogUtil.logInfo("PdfPluginUtil -> generateRaqPDF -> successCallback");
					successCallback(data);
				}, function(data) {
					failureCallback(data);
					LogUtil.logInfo("PdfPluginUtil -> generateRaqPDF -> successCallback");
				}, "PdfPlugin", "editPdf", [ JSON.stringify(reqData) ]);
			},
			generateTargetPortfolioPDF : function(targetData, successCallback, failureCallback) {
				cordova.exec(function(data) {					
					LogUtil.logInfo("PdfPluginUtil -> generateTargetPortfolioPDF -> successCallback");
					
					targetData.fileContent = data;
					successCallback(targetData);
				}, function(data) {
					LogUtil.logInfo("PdfPluginUtil -> generateTargetPortfolioPDF -> failureCallback");
					
					failureCallback(targetData);
				}, "PdfPlugin", "generateTargetPortfolioPDF", [JSON.stringify(targetData)]);
			}			
	};
	return PdfPluginUtil;
});
