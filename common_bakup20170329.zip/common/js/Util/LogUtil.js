define([
	'js/appConfig',	
	'js/constants',
	'environment'
	], function(AppConfig,Constants,Environment){

		var LogUtil = {

			 logError  : function(message) {
				 if (Constants.ERROR > Environment.logLevel){
					 console.log.bind(console);
				 }else{
					 
					 if(Environment.remoteLogging){ 
	
						 this.logger.error(message);
						 this.logCount = this.logCount+1;
						 if(this.logCount>=Environment.logSize && AppConfig.enableLogSender){
							 WL.Logger.send();
							 this.logCount=0;
						 }
					 }
				 }
			 },

			 logWarn : function(message) {
				 if(Constants.WARN > Environment.logLevel){
					 console.log.bind(console); 
				 }else{
					 
					 if(Environment.remoteLogging){ 
						 this.logger.warn(message);
						 this.logCount = this.logCount+1;
						 if(this.logCount>=Environment.logSize && AppConfig.enableLogSender){
							 WL.Logger.send();
							 this.logCount=0;
						 }
					 }
				 }
			 },

			 logInfo : function(message) {
				 if(Constants.INFO > Environment.logLevel){
					 console.log.bind(console);
				 }else{
					 
					 if(Environment.remoteLogging){ 
						 
						 this.logger.info(message);	
						 this.logCount = this.logCount+1;
						 if(this.logCount>=Environment.logSize && AppConfig.enableLogSender){
							 WL.Logger.send();
							 this.logCount=0;
						 }
					 }
				 }
			 },

			 logDebug : function(message) {
				 if(Constants.DEBUG > Environment.logLevel){
					 console.log.bind(console);
				 }else{
					 
					 if(Environment.remoteLogging){
						 this.logger.debug(message);
						 this.logCount = this.logCount+1;
						 if(this.logCount>=Environment.logSize && AppConfig.enableLogSender){
							 WL.Logger.send();
							 this.logCount=0;
						 }
					 }
				 }
			 },

			 logTrace : function(message) {
				 if(Constants.TRACE > Environment.logLevel){
					 console.log.bind(console);
				 }else{
					 
					 if(Environment.remoteLogging){
						 this.logger.trace(message);
						 this.logCount = this.logCount+1;
						 if(this.logCount>=Environment.logSize && AppConfig.enableLogSender){
							 WL.Logger.send();
							 this.logCount=0;
						 }
					 }
				 }
			 },
			 
			 initialize : function(){
				 this.logger = WL.Logger.create({pkg: Environment.loggerPackageName});
				 WL.Logger.config({autoSendLogs: false,level:Environment.logFilterLevel});
			 },
			 logCount : 0

			 
			};
			return LogUtil;
		});
