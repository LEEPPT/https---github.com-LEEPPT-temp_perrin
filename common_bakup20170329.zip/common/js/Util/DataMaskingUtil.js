define([
        'js/Util/LogUtil'
	], function(LogUtil){

		var DataMaskingUtil = {
			
			maskByPosition : function (input,index,key){
				return input.substring(0, index) + key + input.substring(index + 1);
			},
			maskAccountName : function (input){
				return this.maskNameByPattern(input,this.accountNamePattern);
			},
			maskCustomerName : function (input){
				return this.maskNameByPattern(input,this.customerNamePattern);
			},
			maskNameByPattern : function (input,pattern){
				var nameList = input.split(' ');
				var resultString = '';
				if(pattern.isIgnoreTitle){
					if(this.titleList.indexOf(nameList[0].toUpperCase())>=0){
						resultString = nameList[0]+' ';
						nameList = nameList.splice(1,nameList.length);
					}
				}
				var maskNameList = [];
				for(i=0;i<nameList.length;i++){
					if(i<pattern.nameStartIndex){
						maskNameList.push(nameList[i]);
					}else {
						var maskString = nameList[i];
							for(j=pattern.maskingStartIndex;j<maskString.length;j++){
								maskString = this.maskByPosition(maskString,j,pattern.maskingKey);
							}
						maskNameList.push(maskString);
					}
					LogUtil.logTrace('maskNameList '+maskNameList);
				}
				resultString = resultString + maskNameList[0];
				var resultNameList = maskNameList.splice(1,maskNameList.length);
				resultNameList.forEach(function(name) {
					resultString = resultString + ' ' + name;
				});
				LogUtil.logTrace('resultString '+resultString);
				return resultString;
			},
			maskAccountNumber : function (input){
				if(this.isAccountNumber(input)){
					var _this = this;
					var maskString = input;
					this.accountNumberPattern.maskPattern.forEach(function(pattern) {
						maskString=_this.maskByPosition(maskString,pattern.position,pattern.key); 
					});
					return maskString;
				}else {
					return input;
				}
				
				
			},
			isAccountNumber : function (input){
				input = input.trim();
				if(input.indexOf(this.accountNumberPattern.prefix) !== 0){
					return false;
				}else if(this.accountNumberPattern.length!==input.length){
					return false;
				}else if(isNaN(Number(input.replace(/-/g,'')))){
					return false;
				}else if(!this.matchKeyWordList(input,this.accountNumberPattern.keyWordList)){
					return false;
				}else{
					return true;
				}
				
			},
			matchKeyWordList : function (input,keyWordList){
				keyWordList.forEach(function(keyWord) {
				   if(input[keyWord.position]!==keyWord.key){
					   return false;
				   }
				  });
				return true;
				
			},
			accountNumberPattern : {
				prefix : '015-260-',
				length : 16,
				keyWordList : [
				               {position:3,key:'-'},
				               {position:7,key:'-'}
				               ],
				maskPattern : [
				 				{position:10,key:'*'},
				 				{position:11,key:'*'},
								{position:12,key:'*'}
				 			  ]
				
			},
			accountNamePattern : {
				nameStartIndex : 1,
				maskingStartIndex : 1,
				maskingKey : '*',
				isIgnoreTitle : true
				
			},
			customerNamePattern : {
				nameStartIndex : 1,
				maskingStartIndex : 1,
				maskingKey : '*',
				isIgnoreTitle : true
			},
			titleList : ['DR',
			             'HON',
			             'LADY',
			             'LORD',
			             'MISS',
			             'MR',
			             'MRS',
			             'MS',
			             'NO TITLE',
			             'PROF',
			             'SIR'
			             ]
			
		};
	return DataMaskingUtil;
});
