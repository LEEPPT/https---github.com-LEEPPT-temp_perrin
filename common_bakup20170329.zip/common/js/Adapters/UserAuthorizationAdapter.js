define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var UserAuthorizationAdapter = {
			getUserAuthorizationInfo: function(userID,successCallback,failureCallback) {
					LogUtil.logInfo('UserAuthorizationAdapter : Attempt to getUserAuthorizationInfo');	
					function getUserInfoSuccess(data) {
						LogUtil.logInfo('UserAuthorizationAdapter : getUserAuthorizationInfo : success');	
						successCallback(data);
					}
					function getUserInfoFailure(data) {
						LogUtil.logInfo('UserAuthorizationAdapter : getUserAuthorizationInfo : failure');	
						failureCallback(data);
					}
					var params=[userID];
					var invocationData = {
							adapter: 'UserAuthorizationAdapter', 
							procedure: 'getUserAuthorizationInfo',
							parameters: params
					};
					WL.Client.invokeProcedure(invocationData, {
						onSuccess: getUserInfoSuccess,
						onFailure: getUserInfoFailure,
						timeout: 10000 
					});
			
		}
		
};
		return UserAuthorizationAdapter;
});


