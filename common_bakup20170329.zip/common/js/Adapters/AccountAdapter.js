define([
  "js/Util/LogUtil"
  ], function(LogUtil){
	var AccountAdapter = {
		getEntitledAccounts: function(searchCriteria,successCallback,failureCallback) {
			LogUtil.logInfo("AccountAdapter : getEntitledAccounts: Attempt to getEntitledAccounts");
			
			function getEntitledAccountsSuccess(data) {
				LogUtil.logInfo("AccountAdapter : getEntitledAccounts : getEntitledAccountsSuccess : " + data);
				successCallback(data);
			}
			function getEntitledAccountsFailure(data) {
				LogUtil.logError("AccountAdapter : getEntitledAccounts : getEntitledAccountsFailure : " + data);
				failureCallback(data);
			}
			var params=[
			            searchCriteria.userID,
			            searchCriteria.customerName, 
			            searchCriteria.accountName, 
			            searchCriteria.accountNumber
			    ];
			var invocationData = {
					adapter: "AccountServiceAdapter", 
					procedure: "getEntitledAccounts",
					parameters: params
			};
			WL.Client.invokeProcedure(invocationData, {
				onSuccess: getEntitledAccountsSuccess,
				onFailure: getEntitledAccountsFailure,
				timeout: 10000 
			});
			
		}
		
};
		return AccountAdapter;
});
