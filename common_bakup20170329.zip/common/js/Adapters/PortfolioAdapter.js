define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var PortfolioAdapter = {
		getCustomerPortfolio: function(params,successCallback,failureCallback) {
			LogUtil.logInfo('PortfolioAdapter : getCustomerPortfolio : Attempt to getCustomerPortfolio');
			function getCustomerPortfolioSuccess(data) {
				LogUtil.logInfo('PortfolioAdapter : getCustomerPortfoliosSuccess : ' + data);
				successCallback(data);
			}
			function getCustomerPortfolioFailure(data) {
				LogUtil.logError('PortfolioAdapter : getCustomerPortfolioFailure : ERROR - ' + data);
				failureCallback(data);
			}
			var paramList=[
			            params.userID,
			            params.accountList,
			            params.portfolioCurrency
			    ];
			LogUtil.logInfo("paramList");
			LogUtil.logInfo(paramList);
			var invocationData = {
					adapter: "CustomerPortfolioAdapter", 
					procedure: "getCustomerPortfolio",
					parameters: paramList
			};
			WL.Client.invokeProcedure(invocationData, {
				onSuccess: getCustomerPortfolioSuccess,
				onFailure: getCustomerPortfolioFailure,
				timeout: 10000 
			});
			
		},
		
		uploadTargetPortfolioPDFFiles:function(userID, fileContent,successCallback,failureCallback){
			LogUtil.logInfo('PortfolioAdapter : Attempt to uploadTargetPortfolioPDFFiles');	
			function uploadPDFSuccess(data) {
				LogUtil.logInfo('PortfolioAdapter : uploadTargetPortfolioPDFFiles : success');	
				successCallback(data);
			}			
			function uploadPDFFailure(data) {
				LogUtil.logInfo('PortfolioAdapter : uploadTargetPortfolioPDFFiles : failure');	
				failureCallback(data);
			}			
			var params=[userID,fileContent];		
			var invocationData = {
					adapter: 'TargetPortfolioAdapter', 
					procedure: 'uploadTargetPortfolioPDFFiles',
					parameters: params
			};
			
			WL.Client.invokeProcedure(invocationData, {
				onSuccess: uploadPDFSuccess,
				onFailure: uploadPDFFailure,
				timeout: 10000 
			});
		}
		
};
		return PortfolioAdapter;
});
