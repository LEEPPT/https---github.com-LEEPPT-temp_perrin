define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var RAQAdapter = {
			getRAQConfigurations: function(userID,successCallback,failureCallback) {
					LogUtil.logInfo('RAQAdapter : Attempt to getRAQConfigurations');	
					function getRAQConfigurationsSuccess(data) {
						LogUtil.logInfo('RAQAdapter : getRAQConfigurations : success');	
						successCallback(data);
					}
					function getRAQConfigurationsFailure(data) {
						LogUtil.logInfo('RAQAdapter : getRAQConfigurations : failure');	
						failureCallback(data);
					}
					var params=[userID];
					var invocationData = {
							adapter: 'RAQAdapter', 
							procedure: 'getRAQConfigurations',
							parameters: params
					};
					WL.Client.invokeProcedure(invocationData, {
						onSuccess: getRAQConfigurationsSuccess,
						onFailure: getRAQConfigurationsFailure,
						timeout: 10000 
					});
			
			},
			
			getRAQPDFTemplates:function(userID, fileList,successCallback,failureCallback) {
				LogUtil.logInfo('RAQAdapter : Attempt to getRAQPDFTemplates');	
				function getRAQPDFTemplatesSuccess(data) {
					LogUtil.logInfo('RAQAdapter : getRAQPDFTemplates : success');	
					successCallback(data);
				}
				function getRAQPDFTemplatesFailure(data) {
					LogUtil.logInfo('RAQAdapter : getRAQPDFTemplates : failure');	
					failureCallback(data);
				}
				var params=[userID,fileList];
				var invocationData = {
						adapter: 'RAQAdapter', 
						procedure: 'getRAQPDFTemplates',
						parameters: params
				};
				WL.Client.invokeProcedure(invocationData, {
					onSuccess: getRAQPDFTemplatesSuccess,
					onFailure: getRAQPDFTemplatesFailure,
					timeout: 15000 
				});				
			},
			
			 uploadRAQPDFFiles:function(userID, fileContent, customerName, accountName, accountNumber,successCallback,failureCallback){
				 	LogUtil.logInfo('RAQAdapter : Attempt to uploadRAQPDFFiles');	
					function uploadRAQPDFSuccess(data) {
						LogUtil.logInfo('RAQAdapter : uploadRAQPDFFiles : success');	
						successCallback(data);
					}
					
					function uploadRAQPDFFailure(data) {
						LogUtil.logInfo('RAQAdapter : uploadRAQPDFFiles : failure');	
						failureCallback(data);
					}
					
					var params=[userID,fileContent,customerName,accountName,accountNumber];
					
					var invocationData = {
							adapter: 'RAQAdapter', 
							procedure: 'uploadRAQPDFFiles',
							//procedure: 'getRAQConfigurations',
							parameters: params
					};
					
					WL.Client.invokeProcedure(invocationData, {
						onSuccess: uploadRAQPDFSuccess,
						onFailure: uploadRAQPDFFailure,
						timeout: 10000 
					});
			 }
		
};
		return RAQAdapter;
});


