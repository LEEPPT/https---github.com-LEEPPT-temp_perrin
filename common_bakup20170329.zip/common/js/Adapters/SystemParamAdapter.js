define([
  'js/Util/LogUtil'
  ], function(LogUtil){
	var SystemParamAdapter = {
			getSystemParams: function(userID,successCallback,failureCallback) {
					LogUtil.logInfo('SystemParamAdapter : Attempt to getSystemParams');	
					function getSystemParamSuccess(data) {
						LogUtil.logInfo('SystemParamAdapter : getSystemParams : success');	
						successCallback(data);
					}
					function getSystemParamFailure(data) {
						LogUtil.logInfo('SystemParamAdapter : getSystemParams : failure');	
						failureCallback(data);
					}
					var params=[userID];
					var invocationData = {
							adapter: 'SystemParamAdapter', 
							procedure: 'getSystemParam',
							parameters: params
					};
					WL.Client.invokeProcedure(invocationData, {
						onSuccess: getSystemParamSuccess,
						onFailure: getSystemParamFailure,
						timeout: 10000 
					});
			
		}
		
};
		return SystemParamAdapter;
});


