define(['js/Util/LogUtil',
        'js/Util/DataPersister',
        'js/Util/CommonUtil',
        'js/appState',
        'js/constants',
        'js/appConfig',
        'js/message',
        'js/Adapters/SystemParamAdapter',
        'js/Adapters/RAQAdapter',
        'js/Adapters/UserAuthorizationAdapter',
        'js/Util/FunctionActivator'
        ], function(LogUtil,DataPersister,CommonUtil,AppState,Constants,AppConfig,Message,SystemParamAdapter,RAQAdapter,UserAuthorizationAdapter, FunctionActivator) {
	/** 
	 * @fileOverview Initialization of the application
	 * step 1
	 */
	var initialize = function() {				
				LogUtil.initialize();				
				DataPersister.init(dpOnInitSuccess,dpOnInitFail);
				
	};
	
	var dpOnInitSuccess = function(){      
	      LogUtil.logDebug('DEBUG: dpOnInitSuccess');
	      loadPreferredLanguage();  
	      if(WL.Client.getEnvironment()!==WL.Environment.PREVIEW){
	    	  checkAppConnectStatus();
	    	  CommonUtil.initMQA();
	      }else{
	    	  AppConfig.enableLogSender = true;
	    	  CommonUtil.bootstrap();
	    	  CommonUtil.checkServerConnection(onConnectSuccess,onConnectFailure,onNetworkFailure);
	      }
	      
	};

	var dpOnInitFail = function(){
	      LogUtil.logDebug('DEBUG: dpOnInitFail');
	      LogUtil.logDebug('ERROR: DataPersister Failed!');
	      loadPreferredLanguage();
	      var langCode = AppState.currentLangCode;
		  var deleteButton = Message[langCode].BTN_DELETE;
		  var cancelButton = Message[langCode].BTN_CANCEL;
		  var title = Message[langCode].ERR_LOCAL_STORAGE_FAILURE_TITLE;
		  var message = Message[langCode].ERR_LOCAL_STORAGE_FAILURE;
	      WL.SimpleDialog.show(title,message,[{text:deleteButton, handler: function() {
	    	  WL.JSONStore.destroy();
	    	  WL.Client.reloadApp();						
			}
	      },{text:cancelButton, handler:function(){
	    	  CommonUtil.quitApp();
	      }}]); 
	    };
	    
	var prepareOfflineHandling = function(source,errorCode){
		var langCode = AppState.currentLangCode;
		var zpbErrorCode = '';
		if(typeof errorCode!=='undefined'){
			zpbErrorCode = errorCode;
		}
		DataPersister.getAppDataByNameValue('isFirstTimeLaunch',
          function (value) {
            LogUtil.logDebug('DEBUG: isFirstTimeLaunch '+ value);
            if (typeof value === 'undefined' || value === 'null') {
              LogUtil.logDebug('DEBUG: isFirstTimeLaunch is not defined.');
              CommonUtil.handleAppError('Generic Error',Message[langCode].ERR_GENERAL_MESSAGE_TITLE,Message[langCode].ERR_GENERAL_MESSAGE,true);
            } else {
            	AppState.isFirstTimeLaunch = value;
            	if(AppState.isFirstTimeLaunch==='N'){
            		
            		if(AppState.isNetworkConnected==='false'){
            			CommonUtil.handleAppError('Connection failure - No internet connection (Subsequent app launch)',Message[langCode].ERR_NO_INTERNET_CONNECTION_TITLE,Message[langCode].ERR_NO_INTERNET_CONNECTION,false,loadSystemParam);
            		}else if(AppState.serverConnectionState===Constants.SERVER_DISCONNECTED){
            			CommonUtil.handleAppError('Connection failure - MobileFirst server connection failure (Subsequent app launch)',Message[langCode].ERR_MFP_CONNECTION_FAILURE_TITLE,Message[langCode].ERR_MFP_CONNECTION_FAILURE,false,loadSystemParam);
            		}else if(source==='appConfigInitFail'){
            			CommonUtil.handleAppError('Retrieve app configuration failure (Subsequent app launch)',Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_TITLE,Message[langCode].ERR_RETRIEVE_APP_CONFIGURE,false,loadSystemParam);
            		}
            	}else{
            		if(AppState.isNetworkConnected==='false'){
            			CommonUtil.handleAppError('Connection failure - No internet connection (First time app launch)',Message[langCode].ERR_CONNECTION_FAILURE_FIRST_TIME,Message[langCode].ERR_NO_INTERNET_CONNECTION_FIRST_TIME,true);
            		}else if(AppState.serverConnectionState===Constants.SERVER_DISCONNECTED){
            			CommonUtil.handleAppError('Connection failure - MobileFirst server connection failure (First time app launch)',Message[langCode].ERR_MFP_CONNECTION_FAILURE_FIRST_TIME_TITLE,Message[langCode].ERR_MFP_CONNECTION_FAILURE_FIRST_TIME,true);
            		}else if(source==='appConfigInitFail'){
            			CommonUtil.handleAppError('Retrieve app configuration failure (First time app launch)',Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE+zpbErrorCode,true);
            		}else if(source==='userInfoInitFail'){
            			CommonUtil.handleAppError('Retrieve user authorization failure (First time app launch) - MobileFirst server connection failure',Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE,true);
            		}else {
            			CommonUtil.handleAppError('Generic Error',Message[langCode].ERR_GENERAL_MESSAGE_TITLE,Message[langCode].ERR_GENERAL_MESSAGE,true);
            		}
            	}
            }
        },
        function(errorObject){
        	LogUtil.logDebug('DEBUG: isFirstTimeLaunch is not defined.');
        	CommonUtil.handleAppError('Generic Error',Message[langCode].ERR_GENERAL_MESSAGE_TITLE,Message[langCode].ERR_GENERAL_MESSAGE,true);
        });
		
	};
	var checkAppConnectStatus = function(){  
        cordova.exec(function(data){
        	LogUtil.logInfo('AppConnect checkAppConnectStatus callback');
        	var errorMsg;
        	var langCode = AppState.currentLangCode;
        	if(data.managedPolicy!=='Managed'){
        		errorCode = data.managedPolicyCode;
        		CommonUtil.handleAppConnectError('User authentication failure - Error returned from MobileIron',errorCode,onConnectSuccess,onConnectFailure,onNetworkFailure);
        	}else if(data.authState !=='Authorized'){
        		errorCode = data.authStateCode;
        		CommonUtil.handleAppConnectError('User authentication failure - Error returned from MobileIron',errorCode,onConnectSuccess,onConnectFailure,onNetworkFailure);
        	}else if(typeof data.userID === 'undefined' || data.userID === 'null'|| data.userID === null||data.userID === ''){
        		errorCode = 'NO_USER_ID';
        		CommonUtil.handleAppConnectError('User authentication failure - Error returned from MobileIron',errorCode,onConnectSuccess,onConnectFailure,onNetworkFailure);
        	}else {
        		loadUserID(data.userID);
            	CommonUtil.checkServerConnection(onConnectSuccess,onConnectFailure,onNetworkFailure);
        	}
        	
        	
        }, function(data){
        	errorCode = 'APPCONNECT_NOT_READY';
        	CommonUtil.handleAppConnectError('User authentication failure - Error returned from MobileIron',errorCode);
        }, 'AppConnectPlugin', 'getAppConnectStatus');
    };
    
	var onConnectSuccess = function(){  
		LogUtil.logInfo('wl server connect success.');
		AppState.appMode = Constants.APP_MODE_ONLINE;
		AppState.serverConnectionState = Constants.SERVER_CONNECTED;
		logAppInitStatus();
		WL.Client.checkForDirectUpdate();
		initAppConfig();
		
    };
    
    var onConnectFailure = function (){
    	LogUtil.logInfo('wl server connect fail');
    	AppState.appMode = Constants.APP_MODE_OFFLINE;
    	AppState.serverConnectionState = Constants.SERVER_DISCONNECTED;
    	logAppInitStatus();
    	AppConfig.enableLogSender = true;
    	prepareOfflineHandling('onConnectFailure');
    };
    
    var onNetworkFailure = function (){
    	AppState.appMode = Constants.APP_MODE_OFFLINE;
		busyIndicator.hide();
		prepareOfflineHandling('onNetworkFailure');

    };
    
    var initAppConfig = function (){
    	SystemParamAdapter.getSystemParams(AppState.userID,appConfigInitSuccess,appConfigInitFail);
    };
    
    var appConfigInitSuccess = function(result){
    	LogUtil.logInfo('appConfigInitSuccess');
    	var appConfigData = result.responseJSON;    	
	    var configList = appConfigData.config;	    	
	    var systemParam = {
	    		config : configList,
	    		stdPortfolioModel : appConfigData.stdPortfolioModel,
	    		lastDownloadTime : Date.now(),
	    		raqInfo : appConfigData.raqConfiguration
	    };
	    DataPersister.setAppDataByNameValue('systemParam',systemParam);
	    AppConfig.systemParam = systemParam;
	    var configMap = new Map();
	    configList.forEach(function(item) {
	    	configMap.set(item.key,item.value);
	    });
	    AppConfig.systemParam.configMap = configMap;
	    var dataExpPeriod = Number(AppConfig.systemParam.configMap.get('i_dataExpPeriod'));
	    CommonUtil.loadStoredPortfolio(dataExpPeriod);
    	CommonUtil.loadStoredTargetPortfolio(dataExpPeriod);
    	CommonUtil.loadStoredRAQResult(dataExpPeriod);
    	CommonUtil.loadStoredCallReport(dataExpPeriod);
    	initUserInfo();
	    loadLatestRAQConfig();
		
    };
    
    var appConfigInitFail = function(result){
    	LogUtil.logInfo('appConfigInitFail');
    	if(result.responseJSON){
    		var errorCode  = result.responseJSON.errorCode;
        	prepareOfflineHandling('appConfigInitFail',errorCode);
    	}else {
    		prepareOfflineHandling('appConfigInitFail');
    	}
    	
    };
    
    var initUserInfo = function (){
    	UserAuthorizationAdapter.getUserAuthorizationInfo(AppState.userID,userInfoInitSuccess,userInfoInitFail);
    };
    
    var userInfoInitSuccess = function(result){
    	LogUtil.logInfo('userInfoInitSuccess');
    	var userInfoData = result.responseJSON;
	    var userInfo = {
	        		lastDownloadTime : Date.now(),
	        		userFullName : userInfoData.userFullName,
	        		accessControlList : userInfoData.accessControlList,
	        		userID : AppState.userID
	    };
	    AppState.userInfo = userInfo;
	    DataPersister.setAppDataByNameValue('userInfo',userInfo);
	    AppState.isFirstTimeLaunch = 'N';
	    DataPersister.setAppDataByNameValue('isFirstTimeLaunch','N');
		FunctionActivator.setModuleAccessControlList(userInfo.accessControlList);
		loadFunctionActivatorByModuleAccess();
		loadFunctionActivatorByFunctionAccess();
		
	    if(userInfo.accessControlList!==null&&userInfo.accessControlList.length>0){
        	CommonUtil.bootstrap();
		    WL.App.hideSplashScreen();
	    }else {
	    	var langCode = AppState.currentLangCode;
	    	CommonUtil.handleAppError('User authorization failure - User is authenticated but not allowed to use the app',Message[langCode].ERR_USER_AUTHORIZATION_FAILURE_TITLE,Message[langCode].ERR_USER_AUTHORIZATION_FAILURE,true);
	    }
    	
    };
    
    var userInfoInitFail = function(result){
    	LogUtil.logInfo('userInfoInitFail');
    	if(result.responseJSON){
    		var langCode = AppState.currentLangCode;
    		var zpbErrorCode = result.responseJSON.errorCode;
    		if (zpbErrorCode) {
    			CommonUtil.handleAppError('Retrieve user authorization failure - Error returned from ZPB',Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE+zpbErrorCode,true);
    		} else {
    			CommonUtil.handleAppError('Retrieve user authorization failure - Error returned from ZPB',Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE,true);
    		}
    	}else {
    		prepareOfflineHandling('userInfoInitFail');
    	}	
	};
	
    var loadUserInfoFromLocal = function (){
    	var langCode = AppState.currentLangCode;
        var errorMsg = '';
        DataPersister.getAppDataByNameValue('userInfo',
          function (value) {
            LogUtil.logDebug('DEBUG: loadUserInfoFromLocal '+ value);
            if (typeof value === 'undefined' || value === 'null') {
              LogUtil.logDebug('DEBUG: No UserInfo on local storage is defined.');
              CommonUtil.handleAppError('Retrieve user authorization failure (First time app launch) - MobileFirst server connection failure',Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE,true);
            } else {
            	AppState.userInfo  = value;
            	var offlineUserID = AppState.userInfo.userID;
                var lastAuthTime = AppState.userInfo.lastDownloadTime;
                var offset = (Date.now() - lastAuthTime)/86400000;
                LogUtil.logDebug('DEBUG: last login time was '+offset +' days ago.');
                var dataExpPeriod = Number(AppConfig.systemParam.configMap.get('i_dataExpPeriod'));
                if(offlineUserID!==AppState.userID||(typeof(dataExpPeriod)!=='undefined'&&offset>=dataExpPeriod)){
                	errorMsg = Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE;
                	CommonUtil.handleAppError('Retrieve user authorization failure - local user info expired',Message[langCode].ERR_RETRIEVE_USER_AUTH_ZPB_FAILURE_TITLE,errorMsg,true);
                }else if(AppState.userInfo.accessControlList===null||AppState.userInfo.accessControlList.length===0){
                	CommonUtil.handleAppError('User authorization failure - User is authenticated but not allowed to use the app',Message[langCode].ERR_USER_AUTHORIZATION_FAILURE_TITLE,Message[langCode].ERR_USER_AUTHORIZATION_FAILURE,true);
                }else {
                	FunctionActivator.setModuleAccessControlList(AppState.userInfo.accessControlList);
            		loadFunctionActivatorByModuleAccess();
            		loadFunctionActivatorByFunctionAccess();
        	        
                	CommonUtil.bootstrap();
        	    	WL.App.hideSplashScreen();
                }
            }
        },
        function(errorObject){
        	LogUtil.logDebug('DEBUG: No UserInfo on local storage is defined.');
        	CommonUtil.handleAppError('Retrieve user authorization failure (First time app launch) - MobileFirst server connection failure',Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_USER_AUTH_FIRST_TIME_MFP_CONNECTION_FAILURE,true);
        });
        
       
    };

    var logAppInitStatus = function (){
    	LogUtil.logInfo('App Mode : '+AppState.appMode);
		LogUtil.logInfo('Network Connection : '+AppState.isNetworkConnected);
		LogUtil.logInfo('Server Connection : '+AppState.serverConnectionState);
		
		setTimeout(function(){
			busyIndicator.hide();
			},500);

    };

    var loadPreferredLanguage = function(){ 
      DataPersister.getAppDataByNameValue('userPreferredLanguage',
        function (value) {
          LogUtil.logDebug('DEBUG: loadAppState(userPreferredLanguage) : onDPSuccess : '+ value);
          if (typeof value === 'undefined' || value === 'null') {
               
            if (typeof(WL) != 'undefined'){
              LogUtil.logDebug('DEBUG: No prefered language selected, retrieving default language = ' + AppConfig.defaultLangCode);
              AppState.currentLangCode = AppConfig.defaultLangCode;
            }
            else{
              LogUtil.logDebug('DEBUG: No prefered language selected, retrieving default language =' + AppConfig.defaultLangCode);
              AppState.currentLangCode = AppConfig.defaultLangCode;
            }
          } else {
            AppState.currentLangCode = value;
          }
          LogUtil.logDebug('DEBUG: Current currentLangCode in AppState (after load) = ' + AppState.currentLangCode);

          DataPersister.setAppDataByNameValue('userPreferredLanguage',AppState.currentLangCode); //Persist State in LocalStorage
          busyIndicator.hide();
          busyIndicator = new WL.BusyIndicator(null, {text : Message[AppState.currentLangCode].BUSY_INDICATOR});
      });
    };
    
    var loadSystemParam = function(){ 
    	var langCode = AppState.currentLangCode;
        DataPersister.getAppDataByNameValue('systemParam',
          function (value) {
            LogUtil.logDebug('DEBUG: loadSystemParam '+ value);
            if (typeof value === 'undefined' || value === 'null') {
              LogUtil.logDebug('DEBUG: No SystemParam is defined.');
              CommonUtil.handleAppError('Retrieve app configuration failure (First time app launch)',Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE,true);
            } else {
            	AppConfig.systemParam = value;
            	var configMap = new Map();
            	AppConfig.systemParam.config.forEach(function(item) {
            		configMap.set(item.key,item.value);
            	 });
            	AppConfig.systemParam.configMap = configMap;
            	var dataExpPeriod = Number(AppConfig.systemParam.configMap.get('i_dataExpPeriod'));
            	CommonUtil.loadStoredPortfolio(dataExpPeriod);
            	CommonUtil.loadStoredTargetPortfolio(dataExpPeriod);
            	CommonUtil.loadStoredRAQResult(dataExpPeriod);
            	CommonUtil.loadStoredCallReport(dataExpPeriod);
            	loadUserInfoFromLocal();
            }
        },
        function(errorObject){
        	LogUtil.logDebug('DEBUG: No SystemParam is defined.');
        	CommonUtil.handleAppError('Retrieve app configuration failure (First time app launch)',Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE_TITLE,Message[langCode].ERR_RETRIEVE_APP_CONFIGURE_FIRST_TIME_ZPB_FAILURE,true);
        });
      };

      var loadUserID = function(currentUserID){ 
          DataPersister.getAppDataByNameValue('userID',
            function (value) {
              LogUtil.logDebug('DEBUG: loadAppState(userID) : onDPSuccess : '+ value);
              if (typeof value === 'undefined' || value === 'null'|| value === null||value === '') {
                  LogUtil.logDebug('DEBUG: No user ID is selected');
                  AppState.userID = currentUserID;
               
              } else {
              	LogUtil.logDebug('DEBUG: last login user ID is found :'+value);
              	if(value!==currentUserID){
              		DataPersister.clearAppDataByNameValue('storedPortfolio');
              		DataPersister.clearAppDataByNameValue('storedTargetPortfolio');
              		DataPersister.clearAppDataByNameValue('storedRAQResult');
              		DataPersister.clearAppDataByNameValue('storedCallReport');
              		DataPersister.clearAppDataByNameValue('userInfo');
              		DataPersister.clearAppDataByNameValue('rmRINumber');
              	}

              	AppState.userID = currentUserID;
              }
              DataPersister.setAppDataByNameValue('userID',AppState.userID); 
             
          });
        };
        var raqConfigInitSuccess = function(result){
	    	 if (result && result.responseJSON) {
	    		 LogUtil.logDebug('wlApp:raqConfigInitSuccess:');    	    		 	   	    	
	    	       	DataPersister.setAppDataByNameValue('raqConfig',result.responseJSON);
	    	    	AppState.raqConfig = CommonUtil.prepareRAQConfig(result.responseJSON);
	    	    	loadLatestPDFTemplete();
	    	 }else {
	    		 LogUtil.logDebug('raqConfigInitSuccess  : JSON response is false');            
	         }
	    }; 
	    
	    var raqConfigInitFail = function(data){
	    	LogUtil.logError('wlApp -> raqConfigInitFail');
	    	var errorCode = '';
            var errorMsg = '';
            var errorTitle = '';
            var langCode = AppState.currentLangCode;
            if (data && data.responseJSON && data.responseJSON.errorCode) {
                errorCode = data.responseJSON.errorCode;
                errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE;
                errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE + errorCode;
                LogUtil.logError('wlApp -> raqConfigInitFail : errorCode - ' + errorCode);
                CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure  - Error returned from ZPB',errorTitle,errorMsg,false);
                busyIndicator.hide();
            }else{
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('wlApp -> raqConfigInitFail : Network Info - '+networkInfo.isNetworkConnected);
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE;
		  				errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION;
		  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - No internet connection',errorTitle,errorMsg,false);
		  			}else{
		  				errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE;
		  				errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE;
		  				CommonUtil.handleAppError('Retrieve RAQ question content and scoring matrix failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
		  			}
	                busyIndicator.hide();
		  		});
            } 
	    }; 
	    
	    var raqPDFTemplatesInitSuccess = function(result){
	    	LogUtil.logInfo('wlApp -> raqPDFTemplatesInitSuccess');
	    	//LogUtil.logInfo(result.responseJSON);
	    	if (result.responseJSON && result.responseJSON.resultList && result.responseJSON.resultList.length > 0) {
	    		var raqPDFTemplate = result.responseJSON.resultList;
	    		raqPDFTemplate.forEach(function(template) {
	    			AppState.raqPDFTemplate.push(template);
	  	    	});

		       	DataPersister.setAppDataByNameValue('raqPDFTemplate',AppState.raqPDFTemplate);
		    	   	 
	    	} else {
	    		LogUtil.logError('wlApp -> raqPDFTemplatesInitSuccess : file list is empty');
	    	}
	    }; 
	    
	    var raqPDFTemplatesInitFailure = function(data){
	    	LogUtil.logError('raqPDFTemplatesInitFailure');
	    	var errorCode = '';
            var errorMsg = '';
            var errorTitle = '';
            var langCode = AppState.currentLangCode;
	    	
	    	if (data && data.responseJSON && data.responseJSON.errorCode) {
                errorCode = data.responseJSON.errorCode;
                errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE_TITLE;
                errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_ZPB_FAILURE + errorCode;
                LogUtil.logError('wlApp -> raqPDFTemplatesInitFailure : errorCode - ' + errorCode);
                CommonUtil.handleAppError('Retrieve RAQ PDF Templates failure  - Error returned from ZPB',errorTitle,errorMsg,false);
                busyIndicator.hide();
            }else{
            	WL.Device.getNetworkInfo(function(networkInfo) {
		  			AppState.isNetworkConnected = networkInfo.isNetworkConnected;
		  			LogUtil.logDebug('wlApp -> raqPDFTemplatesInitFailure :Network Info - '+networkInfo.isNetworkConnected);
		  			if (networkInfo.isNetworkConnected === 'false') {
		  				errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION_TITLE;
		  				errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_NO_INTERNET_CONNECTION;
		  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates failure - No internet connection',errorTitle,errorMsg,false);
		  			}else{
		  				errorTitle = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE_TITLE;
		  				errorMsg = Message[langCode].ERR_RETRIEVE_RAQ_CONTENT_MFP_CONNECTION_FAILURE;
		  				CommonUtil.handleAppError('Retrieve RAQ PDF Templates failure - MobileFirst server connection failure',errorTitle,errorMsg,false);
		  			}
	                busyIndicator.hide();
		  		});
            } 
	    }; 
	        
	    
     var loadLatestRAQConfig = function(){ 
	   	  LogUtil.logInfo('loadLatestRAQConfig latest version :'+AppConfig.systemParam.raqInfo.configFileVersion);
	   	  var raqInfo = AppConfig.systemParam.raqInfo;
	   	  var fileList= AppConfig.systemParam.raqInfo.fileList;
   	  	    
          DataPersister.getAppDataByNameValue('raqConfig',
           function (value) {
             LogUtil.logDebug('DEBUG: wlApp: loadLatestRAQConfig '+ value);             
             LogUtil.logInfo('loadLatestRAQConfig local version : '+value.configFileVersion);
             if (typeof value === 'undefined' || value === 'null' || value === null) {
            	 LogUtil.logDebug('DEBUG:wlApp:  No RAQConfig is defined.');
            	 RAQAdapter.getRAQConfigurations(AppState.userID,raqConfigInitSuccess,raqConfigInitFail);
               
             } else if(Number(raqInfo.configFileVersion)>Number(value.configFileVersion)) {
            	 LogUtil.logDebug('DEBUG: wlApp: RAQConfig is outdated.');
            	 RAQAdapter.getRAQConfigurations(AppState.userID,raqConfigInitSuccess,raqConfigInitFail);
               
             } else {
           	  LogUtil.logDebug('DEBUG:wlApp: RAQConfig in local storage is the latest version');
           	  AppState.raqConfig = CommonUtil.prepareRAQConfig(value); 
           	  loadLatestPDFTemplete();
             }
         },
         function(errorObject){
        	 LogUtil.logDebug('DEBUG:wlApp:  No RAQConfig is defined.');
        	 RAQAdapter.getRAQConfigurations(AppState.userID,raqConfigInitSuccess,raqConfigInitFail);
         });
       }; 

       var loadLatestPDFTemplete = function(){   
    	   LogUtil.logInfo('loadLatestPDFTemplete');
    	   var fullFileList=AppConfig.systemParam.raqInfo.fileList; 
    	   if (typeof fullFileList !== 'undefined' && fullFileList.length > 0) {  
    		   var fileMap = new Map();
	    	   var downloadFileList = [];
	    	   DataPersister.getAppDataByNameValue('raqPDFTemplate',
	    		function (value) {  
	             if (typeof value === 'undefined' || value === 'null' || value===null) {
	            	 LogUtil.logDebug('wlApp -> loadLatestPDFTemplete :  No PDFTemplete  is defined in local storage.');              
	            	 RAQAdapter.getRAQPDFTemplates(AppState.userID, fullFileList,raqPDFTemplatesInitSuccess,raqPDFTemplatesInitFailure);
	             } else {
	            	 LogUtil.logDebug('wlApp -> loadLatestPDFTemplete: PDFTemplete is found in local storage.');  
	            	 var localFileList = value;
	            	 localFileList.forEach(function(localFile) {
	      			   fileMap.set(localFile.id,localFile);
	  	    	   	 });
	            	 
	          		 fullFileList.forEach(function(file) {
	          			   var localCopy = fileMap.get(file.id);
	          			   if(typeof localCopy === 'undefined'|| localCopy === 'null' || localCopy===null){
	          				 downloadFileList.push(file); 
	          			   }else {
	          				   var fileVersion = file.version.split('-')[0];
	          				   var localVersion = localCopy.version.split('-')[0];
	          				   var lastModifiedDate = new Date(parseInt(fileVersion.split('/')[1]),parseInt(fileVersion.split('/')[0]),1);
	          				   var localModifiedDate = new Date(parseInt(localVersion.split('/')[1]),parseInt(localVersion.split('/')[0]),1);
	          				   LogUtil.logDebug('wlApp -> loadLatestPDFTemplete: lastModifiedDate is' + lastModifiedDate);
	          				   LogUtil.logDebug('wlApp -> loadLatestPDFTemplete: localModifiedDate is' + localModifiedDate);
	          				   if(lastModifiedDate>localModifiedDate){
	          					   downloadFileList.push(file);  
	          				   }else {
	          					   AppState.raqPDFTemplate.push(localCopy); 
	          				   }
	          			   }
	      	    	 });
	          		 LogUtil.logDebug('wlApp -> loadLatestPDFTemplete: '+downloadFileList.length +' PDFTemplete is outdated.');
	          		 if(downloadFileList.length>0){
	          			 RAQAdapter.getRAQPDFTemplates(AppState.userID, downloadFileList,raqPDFTemplatesInitSuccess,raqPDFTemplatesInitFailure);
	          		 }
	            	 
	            }
	         },
	         function(errorObject){
	       	  LogUtil.logDebug('DEBUG:wlApp: No PDFTemplete is defined.');              
	             RAQAdapter.getRAQPDFTemplates(AppState.userID, fullFileList,raqPDFTemplatesInitSuccess,raqPDFTemplatesInitFailure);
	         });
    	   }else {
    		   LogUtil.logError('wlApp: No PDFTemplete is configured in System Params.'); 
    	   }
       }; 
     
    var parseLangCode = function(inLangCode){ 
    	LogUtil.logDebug('DEBUG: parseLangCode : ' + inLangCode);
        var resultLangCode; 
        if (inLangCode == 'en-US' || inLangCode == 'en')
        {
          resultLangCode = Constants.LANG_EN;
        }
        else if (inLangCode == 'zh-hk' || inLangCode == 'zh-tw' || inLangCode == 'zh')
        {
          resultLangCode = Constants.LANG_TC; 
        }
        else
        {
          resultLangCode = Constants.LANG_TC;  
        }

        LogUtil.logDebug('DEBUG: resultLangCode : ' + resultLangCode);
        return resultLangCode;
    };
    var loadFunctionActivatorByModuleAccess = function() {
    	LogUtil.logDebug('wlApp -> loadFunctionActivatorByModuleAccess');
    	for (var i in AppConfig.functionActivatorByModuleAccess) {
    		entry = AppConfig.functionActivatorByModuleAccess[i];
    		if (entry.module && entry.enabled) {
        		FunctionActivator.setModuleAccessible(entry.module, (entry.enabled === 'Y'));
    		}
    	}
    };
    var loadFunctionActivatorByFunctionAccess = function() {
    	LogUtil.logDebug('wlApp -> loadFunctionActivatorByFunctionAccess');
    	for (var i in AppConfig.functionActivatorByFunctionAccess) {
    		entry = AppConfig.functionActivatorByFunctionAccess[i];
    		if (entry.fn && entry.enabled) {
        		FunctionActivator.setFunctionAccessible(entry.fn, entry.module, (entry.enabled === 'Y'));
    		}
    	}
    };
	return { 
	    initialize: initialize
	    
	  };
});